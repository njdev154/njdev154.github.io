/* ==========================================================
   N'Goran Junior · interactions
   JavaScript pur, sans librairie.
   1. Outils          6. Projets (paquet + grille)
   2. Langue          7. Étude de cas
   3. Arrivée         8. Stickers (physique)
   4. En-tête         9. Parcours
   5. Affiche        10. À propos, contact, divers
   ========================================================== */
(function () {
  "use strict";

  var NJ = window.NJ;
  var doc = document;
  var root = doc.documentElement;

  /* ---------- 1. Outils ---------- */
  function $(s, c) { return (c || doc).querySelector(s); }
  function $$(s, c) { return Array.prototype.slice.call((c || doc).querySelectorAll(s)); }
  function clamp(v, a, b) { return v < a ? a : v > b ? b : v; }
  function lerp(a, b, t) { return a + (b - a) * t; }
  function store(k, v) {
    try {
      if (v === undefined) return localStorage.getItem("p06-" + k);
      localStorage.setItem("p06-" + k, v);
    } catch (e) { return null; }
  }
  function sstore(k, v) {
    try {
      if (v === undefined) return sessionStorage.getItem("p06-" + k);
      sessionStorage.setItem("p06-" + k, v);
    } catch (e) { return null; }
  }
  // Création d'éléments sans innerHTML : tout le texte passe par textContent
  function el(tag, attrs, kids) {
    var n = doc.createElement(tag);
    if (attrs) Object.keys(attrs).forEach(function (k) {
      var v = attrs[k];
      if (v === null || v === undefined || v === false) return;
      if (k === "class") n.className = v;
      else if (k === "text") n.textContent = v;
      else if (k === "svg") n.innerHTML = v; // uniquement pour les logos internes (icons.js)
      else if (k.slice(0, 2) === "on") n.addEventListener(k.slice(2), v);
      else n.setAttribute(k, v);
    });
    (kids || []).forEach(function (c) { if (c) n.appendChild(typeof c === "string" ? doc.createTextNode(c) : c); });
    return n;
  }
  function safeUrl(u) { return typeof u === "string" && /^https:\/\/[^\s"'<>]+$/.test(u) ? u : null; }
  function arrowSvg(d) {
    var s = doc.createElementNS("http://www.w3.org/2000/svg", "svg");
    s.setAttribute("viewBox", "0 0 16 16"); s.setAttribute("aria-hidden", "true");
    var p = doc.createElementNS("http://www.w3.org/2000/svg", "path"); p.setAttribute("d", d);
    s.appendChild(p); return s;
  }

  var reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  var fine = window.matchMedia("(hover: hover) and (pointer: fine)").matches;
  var mqSmall = window.matchMedia("(max-width: 900px)");

  // Une seule boucle d'animation pour tout le site
  var tasks = [];
  var last = performance.now();
  function addTask(f) { if (tasks.indexOf(f) < 0) tasks.push(f); }
  function removeTask(f) { var i = tasks.indexOf(f); if (i >= 0) tasks.splice(i, 1); }
  function frame(now) {
    var dt = Math.min(0.034, (now - last) / 1000);
    last = now;
    for (var i = tasks.length - 1; i >= 0; i--) {
      if (tasks[i](dt, now) === false) tasks.splice(i, 1);
    }
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);

  function onView(node, cb, opts) {
    if (!("IntersectionObserver" in window)) { cb(true); return; }
    var io = new IntersectionObserver(function (es) { es.forEach(function (e) { cb(e.isIntersecting, e); }); }, opts || { threshold: 0 });
    io.observe(node);
    return io;
  }

  var toastTimer;
  function toast(msg) {
    var t = $("#toast");
    t.textContent = msg; t.classList.add("is-on");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { t.classList.remove("is-on"); }, 2400);
  }

  /* Objet qu'on attrape et qu'on lance : il revient à sa place grâce à un ressort.
     Peu amorti, il dépasse et revient comme un boomerang. */
  function Throwable(node, o) {
    o = o || {};
    var s = this;
    s.el = node; s.o = o;
    s.x = 0; s.y = 0; s.vx = 0; s.vy = 0; s.r = 0; s.vr = 0;
    s.k = o.k || 36; s.c = o.c || 4.4; s.held = false; s.free = false;
    var handle = o.handle || node, sx, sy, samples = [];
    s.tick = function (dt) {
      if (s.held) return true;
      if (s.free) return true;
      s.vx += (-s.k * s.x - s.c * s.vx) * dt;
      s.vy += (-s.k * s.y - s.c * s.vy) * dt;
      s.x += s.vx * dt; s.y += s.vy * dt;
      s.vr += (-30 * s.r - 5 * s.vr) * dt;
      s.r += s.vr * dt;
      s.paint();
      var done = Math.abs(s.x) < 0.3 && Math.abs(s.y) < 0.3 && Math.abs(s.vx) < 4 && Math.abs(s.vy) < 4 && Math.abs(s.r) < 0.3 && Math.abs(s.vr) < 4;
      if (done) { s.x = s.y = s.vx = s.vy = s.r = s.vr = 0; s.paint(); node.classList.remove("is-flying"); }
      return !done;
    };
    s.paint = function () {
      node.style.setProperty("--x", s.x.toFixed(2) + "px");
      node.style.setProperty("--y", s.y.toFixed(2) + "px");
      node.style.setProperty("--r", s.r.toFixed(2) + "deg");
    };
    s.release = function () { addTask(s.tick); };
    handle.addEventListener("pointerdown", function (e) {
      if (e.button !== 0 || reduce) return;
      if (o.ignore && o.ignore(e)) return;
      e.preventDefault();
      try { handle.setPointerCapture(e.pointerId); } catch (err) { /* rien */ }
      s.held = true; s.free = false;
      sx = e.clientX - s.x; sy = e.clientY - s.y;
      samples = [{ x: e.clientX, y: e.clientY, t: performance.now() }];
      node.classList.add("is-held", "is-flying");
      addTask(s.tick);
      if (o.onGrab) o.onGrab(s);
    });
    handle.addEventListener("pointermove", function (e) {
      if (!s.held) return;
      s.x = e.clientX - sx; s.y = e.clientY - sy;
      var now = performance.now();
      samples.push({ x: e.clientX, y: e.clientY, t: now });
      while (samples.length > 2 && now - samples[0].t > 90) samples.shift();
      var a = samples[0], b = samples[samples.length - 1], dtm = Math.max(1, b.t - a.t);
      s.r = clamp(((b.x - a.x) / dtm) * 8, -18, 18);
      s.paint();
    });
    function up(e, cancel) {
      if (!s.held) return;
      s.held = false;
      node.classList.remove("is-held");
      var a = samples[0], b = samples[samples.length - 1], dtm = Math.max(16, b.t - a.t);
      if (cancel || performance.now() - b.t > 120) { s.vx = 0; s.vy = 0; }
      else { s.vx = clamp(((b.x - a.x) / dtm) * 1000, -5000, 5000); s.vy = clamp(((b.y - a.y) / dtm) * 1000, -5000, 5000); }
      s.vr = o.spin ? clamp(s.vx * 0.28, -1300, 1300) : 0;
      if (o.onRelease && o.onRelease(s, e) === false) return;
      addTask(s.tick);
    }
    handle.addEventListener("pointerup", function (e) { up(e, false); });
    handle.addEventListener("pointercancel", function (e) { up(e, true); });
  }

  /* ---------- 2. Langue ---------- */
  var lang = store("nj-lang") || "fr";
  if (lang !== "fr" && lang !== "en") lang = "fr";
  function t(k) {
    var d = NJ.I18N[lang];
    return d[k] !== undefined ? d[k] : NJ.I18N.fr[k];
  }
  function L(obj) { return obj[lang] || obj.fr; }

  function setMis(n, text) {
    n.textContent = "";
    n.appendChild(el("span", { class: "mis__a", text: text }));
    n.appendChild(el("span", { class: "mis__b", "aria-hidden": "true", text: text }));
  }

  var langHooks = [];
  function applyLang() {
    root.lang = lang;
    $$("[data-i18n]").forEach(function (n) {
      var v = t(n.getAttribute("data-i18n"));
      if (typeof v !== "string") return;
      if (n.classList.contains("mis")) setMis(n, v);
      else n.textContent = v;
    });
    $$(".lang button").forEach(function (b) { b.setAttribute("aria-pressed", String(b.getAttribute("data-lang") === lang)); });
    langHooks.forEach(function (f) { f(); });
  }
  $$(".lang button").forEach(function (b) {
    b.addEventListener("click", function () {
      var l = b.getAttribute("data-lang");
      if (l === lang) return;
      lang = l; store("nj-lang", l); applyLang();
    });
  });

  /* ---------- Défaut de calage lié à la vitesse de défilement ---------- */
  (function () {
    var lastY = window.scrollY, mis = 0, shown = -1;
    addTask(function () {
      var y = window.scrollY, v = y - lastY; lastY = y;
      mis = lerp(mis, clamp(v * 0.35, -16, 16), 0.12);
      var q = Math.round(mis * 10) / 10;
      if (q !== shown) {
        shown = q;
        root.style.setProperty("--mx", (2.5 + q * 0.5).toFixed(1) + "px");
        root.style.setProperty("--my", (1.5 + q).toFixed(1) + "px");
      }
      var bar = $(".progress span");
      var max = doc.documentElement.scrollHeight - window.innerHeight;
      if (bar) bar.style.transform = "scaleX(" + (max > 0 ? y / max : 0).toFixed(4) + ")";
    });
  })();

  /* ---------- 3. Arrivée ---------- */
  var arrived = [];
  function whenArrived(f) { if (arrived === true) f(); else arrived.push(f); }
  (function () {
    var press = $("#press");
    function done() {
      if (arrived === true) return;
      var list = arrived; arrived = true;
      doc.body.classList.remove("is-loading");
      press.classList.add("is-done");
      setTimeout(function () { press.remove(); }, 1000);
      list.forEach(function (f) { f(); });
    }
    if (reduce || sstore("nj-press")) { press.remove(); doc.body.classList.remove("is-loading"); var l = arrived; arrived = true; l.forEach(function (f) { f(); }); return; }
    sstore("nj-press", "1");
    $(".press__skip", press).addEventListener("click", done);
    setTimeout(done, 1500);
  })();

  /* ---------- 4. En-tête ---------- */
  (function () {
    var head = $("#head"), lastY = 0, nav = $("#nav"), burger = $(".burger");
    window.addEventListener("scroll", function () {
      var y = window.scrollY;
      head.classList.toggle("is-solid", y > 30);
      if (!head.classList.contains("menu-open")) head.classList.toggle("is-hidden", y > 700 && y > lastY + 2);
      if (y < lastY - 2) head.classList.remove("is-hidden");
      lastY = y;
    }, { passive: true });

    function setMenu(open) {
      burger.setAttribute("aria-expanded", String(open));
      nav.classList.toggle("is-open", open);
      head.classList.toggle("menu-open", open);
      doc.body.style.overflow = open ? "hidden" : "";
      var b = $(".sr", burger); if (b) b.textContent = t(open ? "nav.close" : "nav.menu");
    }
    burger.addEventListener("click", function () { setMenu(burger.getAttribute("aria-expanded") !== "true"); });
    $$("a", nav).forEach(function (a) { a.addEventListener("click", function () { if (nav.classList.contains("is-open")) setMenu(false); }); });
    doc.addEventListener("keydown", function (e) { if (e.key === "Escape" && nav.classList.contains("is-open")) setMenu(false); });

    var links = $$("a", nav);
    links.forEach(function (a) {
      var sec = $(a.getAttribute("href"));
      if (!sec) return;
      onView(sec, function (vis) {
        if (vis) links.forEach(function (x) { x.classList.toggle("is-active", x === a); });
        else a.classList.remove("is-active");
      }, { rootMargin: "-45% 0px -50% 0px" });
    });
  })();

  /* ---------- Heure d'Abidjan ---------- */
  (function () {
    var fmt;
    try { fmt = new Intl.DateTimeFormat("fr-FR", { hour: "2-digit", minute: "2-digit", timeZone: "Africa/Abidjan" }); }
    catch (e) { fmt = null; }
    function tick() {
      var d = new Date();
      var s = fmt ? fmt.format(d) : String(d.getUTCHours()).padStart(2, "0") + ":" + String(d.getUTCMinutes()).padStart(2, "0");
      $$("[data-clock]").forEach(function (n) { n.textContent = s; });
    }
    tick(); setInterval(tick, 15000);
    $$("[data-year]").forEach(function (n) { n.textContent = String(new Date().getFullYear()); });
  })();

  /* ---------- 5. L'affiche ---------- */
  (function hero() {
    var rows = $$("[data-letters]");
    var letters = [];
    rows.forEach(function (row) {
      var txt = row.textContent; row.textContent = "";
      row.setAttribute("aria-hidden", "true");
      Array.prototype.forEach.call(txt, function (ch) {
        var s = el("span", { class: "ltr", "data-cursor": "cursor.grab" }, [
          el("span", { class: "ltr__p", text: ch }),
          el("span", { class: "ltr__a", text: ch })
        ]);
        row.appendChild(s);
        letters.push(s);
      });
    });
    letters.forEach(function (n) {
      if (!fine) n.style.touchAction = "pan-y";
      new Throwable(n, { spin: true, k: 34, c: 4 });
    });

    var ticket = $(".ticket");
    if (ticket) { ticket.setAttribute("data-cursor", "cursor.grab"); new Throwable(ticket, { spin: true, k: 30, c: 3.6 }); }

    whenArrived(function () {
      if (reduce) return;
      letters.forEach(function (n, i) {
        n.animate([{ transform: "translate3d(0, 0.9em, 0) rotate(8deg)", opacity: 0 }, { transform: "translate3d(0,0,0) rotate(0deg)", opacity: 1 }],
          { duration: 900, delay: 60 + i * 45, easing: "cubic-bezier(.22,1,.36,1)", fill: "backwards" });
      });
      $$(".hero__foot, .hero__meta, .ticket, .hero__hint").forEach(function (n, i) {
        n.animate([{ opacity: 0, transform: "translateY(18px)" }, { opacity: 1, transform: "none" }],
          { duration: 800, delay: 700 + i * 90, easing: "cubic-bezier(.22,1,.36,1)", fill: "backwards" });
      });
    });

    /* Portrait en trame (demi-teinte) dessiné à l'encre rose.
       Les points grossissent près du curseur et respirent doucement. */
    var cv = $(".hero__dots"), img = $(".hero__src");
    if (!cv || !img) return;
    var ctx = cv.getContext("2d");
    var cells = [], W = 0, H = 0, dpr = 1, step = 9, visible = true, born = 0;
    var px = -9999, py = -9999, ppx = -9999, ppy = -9999;
    var hero = $(".hero");

    function build() {
      var rect = cv.getBoundingClientRect();
      dpr = Math.min(2, window.devicePixelRatio || 1);
      W = rect.width; H = rect.height;
      if (!W || !H || !img.naturalWidth) return;
      cv.width = Math.round(W * dpr); cv.height = Math.round(H * dpr);
      step = W < 560 ? 6 : 7.5;
      // Le portrait est posé en bas, centré, à la hauteur du cadre
      var ir = img.naturalWidth / img.naturalHeight;
      var dh = H * (mqSmall.matches ? 1 : 0.94), dw = dh * ir;
      if (dw > W * 1.05) { dw = W * 1.05; dh = dw / ir; }
      var ox = (W - dw) / 2 - (mqSmall.matches ? 0 : W * 0.1), oy = H - dh;
      var cols = Math.ceil(dw / step), rws = Math.ceil(dh / step);
      var off = doc.createElement("canvas"); off.width = cols; off.height = rws;
      var octx = off.getContext("2d", { willReadFrequently: true });
      octx.drawImage(img, 0, 0, cols, rws);
      var data;
      try { data = octx.getImageData(0, 0, cols, rws).data; } catch (e) { return; }
      cells = [];
      var raw = [];
      for (var j = 0; j < rws; j++) {
        for (var i = 0; i < cols; i++) {
          var k = (j * cols + i) * 4;
          var lum = (0.2126 * data[k] + 0.7152 * data[k + 1] + 0.0722 * data[k + 2]) / 255;
          raw.push(1 - lum);
        }
      }
      // Niveaux : on étire la plage utile du visage pour garder les détails
      var sorted = raw.filter(function (v) { return v > 0.12; }).sort(function (a, b) { return a - b; });
      var lo = sorted[Math.floor(sorted.length * 0.12)] || 0.1, hi = sorted[Math.floor(sorted.length * 0.995)] || 1;
      var cx0 = ox + dw / 2, cy0 = H;
      var maxd = Math.hypot(dw / 2, dh);
      for (j = 0; j < rws; j++) {
        for (i = 0; i < cols; i++) {
          var d = raw[j * cols + i];
          if (d < 0.1) continue;
          var v = clamp((d - lo) / (hi - lo), 0, 1);
          v = 0.06 + 0.94 * Math.pow(v, 1.55);
          var x = ox + i * step + step / 2, y = oy + j * step + step / 2;
          cells.push({ x: x, y: y, v: v, o: Math.hypot(x - cx0, y - cy0) / maxd });
        }
      }
      paint(performance.now());
    }

    function paint(now) {
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, W, H);
      ctx.fillStyle = "#ff4fa0";
      ctx.beginPath();
      var since = born ? (now - born) / 1700 : 1;
      var sweep = reduce ? 1 : clamp(since, 0, 1.6);
      var sig2 = 2 * 110 * 110, half = step * 0.56, tt = now * 0.0016;
      for (var n = 0; n < cells.length; n++) {
        var c = cells[n];
        var grow = clamp((sweep * 1.5 - c.o) * 2.6, 0, 1);
        if (grow <= 0) continue;
        var dx = c.x - ppx, dy = c.y - ppy, dd = dx * dx + dy * dy;
        var near = dd < 90000 ? Math.exp(-dd / sig2) : 0;
        var breath = reduce ? 0 : 0.07 * Math.sin(tt + (c.x + c.y) * 0.018);
        var r = half * 1.12 * Math.sqrt(c.v) * (1 + breath) * (1 + near * 0.55) * grow;
        var x = c.x, y = c.y;
        if (near > 0.01) { var dl = Math.sqrt(dd) || 1; x += (dx / dl) * near * 9; y += (dy / dl) * near * 9; }
        if (r < 0.35) continue;
        ctx.moveTo(x + r, y);
        ctx.arc(x, y, r, 0, 6.2832);
      }
      ctx.fill();
    }

    function loop(dt, now) {
      if (!visible) return false;
      ppx = lerp(ppx, px, 0.16); ppy = lerp(ppy, py, 0.16);
      paint(now);
      return true;
    }

    hero.addEventListener("pointermove", function (e) {
      var r = cv.getBoundingClientRect();
      if (ppx < -999) { ppx = e.clientX - r.left; ppy = e.clientY - r.top; }
      px = e.clientX - r.left; py = e.clientY - r.top;
    });
    hero.addEventListener("pointerleave", function () { px = -9999; py = -9999; });

    function start() {
      build();
      whenArrived(function () { born = performance.now() + 150; });
      onView(hero, function (vis) { visible = vis; if (vis) addTask(loop); });
      var rt;
      window.addEventListener("resize", function () { clearTimeout(rt); rt = setTimeout(build, 150); });
    }
    if (img.complete && img.naturalWidth) start();
    else img.addEventListener("load", start);
  })();

  /* ---------- 6. Projets ---------- */
  var openCase; // défini plus bas
  (function work() {
    var P = NJ.PROJECTS;
    var deck = $("#deck"), info = $("#deck-info"), grid = $("#grid"), stage = $(".work__stage");
    var order = P.map(function (_, i) { return i; });
    var cards = [];
    var busy = false;
    var ROT = [0, -3.6, 2.8, -1.8, 1.4];

    function cardNode(p, interactive) {
      var tx = L(p);
      return el("article", { class: "card", "data-slug": p.slug }, [
        el("div", { class: "card__img" }, [el("img", { src: p.cover, alt: tx.tagline, loading: "lazy", decoding: "async", draggable: "false" })]),
        el("span", { class: "card__stamp card__stamp--" + p.status, text: t("status." + p.status) }),
        el("div", { class: "card__body" }, [
          el("h3", { class: "card__name", text: p.name }),
          el("p", { class: "card__tag", text: tx.tagline }),
          el("div", { class: "card__stack" }, p.stack.map(function (s) { return el("span", { class: "tag", text: s }); }))
        ])
      ]);
    }

    function slot(i) {
      var k = Math.min(i, 4);
      return { x: k * 9, y: k * -7, r: ROT[k], s: 1 - k * 0.03 };
    }
    function layout(animate) {
      order.forEach(function (pi, i) {
        var c = cards[pi], s = slot(i);
        c.style.transition = animate ? "transform .6s cubic-bezier(.22,1,.36,1), opacity .4s" : "none";
        c.style.transform = "translate3d(" + s.x + "px," + s.y + "px,0) rotate(" + s.r + "deg) scale(" + s.s + ")";
        c.style.zIndex = String(10 - i);
        c.style.opacity = i > 3 ? "0" : "1";
        c.classList.toggle("is-top", i === 0);
        c.setAttribute("tabindex", i === 0 ? "0" : "-1");
        c.setAttribute("aria-hidden", i === 0 ? "false" : "true");
        if (i === 0) { c.setAttribute("data-cursor", "cursor.throw"); c.setAttribute("role", "button"); c.setAttribute("aria-label", P[pi].name + ", " + t("work.open")); }
        else { c.removeAttribute("data-cursor"); c.removeAttribute("role"); c.removeAttribute("aria-label"); }
      });
    }

    function renderInfo() {
      var p = P[order[0]], tx = L(p);
      info.textContent = "";
      var name = el("h3", { class: "deck-info__name mis" }); setMis(name, p.name);
      var btns = el("div", { class: "deck-info__btns" }, [
        el("button", { class: "btn btn--blue", type: "button", onclick: function () { openCase(p.slug); } }, [el("span", { text: t("work.open") }), arrowSvg("M3 8h10M9 4l4 4-4 4")]),
        safeUrl(p.demo) ? el("a", { class: "btn btn--line", href: p.demo, target: "_blank", rel: "noopener noreferrer" }, [el("span", { text: t("work.demo") }), arrowSvg("M5 11 11 5M6 5h5v5")]) : null,
        safeUrl(p.code) ? el("a", { class: "btn btn--line", href: p.code, target: "_blank", rel: "noopener noreferrer" }, [el("span", { text: t("work.code") }), arrowSvg("M5 11 11 5M6 5h5v5")]) : null
      ]);
      var pos = order[0] + 1;
      var wrap = el("div", { class: "swap-in", style: null }, [
        el("p", { class: "deck-info__count" }, [el("b", { text: String(pos).padStart(2, "0") }), " / " + String(P.length).padStart(2, "0") + "  ·  " + t("status." + p.status)]),
        name,
        el("p", { class: "deck-info__tag", text: tx.tagline }),
        el("p", { class: "deck-info__meta", text: tx.type + " · " + p.stack.join(" · ") }),
        btns,
        el("div", { class: "deck-info__nav" }, [
          el("button", { class: "round", type: "button", "aria-label": t("work.prev"), onclick: prev }, [arrowSvg("M13 8H3M7 4 3 8l4 4")]),
          el("button", { class: "round", type: "button", "aria-label": t("work.next"), onclick: function () { next(); } }, [arrowSvg("M3 8h10M9 4l4 4-4 4")]),
          el("p", { class: "deck-info__hint", text: t("work.hint") })
        ])
      ]);
      wrap.style.display = "grid"; wrap.style.gap = "18px";
      info.appendChild(wrap);
    }

    function buildDeck() {
      deck.textContent = "";
      cards = P.map(function (p) {
        var c = cardNode(p, true);
        if (!fine) c.style.touchAction = "pan-y";
        deck.appendChild(c);
        bindCard(c);
        return c;
      });
      layout(false);
      renderInfo();
    }

    function bindCard(c) {
      var held = false, sx = 0, sy = 0, dx = 0, dy = 0, t0 = 0, samples = [];
      c.addEventListener("pointerdown", function (e) {
        if (!c.classList.contains("is-top") || busy || e.button !== 0) return;
        if (e.target.closest("a, button")) return;
        held = true; c.classList.add("is-held");
        try { c.setPointerCapture(e.pointerId); } catch (err) { /* rien */ }
        sx = e.clientX; sy = e.clientY; dx = dy = 0; t0 = performance.now();
        samples = [{ x: sx, y: sy, t: t0 }];
        c.style.transition = "none";
      });
      c.addEventListener("pointermove", function (e) {
        if (!held) return;
        dx = e.clientX - sx; dy = e.clientY - sy;
        var now = performance.now();
        samples.push({ x: e.clientX, y: e.clientY, t: now });
        while (samples.length > 2 && now - samples[0].t > 90) samples.shift();
        c.style.transform = "translate3d(" + dx + "px," + dy + "px,0) rotate(" + (dx * 0.06) + "deg)";
      });
      function up(e, cancel) {
        if (!held) return;
        held = false; c.classList.remove("is-held");
        var a = samples[0], b = samples[samples.length - 1], dtm = Math.max(16, b.t - a.t);
        var vx = (b.x - a.x) / dtm, vy = (b.y - a.y) / dtm;
        if (performance.now() - b.t > 120) { vx = 0; vy = 0; }
        var dist = Math.hypot(dx, dy), speed = Math.hypot(vx, vy);
        if (!cancel && dist < 6 && performance.now() - t0 < 350) { layout(true); openCase(P[order[0]].slug); return; }
        if (!cancel && (dist > 120 || speed > 0.65)) {
          var ux = vx, uy = vy;
          if (speed < 0.2) { ux = dx; uy = dy; }
          var m = Math.hypot(ux, uy) || 1;
          boomerang(c, dx, dy, ux / m, uy / m);
        } else {
          layout(true);
        }
      }
      c.addEventListener("pointerup", function (e) { up(e, false); });
      c.addEventListener("pointercancel", function (e) { up(e, true); });
      c.addEventListener("keydown", function (e) {
        if (!c.classList.contains("is-top")) return;
        if (e.key === "Enter" || e.key === " ") { e.preventDefault(); openCase(P[order[0]].slug); }
        if (e.key === "ArrowRight") { e.preventDefault(); next(); }
        if (e.key === "ArrowLeft") { e.preventDefault(); prev(); }
      });
    }

    // La carte part dans la direction du lancer, tourne, et revient sous le paquet
    function boomerang(c, x0, y0, ux, uy) {
      if (busy) return;
      busy = true;
      var rect = deck.getBoundingClientRect();
      var reach = Math.max(520, Math.min(window.innerWidth, 1400) * 0.5);
      var side = ux >= 0 ? 1 : -1;
      var p1x = x0 + ux * reach + -uy * 260 * side, p1y = y0 + uy * reach + ux * 260 * side;
      // Garde l'apogée à peu près à l'écran
      p1y = clamp(p1y, -rect.top - 120, window.innerHeight - rect.top - 100);
      var end = slot(P.length - 1);
      var r0 = x0 * 0.06, spin = 360 * side;
      var dur = reduce ? 1 : 1050, t0 = performance.now(), swapped = false;
      c.style.transition = "none";
      function ease(u) { return u < 0.5 ? 4 * u * u * u : 1 - Math.pow(-2 * u + 2, 3) / 2; }
      addTask(function step() {
        var u = clamp((performance.now() - t0) / dur, 0, 1);
        var e = ease(u), a = 1 - e;
        var x = a * a * x0 + 2 * a * e * p1x + e * e * end.x;
        var y = a * a * y0 + 2 * a * e * p1y + e * e * end.y;
        var r = r0 + (spin + end.r - r0) * e;
        var s = 1 - 0.14 * Math.sin(Math.PI * u);
        c.style.transform = "translate3d(" + x + "px," + y + "px,0) rotate(" + r + "deg) scale(" + s + ")";
        if (!swapped && u > 0.45) {
          swapped = true;
          order.push(order.shift());
          // les autres cartes montent d'un cran
          order.forEach(function (pi, i) {
            if (cards[pi] === c) return;
            var cc = cards[pi], sl = slot(i);
            cc.style.transition = "transform .6s cubic-bezier(.22,1,.36,1), opacity .4s";
            cc.style.transform = "translate3d(" + sl.x + "px," + sl.y + "px,0) rotate(" + sl.r + "deg) scale(" + sl.s + ")";
            cc.style.zIndex = String(10 - i);
            cc.style.opacity = i > 3 ? "0" : "1";
          });
          c.style.zIndex = "1";
          renderInfo();
        }
        if (u >= 1) {
          layout(false);
          busy = false;
          var top = cards[order[0]];
          if (doc.activeElement && deck.contains(doc.activeElement)) top.focus({ preventScroll: true });
          return false;
        }
        return true;
      });
    }

    function next() {
      if (busy) return;
      var c = cards[order[0]];
      boomerang(c, 0, 0, 0.94, -0.34);
    }
    function prev() {
      if (busy) return;
      busy = true;
      order.unshift(order.pop());
      var c = cards[order[0]];
      layout(true);
      c.style.zIndex = "20";
      c.animate([
        { transform: "translate3d(-560px,-80px,0) rotate(-24deg) scale(.9)", opacity: 0.2 },
        { transform: "translate3d(0,0,0) rotate(0deg) scale(1)", opacity: 1 }
      ], { duration: reduce ? 1 : 700, easing: "cubic-bezier(.22,1,.36,1)" }).onfinish = function () { layout(false); busy = false; };
      renderInfo();
    }

    function buildGrid() {
      grid.textContent = "";
      P.forEach(function (p) {
        var c = cardNode(p, false);
        c.setAttribute("tabindex", "0"); c.setAttribute("role", "button");
        c.setAttribute("aria-label", p.name + ", " + t("work.open"));
        c.setAttribute("data-cursor", "cursor.open");
        c.addEventListener("click", function () { openCase(p.slug); });
        c.addEventListener("keydown", function (e) { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); openCase(p.slug); } });
        grid.appendChild(c);
      });
    }

    $$(".seg button").forEach(function (b) {
      b.addEventListener("click", function () {
        var v = b.getAttribute("data-view");
        $$(".seg button").forEach(function (x) { x.setAttribute("aria-pressed", String(x === b)); });
        var g = v === "grid";
        stage.hidden = g; grid.hidden = !g;
        if (g) {
          $$(".card", grid).forEach(function (c, i) {
            if (!reduce) c.animate([{ opacity: 0, transform: "translateY(40px) rotate(" + (i % 2 ? 3 : -3) + "deg)" }, { opacity: 1, transform: "none" }], { duration: 650, delay: i * 70, easing: "cubic-bezier(.22,1,.36,1)", fill: "backwards" });
          });
        } else layout(false);
      });
    });

    buildDeck(); buildGrid();
    langHooks.push(function () {
      cards.forEach(function (c, i) {
        var p = P[i], tx = L(p);
        $(".card__tag", c).textContent = tx.tagline;
        $(".card__stamp", c).textContent = t("status." + p.status);
        $(".card__img img", c).alt = tx.tagline;
      });
      layout(false); renderInfo(); buildGrid();
    });

    // Le paquet arrive en éventail quand on le voit
    var shown = false;
    onView(deck, function (vis) {
      if (!vis || shown || reduce) return;
      shown = true;
      order.slice().reverse().forEach(function (pi, k) {
        cards[pi].animate([{ transform: "translate3d(" + (k % 2 ? 260 : -260) + "px, 220px,0) rotate(" + (k % 2 ? 24 : -24) + "deg)", opacity: 0 }, { opacity: 1 }],
          { duration: 900, delay: k * 90, easing: "cubic-bezier(.22,1,.36,1)", fill: "backwards", composite: "replace" });
      });
    }, { threshold: 0.25 });
  })();

  /* ---------- 7. Étude de cas ---------- */
  (function sheet() {
    var box = $("#sheet"), paper = $(".sheet__paper", box), body = $("#sheet-body");
    var current = null, lastFocus = null, pushed = false, closeT;
    var P = NJ.PROJECTS;

    function render(slug) {
      var i = P.findIndex(function (p) { return p.slug === slug; });
      if (i < 0) return false;
      var p = P[i], tx = L(p), nx = P[(i + 1) % P.length];
      body.textContent = "";
      var title = el("h2", { class: "cs__name mis", id: "sheet-title" }); setMis(title, p.name);
      body.appendChild(el("header", { class: "cs__head" }, [
        el("p", { class: "label", text: tx.type + " · " + p.year }),
        title,
        el("p", { class: "cs__tag", text: tx.tagline })
      ]));
      body.appendChild(el("dl", { class: "cs__meta" }, [
        el("div", null, [el("dt", { text: t("cs.type") }), el("dd", { text: tx.type })]),
        el("div", null, [el("dt", { text: t("cs.stack") }), el("dd", { text: p.stack.join(" · ") })]),
        el("div", null, [el("dt", { text: t("cs.status") }), el("dd", { text: t("status." + p.status) })])
      ]));
      var links = el("div", { class: "cs__links" }, [
        safeUrl(p.demo) ? el("a", { class: "btn btn--blue", href: p.demo, target: "_blank", rel: "noopener noreferrer" }, [el("span", { text: t("work.demo") }), arrowSvg("M5 11 11 5M6 5h5v5")]) : el("span", { class: "cs__nodemo", text: t("cs.nodemo") }),
        safeUrl(p.code) ? el("a", { class: "btn btn--line", href: p.code, target: "_blank", rel: "noopener noreferrer" }, [el("span", { text: t("work.code") }), arrowSvg("M5 11 11 5M6 5h5v5")]) : null
      ]);
      body.appendChild(links);
      body.appendChild(el("div", { class: "cs__gallery" }, p.gallery.map(function (g) {
        return el("figure", { class: "cs__shot" }, [el("img", { src: g.src, alt: p.name + " : " + L(g), loading: "lazy", decoding: "async" }), el("figcaption", { text: L(g) })]);
      })));
      body.appendChild(el("section", { class: "cs__block" }, [el("h3", { text: t("cs.context") }), el("p", { text: tx.context })]));
      body.appendChild(el("div", { class: "cs__cols" }, [
        el("section", { class: "cs__block" }, [el("h3", { text: t("cs.shows") }), el("ul", { role: "list" }, tx.shows.map(function (s) { return el("li", { text: s }); }))]),
        el("section", { class: "cs__block" }, [el("h3", { text: t("cs.learned") }), el("ul", { role: "list" }, tx.learned.map(function (s) { return el("li", { text: s }); }))])
      ]));
      body.appendChild(el("section", { class: "cs__honest" }, [el("h3", { text: t("cs.honest") }), el("p", { text: tx.honest })]));
      body.appendChild(el("button", { class: "cs__next", type: "button", "data-cursor": "cursor.open", onclick: function () { show(nx.slug, true); } }, [el("span", { text: t("cs.next") }), el("b", { text: nx.name + " →" })]));
      current = slug;
      return true;
    }

    function show(slug, replace) {
      if (!render(slug)) return;
      clearTimeout(closeT);
      var hash = "#/projets/" + slug;
      if (location.hash !== hash) {
        try {
          if (replace || pushed) history.replaceState(null, "", hash);
          else { history.pushState(null, "", hash); pushed = true; }
        } catch (e) { /* rien */ }
      }
      if (box.hidden) {
        lastFocus = doc.activeElement;
        box.hidden = false;
        doc.body.style.overflow = "hidden";
        requestAnimationFrame(function () { requestAnimationFrame(function () { box.classList.add("is-open"); }); });
      }
      paper.scrollTop = 0;
      paper.focus({ preventScroll: true });
    }
    function hide(fromRoute) {
      if (box.hidden) return;
      box.classList.remove("is-open");
      doc.body.style.overflow = "";
      current = null;
      if (!fromRoute) {
        try {
          if (pushed) { pushed = false; history.back(); }
          else history.replaceState(null, "", location.pathname + location.search + "#work");
        } catch (e) { /* rien */ }
      } else pushed = false;
      closeT = setTimeout(function () { box.hidden = true; }, reduce ? 0 : 650);
      if (lastFocus && lastFocus.focus) lastFocus.focus({ preventScroll: true });
    }
    openCase = function (slug) { show(slug, false); };

    function route() {
      var m = /^#\/projets\/([a-z0-9-]+)$/.exec(location.hash);
      if (m) show(m[1], true);
      else hide(true);
    }
    window.addEventListener("hashchange", route);
    window.addEventListener("popstate", route);
    whenArrived(function () { if (/^#\/projets\//.test(location.hash)) route(); });

    $$("[data-close]", box).forEach(function (b) { b.addEventListener("click", function () { hide(false); }); });
    box.addEventListener("keydown", function (e) {
      if (e.key === "Escape") { e.preventDefault(); hide(false); return; }
      if (e.key !== "Tab") return;
      var f = $$("a[href], button:not([disabled]), [tabindex]:not([tabindex='-1'])", paper).filter(function (n) { return n.offsetParent !== null; });
      if (!f.length) return;
      var first = f[0], lastEl = f[f.length - 1];
      if (e.shiftKey && (doc.activeElement === first || doc.activeElement === paper)) { e.preventDefault(); lastEl.focus(); }
      else if (!e.shiftKey && doc.activeElement === lastEl) { e.preventDefault(); first.focus(); }
    });
    langHooks.push(function () { if (current) render(current); });
  })();

  /* ---------- 8. Stickers : petite physique maison ---------- */
  (function stickers() {
    var board = $("#board"), proof = $("#proof");
    if (!board) return;
    var S = NJ.SKILLS, P = NJ.PROJECTS;
    var bodies = [], W = 0, H = 0, running = false, started = false, calm = 0, selected = "html";
    var G = 2200, REST = 0.38;

    function radius(id) {
      var base = W < 520 ? 40 : 56;
      return ["html", "css", "js"].indexOf(id) >= 0 ? base + 8 : base;
    }
    function measure() { W = board.clientWidth; H = board.clientHeight; }

    function renderProof() {
      var s = S.find(function (x) { return x.id === selected; }) || S[0];
      proof.textContent = "";
      proof.appendChild(el("p", { class: "proof__name", text: s.name }));
      if (s.uses.length) {
        proof.appendChild(el("p", { class: "proof__label", text: t("skills.used") + " · " + s.uses.length }));
        proof.appendChild(el("div", { class: "proof__list" }, s.uses.map(function (slug) {
          var p = P.find(function (x) { return x.slug === slug; });
          return p ? el("button", { type: "button", onclick: function () { openCase(slug); } }, [p.name + " ↗"]) : null;
        })));
      } else proof.appendChild(el("p", { class: "proof__empty", text: t("skills.none") }));
      bodies.forEach(function (b) { b.el.classList.toggle("is-on", b.id === selected); b.el.setAttribute("aria-pressed", String(b.id === selected)); });
    }
    function select(id) { if (id === selected) return; selected = id; renderProof(); }

    S.forEach(function (s, i) {
      var n = el("button", { class: "sticker", type: "button", "aria-label": s.name, "aria-pressed": "false", "data-cursor": "cursor.grab" }, [
        el("i", { svg: NJ.ICONS[s.id] || "" }),
        el("span", { text: s.name })
      ]);
      var ic = n.firstChild; // le svg sort de la balise i
      if (ic && ic.firstChild) { n.replaceChild(ic.firstChild, ic); }
      board.appendChild(n);
      var b = { id: s.id, el: n, x: 0, y: 0, vx: 0, vy: 0, a: 0, r: 50, held: false, hx: 0, hy: 0, samples: [] };
      bodies.push(b);
      var downAt = 0, moved = 0;
      n.addEventListener("pointerdown", function (e) {
        if (e.button !== 0) return;
        e.preventDefault();
        try { n.setPointerCapture(e.pointerId); } catch (err) { /* rien */ }
        var r = board.getBoundingClientRect();
        b.held = true; n.classList.add("is-held");
        b.hx = e.clientX - r.left - b.x; b.hy = e.clientY - r.top - b.y;
        b.samples = [{ x: b.x, y: b.y, t: performance.now() }];
        downAt = performance.now(); moved = 0;
        wake();
      });
      n.addEventListener("pointermove", function (e) {
        if (!b.held) return;
        var r = board.getBoundingClientRect();
        var nx = e.clientX - r.left - b.hx, ny = e.clientY - r.top - b.hy;
        moved += Math.abs(nx - b.x) + Math.abs(ny - b.y);
        b.x = clamp(nx, b.r, W - b.r); b.y = clamp(ny, -200, H - b.r);
        var now = performance.now();
        b.samples.push({ x: b.x, y: b.y, t: now });
        while (b.samples.length > 2 && now - b.samples[0].t > 90) b.samples.shift();
      });
      function up() {
        if (!b.held) return;
        b.held = false; n.classList.remove("is-held");
        var a = b.samples[0], z = b.samples[b.samples.length - 1], dtm = Math.max(16, z.t - a.t);
        if (performance.now() - z.t > 120) { b.vx = 0; b.vy = 0; }
        else { b.vx = clamp(((z.x - a.x) / dtm) * 1000, -4200, 4200); b.vy = clamp(((z.y - a.y) / dtm) * 1000, -4200, 4200); }
        if (moved < 6 && performance.now() - downAt < 400) select(s.id);
        wake();
      }
      n.addEventListener("pointerup", up);
      n.addEventListener("pointercancel", up);
      n.addEventListener("keydown", function (e) { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); select(s.id); } });
      if (fine) n.addEventListener("pointerenter", function () { if (!b.held) select(s.id); });
    });

    function sizeBodies() {
      bodies.forEach(function (b) {
        b.r = radius(b.id);
        b.el.style.width = b.el.style.height = b.r * 2 + "px";
        b.el.style.setProperty("--s", b.r * 2 + "px");
      });
    }

    function drop() {
      measure(); sizeBodies();
      bodies.forEach(function (b, i) {
        b.x = b.r + Math.random() * (W - b.r * 2);
        b.y = -b.r - i * 70 - Math.random() * 40;
        b.vx = (Math.random() - 0.5) * 200; b.vy = 0;
        b.a = (Math.random() - 0.5) * 1.2;
      });
      wake();
    }
    function settleStatic() {
      // Sans animation : on range les stickers en tas propre
      measure(); sizeBodies();
      var x = 0, y = H;
      bodies.forEach(function (b) {
        if (x + b.r * 2 > W) { x = 0; y -= 2 * b.r + 10; }
        b.x = x + b.r + 6; b.y = y - b.r - 6; x += b.r * 2 + 10;
        b.vx = b.vy = 0;
      });
      paint();
    }

    function stepPhys(dt) {
      var n = bodies.length, i, j;
      for (i = 0; i < n; i++) {
        var b = bodies[i];
        if (b.held) { b.vx = 0; b.vy = 0; continue; }
        b.vy += G * dt;
        b.x += b.vx * dt; b.y += b.vy * dt;
        if (b.y + b.r > H) { b.y = H - b.r; if (b.vy > 0) b.vy *= -REST; b.vx *= 0.96; if (Math.abs(b.vy) < 30) b.vy = 0; }
        if (b.y - b.r < -360) { b.y = -360 + b.r; b.vy = Math.abs(b.vy) * 0.3; }
        if (b.x - b.r < 0) { b.x = b.r; b.vx = Math.abs(b.vx) * REST; }
        if (b.x + b.r > W) { b.x = W - b.r; b.vx = -Math.abs(b.vx) * REST; }
        var floor = b.y + b.r >= H - 1;
        b.a += ((b.vx * dt) / b.r) * 0.45;
        if (floor && Math.abs(b.vx) < 60) { b.a = b.a % (Math.PI * 2); if (b.a > Math.PI) b.a -= Math.PI * 2; if (b.a < -Math.PI) b.a += Math.PI * 2; b.a *= 0.94; }
      }
      for (i = 0; i < n; i++) {
        for (j = i + 1; j < n; j++) {
          var A = bodies[i], B = bodies[j];
          var dx = B.x - A.x, dy = B.y - A.y, d2 = dx * dx + dy * dy, rr = A.r + B.r;
          if (d2 >= rr * rr || d2 === 0) continue;
          var d = Math.sqrt(d2), nx = dx / d, ny = dy / d, ov = rr - d;
          var wa = A.held ? 0 : B.held ? 1 : 0.5, wb = B.held ? 0 : A.held ? 1 : 0.5;
          A.x -= nx * ov * wa; A.y -= ny * ov * wa;
          B.x += nx * ov * wb; B.y += ny * ov * wb;
          var rv = (B.vx - A.vx) * nx + (B.vy - A.vy) * ny;
          if (rv < 0) {
            var imp = -(1 + REST) * rv / 2;
            if (!A.held) { A.vx -= imp * nx * (B.held ? 2 : 1); A.vy -= imp * ny * (B.held ? 2 : 1); }
            if (!B.held) { B.vx += imp * nx * (A.held ? 2 : 1); B.vy += imp * ny * (A.held ? 2 : 1); }
            // un peu de frottement entre stickers
            var tx = -ny, ty = nx, tv = (B.vx - A.vx) * tx + (B.vy - A.vy) * ty;
            if (!A.held) { A.vx += tv * tx * 0.05; A.vy += tv * ty * 0.05; }
            if (!B.held) { B.vx -= tv * tx * 0.05; B.vy -= tv * ty * 0.05; }
          }
        }
      }
    }
    function walls() {
      bodies.forEach(function (b) {
        if (b.held) return;
        if (b.x - b.r < 0) b.x = b.r;
        if (b.x + b.r > W) b.x = W - b.r;
        if (b.y + b.r > H) b.y = H - b.r;
      });
    }
    function paint() {
      bodies.forEach(function (b) {
        b.el.style.transform = "translate3d(" + (b.x - b.r).toFixed(1) + "px," + (b.y - b.r).toFixed(1) + "px,0) rotate(" + b.a.toFixed(3) + "rad)";
      });
    }
    function tick(dt) {
      var sub = 3, h = dt / sub;
      for (var k = 0; k < sub; k++) { stepPhys(h); walls(); }
      paint();
      var energy = 0, held = false;
      bodies.forEach(function (b) { energy += Math.abs(b.vx) + Math.abs(b.vy); if (b.held) held = true; });
      calm = energy < 40 && !held ? calm + dt : 0;
      if (calm > 0.3) bodies.forEach(function (b) { if (Math.abs(b.a) > 0.01) { b.a *= 0.9; calm = 0.3; } });
      if (calm > 0.8) { running = false; return false; }
      return true;
    }
    function wake() { calm = 0; if (!running) { running = true; addTask(tick); } }

    $(".board__shake", board).addEventListener("click", function () {
      if (reduce) return;
      bodies.forEach(function (b) { b.vy = -900 - Math.random() * 900; b.vx = (Math.random() - 0.5) * 1600; });
      wake();
    });

    onView(board, function (vis) {
      if (!vis || started) return;
      started = true;
      if (reduce) settleStatic(); else drop();
    }, { threshold: 0.3 });
    var rt;
    window.addEventListener("resize", function () {
      clearTimeout(rt);
      rt = setTimeout(function () { measure(); sizeBodies(); bodies.forEach(function (b) { b.x = clamp(b.x, b.r, W - b.r); b.y = Math.min(b.y, H - b.r); }); wake(); }, 120);
    });
    measure(); sizeBodies();
    bodies.forEach(function (b, i) { b.x = W / 2; b.y = -200 - i * 50; });
    paint();
    renderProof();
    langHooks.push(renderProof);
  })();

  /* ---------- 9. Parcours ---------- */
  (function path() {
    var sec = $("#path"), track = $("#track"), svg = $(".path__line", track), line = $("#trackline");
    var stops = [], len = 0, maxShift = 0, active = false;

    function render() {
      stops.forEach(function (s) { s.remove(); });
      var end = $(".path__end", track); if (end) end.remove();
      stops = NJ.TIMELINE.map(function (s) {
        var tx = L(s);
        var n = el("article", { class: "stop" + (s.now ? " stop--now" : "") + (s.next ? " stop--next" : "") }, [
          el("p", { class: "stop__when", text: L(s.when) }),
          el("h3", { class: "stop__t", text: tx.t }),
          el("p", { class: "stop__d", text: tx.d }),
          s.now ? el("span", { class: "stop__flag", text: t("path.now") }) : null,
          s.next ? el("span", { class: "stop__flag", text: t("path.next") }) : null
        ]);
        track.appendChild(n);
        return n;
      });
      track.appendChild(el("span", { class: "path__end", "aria-hidden": "true" }));
      measure();
    }

    function measure() {
      var small = mqSmall.matches;
      active = !small && !reduce;
      if (!active) { sec.style.height = ""; track.style.transform = ""; stops.forEach(function (s) { s.style.opacity = ""; }); return; }
      var view = $(".path__view", sec).clientWidth;
      var tw = track.scrollWidth;
      maxShift = Math.max(0, tw - view);
      sec.style.height = (window.innerHeight + maxShift + 200) + "px";
      // Tracé : une courbe qui passe par le centre de chaque billet
      svg.setAttribute("width", String(tw)); svg.setAttribute("height", String(track.clientHeight));
      svg.style.width = tw + "px";
      var pts = stops.map(function (s) { return { x: s.offsetLeft + s.offsetWidth / 2, y: s.offsetTop + s.offsetHeight / 2 + (stops.indexOf(s) % 2 ? 48 : -48) }; });
      if (!pts.length) return;
      var d = "M " + (pts[0].x - 400) + " " + pts[0].y;
      pts.forEach(function (p, i) {
        var prev = i ? pts[i - 1] : { x: pts[0].x - 400, y: pts[0].y };
        var mx = (prev.x + p.x) / 2;
        d += " C " + mx + " " + prev.y + ", " + mx + " " + p.y + ", " + p.x + " " + p.y;
      });
      d += " L " + (tw + 200) + " " + pts[pts.length - 1].y;
      line.setAttribute("d", d);
      len = line.getTotalLength();
      line.style.strokeDasharray = len + " " + len;
      update();
    }

    function update() {
      if (!active) return;
      var r = sec.getBoundingClientRect();
      var total = sec.offsetHeight - window.innerHeight;
      var p = clamp(-r.top / (total || 1), 0, 1);
      var shift = p * maxShift;
      track.style.transform = "translate3d(" + (-shift).toFixed(1) + "px,0,0)";
      var view = $(".path__view", sec).clientWidth;
      var lit = shift + view * 0.62;
      var tw = track.scrollWidth || 1;
      line.style.strokeDashoffset = String(len * (1 - clamp((lit + 400) / (tw + 600), 0, 1)));
      stops.forEach(function (s) {
        var on = s.offsetLeft + s.offsetWidth * 0.3 < lit;
        s.style.opacity = on ? "1" : "0.35";
      });
    }

    render();
    window.addEventListener("scroll", function () { if (active) requestAnimationFrame(update); }, { passive: true });
    var rt;
    window.addEventListener("resize", function () { clearTimeout(rt); rt = setTimeout(measure, 150); });
    if (mqSmall.addEventListener) mqSmall.addEventListener("change", measure);
    if (doc.fonts && doc.fonts.ready) doc.fonts.ready.then(measure);
    langHooks.push(render);
  })();

  /* ---------- 10. À propos ---------- */
  (function about() {
    var ul = $("#traits");
    function render() {
      ul.textContent = "";
      (t("about.t") || []).forEach(function (s) { ul.appendChild(el("li", { text: s })); });
    }
    render(); langHooks.push(render);

    var ph = $("[data-tilt]");
    if (ph && fine && !reduce) {
      ph.addEventListener("pointermove", function (e) {
        var r = ph.getBoundingClientRect();
        var x = (e.clientX - r.left) / r.width - 0.5, y = (e.clientY - r.top) / r.height - 0.5;
        ph.style.transform = "perspective(900px) rotateY(" + (x * 10).toFixed(2) + "deg) rotateX(" + (-y * 10).toFixed(2) + "deg) rotate(-1deg)";
      });
      ph.addEventListener("pointerleave", function () { ph.style.transform = ""; });
    }
  })();

  /* ---------- Tampons « Pourquoi moi » ---------- */
  (function stamps() {
    var list = $$("[data-stamp]"), why = $("#why"), done = false;
    if (!list.length) return;
    onView($(".stamps"), function (vis) {
      if (!vis || done) return;
      done = true;
      list.forEach(function (s, i) {
        setTimeout(function () {
          s.classList.add("is-hit");
          if (!reduce) { why.classList.remove("is-shake"); void why.offsetWidth; why.classList.add("is-shake"); }
        }, reduce ? 0 : 150 + i * 200);
      });
    }, { threshold: 0.4 });
    if (!reduce) list.forEach(function (s) { s.style.opacity = "0"; s.addEventListener("animationstart", function () { s.style.opacity = ""; }); });
  })();

  /* ---------- Apparitions ---------- */
  $$("[data-reveal]").forEach(function (n) {
    var io = onView(n, function (vis) { if (vis) { n.classList.add("is-in"); if (io) io.disconnect(); } }, { threshold: 0.2 });
  });

  /* ---------- Boutons aimantés ---------- */
  if (fine && !reduce) {
    doc.addEventListener("pointermove", function (e) {
      var b = e.target.closest && e.target.closest("[data-magnet]");
      $$("[data-magnet].is-mag").forEach(function (m) { if (m !== b) { m.classList.remove("is-mag"); m.style.transform = ""; } });
      if (!b) return;
      var r = b.getBoundingClientRect();
      var x = e.clientX - (r.left + r.width / 2), y = e.clientY - (r.top + r.height / 2);
      b.classList.add("is-mag");
      b.style.transform = "translate(" + (x * 0.22).toFixed(1) + "px," + (y * 0.3).toFixed(1) + "px)";
    });
  }

  /* ---------- Curseur ---------- */
  (function cursor() {
    if (!fine || reduce) return;
    var c = $(".cursor"), lab = $(".cursor__label", c);
    var x = -100, y = -100, cx = -100, cy = -100, key = null;
    doc.addEventListener("pointermove", function (e) {
      x = e.clientX; y = e.clientY;
      c.classList.add("is-on");
      var tg = e.target.closest && e.target.closest("[data-cursor]");
      var k = tg ? tg.getAttribute("data-cursor") : null;
      if (k !== key) {
        key = k;
        c.classList.toggle("has-label", !!k);
        lab.textContent = k ? t(k) : "";
      }
    });
    doc.addEventListener("pointerleave", function () { c.classList.remove("is-on"); });
    addTask(function () {
      cx = lerp(cx, x, 0.25); cy = lerp(cy, y, 0.25);
      c.style.transform = "translate3d(" + cx.toFixed(1) + "px," + cy.toFixed(1) + "px,0)";
    });
    langHooks.push(function () { if (key) lab.textContent = t(key); });
  })();

  /* ---------- Contact ---------- */
  (function contact() {
    var C = NJ.CONTACT;
    var EMAIL = [C.user, C.host].join("@"); // assemblé ici pour gêner les robots
    var addr = $("#mail-addr"), btn = $("#mail-btn"), wa = $("#wa-link");
    addr.textContent = EMAIL;
    function setWa() { wa.href = "https://wa.me/" + C.whatsapp + "?text=" + encodeURIComponent(t("wa.text")); }
    setWa(); langHooks.push(setWa);
    btn.addEventListener("click", function () {
      function ok() {
        toast(t("toast.copy"));
        var h = $(".mail__hint", btn); h.textContent = t("contact.copied");
        setTimeout(function () { h.textContent = t("contact.copy"); }, 2200);
      }
      if (navigator.clipboard && window.isSecureContext) navigator.clipboard.writeText(EMAIL).then(ok, function () { location.href = "mailto:" + EMAIL; });
      else location.href = "mailto:" + EMAIL;
    });

    var form = $("#note"), msg = $("#note-msg"), done = $("#note-done"), plane = $("#plane"), send = $("#send");
    var emailRe = /^[^\s@]{1,64}@[^\s@]{1,190}\.[^\s@]{2,24}$/;
    var sending = false;

    function validate() {
      var bad = [];
      var f = form.elements;
      [["name", function (v) { return v.length >= 2; }], ["email", function (v) { return emailRe.test(v); }], ["message", function (v) { return v.length >= 10; }]].forEach(function (pair) {
        var input = f[pair[0]], v = input.value.trim();
        var good = pair[1](v);
        input.closest(".field").classList.toggle("is-bad", !good);
        input.setAttribute("aria-invalid", String(!good));
        if (!good) bad.push(input);
      });
      return bad;
    }
    function say(k, isBad) { msg.textContent = k ? t(k) : ""; msg.classList.toggle("is-bad", !!isBad); }

    function fold() {
      // Le mot se plie en avion, puis s'envole
      return new Promise(function (resolve) {
        if (reduce) { form.style.visibility = "hidden"; resolve(); return; }
        var r = form.getBoundingClientRect(), z = form.parentNode.getBoundingClientRect();
        var a = form.animate([
          { clipPath: "polygon(0% 0%, 100% 0%, 100% 100%, 0% 100%)", opacity: 1 },
          { clipPath: "polygon(50% 0%, 100% 40%, 50% 100%, 0% 40%)", opacity: 1, offset: 0.5 },
          { clipPath: "polygon(50% 30%, 70% 50%, 50% 70%, 30% 50%)", opacity: 0, transform: "scale(.3) rotate(20deg)" }
        ], { duration: 520, easing: "cubic-bezier(.65,0,.35,1)", fill: "forwards" });
        a.onfinish = function () {
          form.style.visibility = "hidden";
          plane.style.left = (r.left - z.left + r.width / 2) + "px";
          plane.style.top = (r.top - z.top + r.height / 2) + "px";
          var fly = plane.animate([
            { opacity: 0, transform: "translate(0,0) rotate(0deg) scale(.6)" },
            { opacity: 1, transform: "translate(-40px,30px) rotate(-10deg) scale(1)", offset: 0.15 },
            { opacity: 1, transform: "translate(160px,-120px) rotate(-4deg) scale(1)", offset: 0.55 },
            { opacity: 0, transform: "translate(" + (window.innerWidth) + "px,-" + (window.innerHeight * 0.8) + "px) rotate(8deg) scale(.7)" }
          ], { duration: 1300, easing: "cubic-bezier(.45,0,.25,1)" });
          fly.onfinish = resolve;
        };
      });
    }
    function unfold() {
      form.getAnimations().forEach(function (a) { a.cancel(); });
      form.style.visibility = "";
      if (!reduce) form.animate([{ opacity: 0, transform: "translateY(30px) rotate(-6deg)" }, { opacity: 1, transform: "rotate(-2deg)" }], { duration: 600, easing: "cubic-bezier(.22,1,.36,1)" });
    }

    function submit() {
      if (sending) return;
      var bad = validate();
      if (bad.length) { say("form.invalid", true); bad[0].focus(); shakeNote(); return false; }
      if (form.elements._gotcha.value) return false; // robot
      var lastSent = parseInt(store("nj-sent") || "0", 10);
      if (Date.now() - lastSent < 60000) { say("form.wait", true); return false; }
      sending = true; send.setAttribute("aria-disabled", "true"); say("form.sending");
      var f = form.elements;
      var data = new FormData();
      data.set("name", f.name.value.trim().slice(0, 80));
      data.set("email", f.email.value.trim().slice(0, 120));
      data.set("subject", t("form.s." + (form.querySelector("input[name=subject]:checked") || { value: "other" }).value));
      data.set("message", f.message.value.trim().slice(0, 2000));
      data.set("_subject", "Portfolio · " + data.get("subject") + " · " + data.get("name"));
      var req = fetch(C.formspree, { method: "POST", body: data, headers: { Accept: "application/json" }, credentials: "omit", referrerPolicy: "no-referrer" })
        .then(function (r) { if (!r.ok) throw new Error("http"); return true; });
      var flight = fold();
      Promise.all([req, flight]).then(function () {
        store("nj-sent", String(Date.now()));
        form.reset(); say(null);
        done.hidden = false;
        if (!reduce) done.animate([{ opacity: 0, transform: "scale(.9)" }, { opacity: 1, transform: "none" }], { duration: 500, easing: "cubic-bezier(.34,1.56,.64,1)" });
      }).catch(function () {
        return flight.then(function () { return new Promise(function (r) { setTimeout(r, 250); }); }).then(function () {
          unfold(); say("form.err", true);
        });
      }).then(function () { sending = false; send.removeAttribute("aria-disabled"); });
      return true;
    }
    form.addEventListener("submit", function (e) { e.preventDefault(); submit(); });
    send.addEventListener("click", function () { submit(); });
    $$("input", form).forEach(function (i) { i.addEventListener("keydown", function (e) { if (e.key === "Enter" && i.type !== "radio") { e.preventDefault(); submit(); } }); });
    $("#note-again").addEventListener("click", function () { done.hidden = true; unfold(); form.elements.name.focus(); });
    $$("input, textarea", form).forEach(function (i) { i.addEventListener("input", function () { i.closest(".field") && i.closest(".field").classList.remove("is-bad"); }); });

    // Attraper le mot par sa poignée et le lancer vers le haut pour l'envoyer
    var grip = $(".note__grip", form);
    grip.setAttribute("data-cursor", "cursor.grab");
    var th = new Throwable(form, {
      handle: grip, spin: false, k: 40, c: 6,
      onRelease: function (s) {
        if (s.vy < -1100 || s.y < -160) {
          var ok = submit();
          if (ok) { s.x = s.y = s.vx = s.vy = 0; s.paint(); return false; }
        }
        return true;
      }
    });
    function shakeNote() {
      if (reduce) return;
      th.vx = 900; th.x = 0; th.release();
    }
  })();

  /* ---------- Démarrage ---------- */
  applyLang();
  try {
    console.log("%cN'Goran Junior%c  Curieux du code ? Tout est sur github.com/njdev154", "font:700 14px sans-serif;color:#2247d1", "color:inherit");
  } catch (e) { /* rien */ }
})();
