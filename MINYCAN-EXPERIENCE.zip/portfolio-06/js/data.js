/* ------------------------------------------------------------
   Contenu du portfolio : projets, compétences, parcours, textes.
   Pour ajouter un projet, copie un bloc de PROJECTS et adapte-le.
   Chaque texte existe en français (fr) et en anglais (en).
   ------------------------------------------------------------ */

var NJ = (window.NJ = window.NJ || {});

NJ.CONTACT = {
  user: "ngoranjunior154",
  host: "gmail.com",
  whatsapp: "2250161506296",
  whatsappLabel: "+225 01 61 50 62 96",
  github: "https://github.com/njdev154",
  linkedin: "https://www.linkedin.com/in/junior-ngoran/",
  formspree: "https://formspree.io/f/mgaevrwr"
};

NJ.PROJECTS = [
  {
    slug: "cibanque",
    name: "CIBANQUE",
    status: "live",
    kind: "front",
    year: "2026",
    stack: ["HTML", "CSS", "JavaScript"],
    cover: "assets/img/cibanque-dashboard.webp",
    gallery: [
      { src: "assets/img/cibanque-accueil.webp", fr: "Accueil", en: "Home" },
      { src: "assets/img/cibanque-login.webp", fr: "Connexion", en: "Sign in" },
      { src: "assets/img/cibanque-dashboard.webp", fr: "Tableau de bord", en: "Dashboard" }
    ],
    demo: "https://njdev154.github.io/cibanque/",
    code: "https://github.com/njdev154/cibanque",
    fr: {
      type: "Projet personnel",
      tagline: "Une banque mobile pensée pour la Côte d'Ivoire : FCFA, virements, factures CIE et SODECI.",
      context: "Un prototype inspiré des services que les Ivoiriens utilisent vraiment : FCFA, Orange Money, Wave, MTN MoMo. Le site est 100 % statique : les données vivent dans le navigateur, la connexion et les transactions sont simulées.",
      shows: [
        "Une interface cohérente sur 8 pages liées : accueil, inscription, connexion, tableau de bord, virements, historique, carte, profil",
        "Inscription et connexion gérées en JavaScript",
        "Données conservées dans le navigateur avec localStorage",
        "Un parcours complet, de l'inscription au virement"
      ],
      learned: [
        "Organiser un projet multi-pages sans perdre la cohérence",
        "Stocker et relire des données avec localStorage",
        "Adapter une interface au contexte local (FCFA, mobile money)"
      ],
      honest: "CIBANQUE n'est pas une banque. Montants fictifs, opérations simulées, aucun mot de passe vérifié par un serveur."
    },
    en: {
      type: "Personal project",
      tagline: "A mobile bank designed for Côte d'Ivoire: CFA francs, transfers, CIE and SODECI bills.",
      context: "A prototype inspired by the services Ivorians actually use: CFA francs, Orange Money, Wave, MTN MoMo. The site is fully static: data lives in the browser, sign-in and transactions are simulated.",
      shows: [
        "A consistent interface across 8 linked pages: home, sign-up, sign-in, dashboard, transfers, history, card, profile",
        "Sign-up and sign-in handled in JavaScript",
        "Data persisted in the browser with localStorage",
        "A complete journey, from sign-up to transfer"
      ],
      learned: [
        "Keeping a multi-page project consistent",
        "Storing and reading data with localStorage",
        "Adapting an interface to the local context (CFA francs, mobile money)"
      ],
      honest: "CIBANQUE is not a bank. Fake amounts, simulated operations, no password checked by a server."
    }
  },
  {
    slug: "dona-ci",
    name: "DONA CI",
    status: "live",
    kind: "front",
    year: "2026",
    stack: ["HTML", "CSS", "JavaScript"],
    cover: "assets/img/dona-accueil.webp",
    gallery: [{ src: "assets/img/dona-accueil.webp", fr: "Accueil", en: "Home" }],
    demo: "https://njdev154.github.io/dona-ci/",
    code: "https://github.com/njdev154/dona-ci",
    fr: {
      type: "Projet personnel",
      tagline: "Mobiliser autour du don de sang : préparer une collecte, comprendre le don, passer à l'action.",
      context: "Le site s'adresse aux entreprises, écoles et associations qui veulent organiser une collecte de sang, et aux visiteurs qui veulent s'impliquer concrètement.",
      shows: [
        "Une identité visuelle construite pour le sujet",
        "Un site multi-pages et responsive",
        "Des parcours selon le profil : organisations, visiteurs, ressources"
      ],
      learned: [
        "Construire une identité visuelle à partir d'un sujet",
        "Hiérarchiser une information sensible pour qu'elle reste claire"
      ],
      honest: "Démonstration de conception : avant une vraie mise en service, les contacts et circuits de collecte doivent être validés avec une structure médicale partenaire."
    },
    en: {
      type: "Personal project",
      tagline: "Rallying people around blood donation: plan a drive, understand donating, take action.",
      context: "Built for companies, schools and associations that want to run a blood drive, and for visitors who want to get involved.",
      shows: [
        "A visual identity built for the subject",
        "A responsive multi-page website",
        "Paths by profile: organisations, visitors, resources"
      ],
      learned: [
        "Building a visual identity from a subject",
        "Structuring sensitive information so it stays clear"
      ],
      honest: "A design demo: before real use, contacts and collection channels must be validated with a medical partner."
    }
  },
  {
    slug: "pigier-connect",
    name: "PIGIER CONNECT",
    status: "live",
    kind: "front",
    year: "2026",
    stack: ["HTML", "CSS", "JavaScript"],
    cover: "assets/img/pigier-accueil.webp",
    gallery: [
      { src: "assets/img/pigier-accueil.webp", fr: "Accueil", en: "Home" },
      { src: "assets/img/pigier-formations.webp", fr: "Recherche de formations", en: "Programme search" }
    ],
    demo: "https://njdev154.github.io/pigier-connect/",
    code: "https://github.com/njdev154/pigier-connect",
    fr: {
      type: "Projet personnel",
      tagline: "Un portail sur les formations : filières, recherche, FAQ et préinscription.",
      context: "Mon premier site mis en ligne. Je l'ai construit pour pratiquer la structure d'un vrai site, la mise en page et les interactions front-end, avec un portail de formations comme sujet.",
      shows: [
        "Une navigation claire entre plusieurs sections",
        "Une mise en page responsive avec Flexbox",
        "Une FAQ interactive et une recherche de formation en JavaScript",
        "Un formulaire de préinscription traité côté client, avec confirmation"
      ],
      learned: [
        "Organiser la navigation d'un site à plusieurs sections",
        "Rendre une interface agréable sur mobile comme sur ordinateur"
      ],
      honest: "Projet personnel, sans affiliation officielle avec l'établissement. Le formulaire ne transmet aucune inscription réelle."
    },
    en: {
      type: "Personal project",
      tagline: "A study-programme portal: courses, search, FAQ and pre-registration.",
      context: "My first website to go live. I built it to practise real site structure, layout and front-end interactions, using a programme portal as the subject.",
      shows: [
        "Clear navigation across several sections",
        "A responsive Flexbox layout",
        "An interactive FAQ and programme search in JavaScript",
        "A client-side pre-registration form with confirmation"
      ],
      learned: [
        "Organising navigation on a multi-section site",
        "Making an interface pleasant on mobile and desktop"
      ],
      honest: "Personal project with no official affiliation with the school. The form does not send any real registration."
    }
  },
  {
    slug: "passerelle",
    name: "PASSERELLE",
    status: "wip",
    kind: "laravel",
    year: "2026",
    stack: ["Laravel", "PHP", "MySQL", "Blade"],
    cover: "assets/img/passerelle-accueil.webp",
    gallery: [{ src: "assets/img/passerelle-accueil.webp", fr: "Accueil", en: "Home" }],
    demo: null,
    code: "https://github.com/njdev154/passerelle",
    fr: {
      type: "Projet full-stack",
      tagline: "Stages et alternance : étudiants, entreprises et établissements sur une même plateforme.",
      context: "Faciliter l'accès à une première expérience : besoins de stage, offres et suivi des candidatures au même endroit. Plus qu'un tableau d'offres : un parcours suivi de bout en bout.",
      shows: [
        "Une application Laravel structurée : routes, vues Blade, formulaires",
        "Une base MySQL avec migrations, relations et données de démonstration",
        "Des espaces pensés pour chaque rôle : étudiant, entreprise, établissement, administration"
      ],
      learned: [
        "Passer du site statique à une vraie application serveur",
        "Modéliser des rôles et des relations dans une base de données"
      ],
      honest: "En construction : rôles, étapes de candidature, validation des offres et suivi restent à finaliser et à tester. Pas encore de démo publique."
    },
    en: {
      type: "Full-stack project",
      tagline: "Internships and work-study: students, companies and schools on one platform.",
      context: "Making a first work experience easier to reach: internship needs, offers and application tracking in one place. More than a job board: a journey followed end to end.",
      shows: [
        "A structured Laravel app: routes, Blade views, forms",
        "A MySQL database with migrations, relations and seed data",
        "Spaces designed for each role: student, company, school, admin"
      ],
      learned: [
        "Moving from static sites to a real server application",
        "Modelling roles and relations in a database"
      ],
      honest: "Under construction: roles, application steps, offer validation and tracking still need finishing and testing. No public demo yet."
    }
  },
  {
    slug: "jeuneavenir-ci",
    name: "JEUNEAVENIR CI",
    status: "wip",
    kind: "front",
    year: "2026",
    stack: ["HTML", "CSS", "JavaScript"],
    cover: "assets/img/jeuneavenir-accueil.webp",
    gallery: [
      { src: "assets/img/jeuneavenir-accueil.webp", fr: "Accueil", en: "Home" },
      { src: "assets/img/jeuneavenir-piliers.webp", fr: "Les 5 piliers", en: "The 5 pillars" }
    ],
    demo: null,
    code: null,
    fr: {
      type: "Projet personnel",
      tagline: "Orientation, mentorat et premiers stages pour les jeunes Ivoiriens, du lycée à l'emploi.",
      context: "Aider un jeune à passer d'une question à des pistes concrètes : filières, établissements, métiers, insertion. Sans prétendre remplacer un conseiller.",
      shows: [
        "Cinq piliers pensés comme un parcours : orientation, découverte, mentorat, insertion pro, espace personnel",
        "Une base front-end avec ses écrans et ses parcours"
      ],
      learned: [
        "Découper un grand sujet en parcours simples",
        "Penser une plateforme avant d'écrire le code"
      ],
      honest: "Exploré en local : contenus, données, comptes et logique serveur restent à construire. Pas encore de démo publique."
    },
    en: {
      type: "Personal project",
      tagline: "Guidance, mentoring and first internships for young Ivorians, from high school to work.",
      context: "Helping a young person go from a question to concrete options: courses, schools, careers, first jobs. Without pretending to replace a counsellor.",
      shows: [
        "Five pillars designed as a journey: guidance, discovery, mentoring, career, personal space",
        "A front-end base with its screens and flows"
      ],
      learned: [
        "Breaking a big subject into simple journeys",
        "Thinking a platform through before writing code"
      ],
      honest: "Explored locally: content, data, accounts and server logic are still to be built. No public demo yet."
    }
  }
];

/* Compétences : chaque techno indique les projets (slug) où elle a servi */
NJ.SKILLS = [
  { id: "html", name: "HTML", uses: ["cibanque", "dona-ci", "pigier-connect", "passerelle", "jeuneavenir-ci"] },
  { id: "css", name: "CSS", uses: ["cibanque", "dona-ci", "pigier-connect", "passerelle", "jeuneavenir-ci"] },
  { id: "js", name: "JavaScript", uses: ["cibanque", "dona-ci", "pigier-connect", "jeuneavenir-ci"] },
  { id: "php", name: "PHP", uses: ["passerelle"] },
  { id: "laravel", name: "Laravel", uses: ["passerelle"] },
  { id: "mysql", name: "MySQL", uses: ["passerelle"] },
  { id: "sqlite", name: "SQLite", uses: [] },
  { id: "tailwind", name: "Tailwind", uses: [] },
  { id: "git", name: "Git", uses: ["cibanque", "dona-ci", "pigier-connect", "passerelle"] },
  { id: "github", name: "GitHub", uses: ["cibanque", "dona-ci", "pigier-connect", "passerelle"] }
];

NJ.TIMELINE = [
  { when: { fr: "2023 – 2024", en: "2023 – 2024" }, fr: { t: "Baccalauréat série D", d: "Collège Le Rodin, Yopougon." }, en: { t: "Baccalaureate, science track", d: "Collège Le Rodin, Yopougon." } },
  { when: { fr: "2024 – 2025", en: "2024 – 2025" }, fr: { t: "Licence 1, IDA", d: "Pigier Côte d'Ivoire. Premières lignes en HTML, CSS, C et SQL." }, en: { t: "Bachelor year 1, App Development", d: "Pigier Côte d'Ivoire. First lines of HTML, CSS, C and SQL." } },
  { when: { fr: "Juin 2025", en: "June 2025" }, fr: { t: "Certifié Microsoft Office Specialist", d: "Excel 2016, délivré par Certiport." }, en: { t: "Microsoft Office Specialist certified", d: "Excel 2016, issued by Certiport." } },
  { when: { fr: "2025 – 2026", en: "2025 – 2026" }, fr: { t: "Licence 2 et BTS IDA", d: "BTS Informatique, option Développeur d'Applications." }, en: { t: "Bachelor year 2 + BTS in App Development", d: "National IT diploma, application developer option." } },
  { when: { fr: "Mars 2026", en: "March 2026" }, fr: { t: "Premier site en ligne", d: "Publié sur GitHub Pages. Trois autres ont suivi." }, en: { t: "First website live", d: "Published on GitHub Pages. Three more followed." } },
  { when: { fr: "Août – nov. 2026", en: "Aug – Nov 2026" }, now: true, fr: { t: "Stage de développement web", d: "YA Consulting, Abidjan." }, en: { t: "Web development internship", d: "YA Consulting, Abidjan." } },
  { when: { fr: "Après le stage", en: "After the internship" }, next: true, fr: { t: "Licence 3, IDA", d: "Pigier Côte d'Ivoire. Cap sur le full-stack." }, en: { t: "Bachelor year 3, App Development", d: "Pigier Côte d'Ivoire. Heading for full-stack." } }
];

NJ.I18N = {
  fr: {
    skip: "Aller au contenu",
    "nav.work": "Projets",
    "nav.why": "Pourquoi moi",
    "nav.skills": "Stack",
    "nav.path": "Parcours",
    "nav.about": "À propos",
    "nav.contact": "Contact",
    "nav.menu": "Menu",
    "nav.close": "Fermer",
    "press.skip": "Passer",
    "hero.kicker": "Développeur web · Abidjan",
    "hero.lead": "Étudiant en BTS IDA à Pigier Côte d'Ivoire. Je construis des sites et des applications web pour des problèmes que je connais : banque mobile, don de sang, orientation, stages.",
    "hero.cta": "Voir les projets",
    "hero.cv": "CV en PDF",
    "hero.status": "En stage chez YA Consulting",
    "hero.status2": "Ouvert aux opportunités",
    "hero.hint": "Attrape une lettre, lance-la",
    "hero.time": "à Abidjan",
    "work.label": "Projets",
    "work.title": "Cinq projets. Trois en ligne.",
    "work.lead": "Chaque fiche dit ce qui marche, ce qui est simulé et ce qui reste à faire.",
    "work.hint": "Attrape la carte du dessus et lance-la : elle revient sous le paquet.",
    "work.deck": "Paquet",
    "work.grid": "Tout voir",
    "work.prev": "Projet précédent",
    "work.next": "Projet suivant",
    "work.open": "Lire l'étude de cas",
    "work.demo": "Voir le site",
    "work.code": "Le code",
    "status.live": "En ligne",
    "status.wip": "En chantier",
    "why.label": "Pourquoi moi",
    "why.title": "Ce que j'apporte à une équipe.",
    "why.n1": "projets construits",
    "why.n2": "sites en ligne",
    "why.n3": "stage en cours",
    "why.n4": "certification Microsoft",
    "why.c1.t": "Je livre.",
    "why.c1.d": "Trois sites publiés sur GitHub Pages, testables tout de suite. Pas de maquettes oubliées dans un dossier.",
    "why.c2.t": "Je pense local.",
    "why.c2.d": "FCFA, mobile money, factures CIE et SODECI : mes interfaces parlent aux gens d'ici.",
    "why.c3.t": "Je dis la vérité sur mon code.",
    "why.c3.d": "Chaque projet affiche ses limites. Vous savez exactement ce que vous regardez.",
    "why.c4.t": "J'apprends en construisant.",
    "why.c4.d": "Des premières balises HTML en 2024 à une application Laravel avec MySQL en 2026.",
    "skills.label": "Stack",
    "skills.title": "Pas de pourcentages. Des preuves.",
    "skills.lead": "Touche un sticker pour voir où je l'ai utilisé. Tu peux aussi les lancer.",
    "skills.pick": "Choisis un sticker",
    "skills.used": "Utilisé dans",
    "skills.none": "Utilisé sur un projet personnel qui n'est pas encore présenté ici.",
    "skills.studied": "Étudié en cours",
    "skills.studied.v": "Langage C, SQL, Merise (MCD, MCT), Linux",
    "skills.office": "Bureautique",
    "skills.office.v": "Excel (certifié Microsoft), Word, Office 365",
    "skills.next": "Prochaines étapes",
    "skills.next.v": "Architecture et qualité du code, tests, sécurité, déploiement",
    "skills.shake": "Secouer",
    "path.label": "Parcours",
    "path.title": "De Yopougon au full-stack.",
    "path.now": "En ce moment",
    "path.next": "Prochaine étape",
    "about.label": "À propos",
    "about.title": "J'apprends en construisant.",
    "about.p1": "Je m'appelle N'Goran Junior. J'ai grandi et je vis à Yopougon. J'étudie le développement d'applications à Pigier Côte d'Ivoire et je suis en stage de développement web chez YA Consulting depuis août 2026.",
    "about.p2": "Chaque projet de ce site m'a fait pratiquer une nouvelle partie du métier, du site statique à l'application Laravel avec base de données. Mon objectif : devenir développeur web full-stack.",
    "about.f.loc": "Basé à",
    "about.f.loc.v": "Yopougon, Abidjan",
    "about.f.study": "Études",
    "about.f.study.v": "BTS IDA · Licence 3",
    "about.f.goal": "Objectif",
    "about.f.goal.v": "Développeur full-stack",
    "about.f.lang": "Langues",
    "about.f.lang.v": "Français · anglais technique",
    "about.method": "Ma façon de travailler",
    "about.m1": "Comprendre le besoin avant d'écrire une ligne de code.",
    "about.m2": "Dire ce qui est réel, ce qui est simulé, ce qui reste à faire.",
    "about.m3": "Progresser projet après projet, sans prétendre tout maîtriser.",
    "about.traits": "Mes points forts",
    "about.t": ["Apprend vite", "Rigoureux et ponctuel", "Esprit d'équipe", "Curieux", "Persévérant"],
    "about.off": "Hors du code",
    "about.off.v": "Jeux vidéo, sport, lecture, veille tech.",
    "cert.title": "Microsoft Office Specialist : Excel 2016",
    "cert.meta": "Certiport · juin 2025",
    "cert.cta": "Voir le certificat",
    "contact.label": "Contact",
    "contact.title": "Un stage, un projet, une question ?",
    "contact.lead": "Écris-moi. Je réponds vite, en français ou en anglais.",
    "contact.copy": "Copier l'email",
    "contact.copied": "Email copié",
    "contact.time": "Il est",
    "contact.time2": "à Abidjan",
    "form.title": "Un petit mot",
    "form.name": "Ton nom",
    "form.email": "Ton email",
    "form.subject": "C'est pour",
    "form.message": "Ton message",
    "form.s.stage": "Un stage",
    "form.s.job": "Un emploi",
    "form.s.project": "Un site",
    "form.s.other": "Autre chose",
    "form.send": "Envoyer",
    "form.fling": "ou lance le mot vers le haut",
    "form.sending": "Envoi…",
    "form.ok": "Message parti. Je te réponds très vite.",
    "form.again": "Écrire un autre mot",
    "form.err": "L'envoi a échoué. Écris-moi directement par email.",
    "form.invalid": "Il manque quelque chose : regarde les champs en rose.",
    "form.wait": "Un message vient de partir. Attends une minute avant d'en renvoyer un.",
    "wa.text": "Bonjour Junior, je viens de voir ton portfolio.",
    "foot.made": "Conçu et codé à la main à Yopougon.",
    "foot.top": "Retour en haut",
    "cs.close": "Fermer",
    "cs.type": "Type",
    "cs.stack": "Technos",
    "cs.status": "Statut",
    "cs.context": "Le contexte",
    "cs.shows": "Ce que ça démontre",
    "cs.learned": "Ce que j'ai appris",
    "cs.honest": "Honnêtement",
    "cs.nodemo": "Pas encore de démo publique.",
    "cs.next": "Projet suivant",
    "cursor.throw": "Lance",
    "cursor.open": "Ouvrir",
    "cursor.grab": "Attrape",
    "toast.copy": "Email copié dans le presse-papiers"
  },
  en: {
    skip: "Skip to content",
    "nav.work": "Work",
    "nav.why": "Why me",
    "nav.skills": "Stack",
    "nav.path": "Journey",
    "nav.about": "About",
    "nav.contact": "Contact",
    "nav.menu": "Menu",
    "nav.close": "Close",
    "press.skip": "Skip",
    "hero.kicker": "Web developer · Abidjan",
    "hero.lead": "Application development student at Pigier Côte d'Ivoire. I build websites and web apps for problems I know first-hand: mobile banking, blood donation, career guidance, internships.",
    "hero.cta": "See the work",
    "hero.cv": "CV (PDF)",
    "hero.status": "Interning at YA Consulting",
    "hero.status2": "Open to opportunities",
    "hero.hint": "Grab a letter, throw it",
    "hero.time": "in Abidjan",
    "work.label": "Work",
    "work.title": "Five projects. Three live.",
    "work.lead": "Each case study says what works, what is simulated and what is left to do.",
    "work.hint": "Grab the top card and throw it: it comes back under the pile.",
    "work.deck": "Pile",
    "work.grid": "See all",
    "work.prev": "Previous project",
    "work.next": "Next project",
    "work.open": "Read the case study",
    "work.demo": "Visit site",
    "work.code": "Code",
    "status.live": "Live",
    "status.wip": "In progress",
    "why.label": "Why me",
    "why.title": "What I bring to a team.",
    "why.n1": "projects built",
    "why.n2": "sites live",
    "why.n3": "internship ongoing",
    "why.n4": "Microsoft certification",
    "why.c1.t": "I ship.",
    "why.c1.d": "Three sites published on GitHub Pages, ready to test right now. No mockups forgotten in a folder.",
    "why.c2.t": "I think local.",
    "why.c2.d": "CFA francs, mobile money, CIE and SODECI bills: my interfaces speak to people here.",
    "why.c3.t": "I tell the truth about my code.",
    "why.c3.d": "Every project shows its limits. You know exactly what you are looking at.",
    "why.c4.t": "I learn by building.",
    "why.c4.d": "From my first HTML tags in 2024 to a Laravel app with MySQL in 2026.",
    "skills.label": "Stack",
    "skills.title": "No percentages. Proof.",
    "skills.lead": "Tap a sticker to see where I used it. You can throw them too.",
    "skills.pick": "Pick a sticker",
    "skills.used": "Used in",
    "skills.none": "Used on a personal project that isn't showcased here yet.",
    "skills.studied": "Studied in class",
    "skills.studied.v": "C language, SQL, Merise modelling, Linux",
    "skills.office": "Office",
    "skills.office.v": "Excel (Microsoft certified), Word, Office 365",
    "skills.next": "Next steps",
    "skills.next.v": "Code architecture and quality, testing, security, deployment",
    "skills.shake": "Shake",
    "path.label": "Journey",
    "path.title": "From Yopougon to full-stack.",
    "path.now": "Right now",
    "path.next": "Next step",
    "about.label": "About",
    "about.title": "I learn by building.",
    "about.p1": "I'm N'Goran Junior, born and raised in Yopougon, Abidjan. I study application development at Pigier Côte d'Ivoire and I've been a web development intern at YA Consulting since August 2026.",
    "about.p2": "Every project on this site taught me a new part of the craft, from static sites to a Laravel app with a database. My goal: becoming a full-stack web developer.",
    "about.f.loc": "Based in",
    "about.f.loc.v": "Yopougon, Abidjan",
    "about.f.study": "Studies",
    "about.f.study.v": "BTS in App Dev · Bachelor year 3",
    "about.f.goal": "Goal",
    "about.f.goal.v": "Full-stack developer",
    "about.f.lang": "Languages",
    "about.f.lang.v": "French · technical English",
    "about.method": "How I work",
    "about.m1": "Understand the need before writing a line of code.",
    "about.m2": "Say what is real, what is simulated, what is left to do.",
    "about.m3": "Grow project after project, without pretending to know it all.",
    "about.traits": "Strengths",
    "about.t": ["Fast learner", "Rigorous and punctual", "Team player", "Curious", "Persistent"],
    "about.off": "Off the keyboard",
    "about.off.v": "Video games, sport, reading, tech watch.",
    "cert.title": "Microsoft Office Specialist: Excel 2016",
    "cert.meta": "Certiport · June 2025",
    "cert.cta": "View certificate",
    "contact.label": "Contact",
    "contact.title": "An internship, a project, a question?",
    "contact.lead": "Write to me. I reply fast, in French or English.",
    "contact.copy": "Copy email",
    "contact.copied": "Email copied",
    "contact.time": "It's",
    "contact.time2": "in Abidjan",
    "form.title": "A quick note",
    "form.name": "Your name",
    "form.email": "Your email",
    "form.subject": "It's about",
    "form.message": "Your message",
    "form.s.stage": "An internship",
    "form.s.job": "A job",
    "form.s.project": "A website",
    "form.s.other": "Something else",
    "form.send": "Send",
    "form.fling": "or throw the note upwards",
    "form.sending": "Sending…",
    "form.ok": "Message sent. I'll get back to you soon.",
    "form.again": "Write another note",
    "form.err": "Sending failed. Email me directly instead.",
    "form.invalid": "Something's missing: check the pink fields.",
    "form.wait": "A message just went out. Wait a minute before sending another.",
    "wa.text": "Hi Junior, I just saw your portfolio.",
    "foot.made": "Designed and hand-coded in Yopougon.",
    "foot.top": "Back to top",
    "cs.close": "Close",
    "cs.type": "Type",
    "cs.stack": "Stack",
    "cs.status": "Status",
    "cs.context": "Context",
    "cs.shows": "What it shows",
    "cs.learned": "What I learned",
    "cs.honest": "Honestly",
    "cs.nodemo": "No public demo yet.",
    "cs.next": "Next project",
    "cursor.throw": "Throw",
    "cursor.open": "Open",
    "cursor.grab": "Grab",
    "toast.copy": "Email copied to clipboard"
  }
};
