# N'Goran Junior · Portfolio

Portfolio de **N'Goran Junior**, étudiant en BTS IDA à Pigier Côte d'Ivoire et stagiaire développeur web chez YA Consulting, à Abidjan.

**En ligne :** https://njdev154.github.io/portfolio-06/

## L'idée

Le site est pensé comme une affiche imprimée en risographie à Yopougon : deux encres, un bleu outremer et un rose fluo, sur un papier blanc. Là où les deux encres se superposent, on obtient du violet. Quand on défile vite, la plaque rose se décale un peu, comme une impression mal calée.

## Ce qu'on peut faire dessus

- **L'affiche** : mon portrait est redessiné en trame de points roses. Les points réagissent au curseur et respirent doucement. Chaque lettre de mon nom s'attrape et se lance : elle revient à sa place.
- **Les projets** : un paquet de cartes. On attrape la carte du dessus, on la lance, elle tourne et revient sous le paquet comme un boomerang. Le bouton « Tout voir » affiche tous les projets en grille.
- **L'étude de cas** : contexte, ce que le projet démontre, ce que j'ai appris, et une partie « Honnêtement » qui dit ce qui est réel, simulé ou à faire. Chaque fiche a son lien (`#/projets/cibanque`).
- **Pourquoi moi** : les chiffres tombent comme des coups de tampon.
- **La stack** : une planche de stickers avec une vraie petite physique. On les attrape, on les lance, on secoue la planche. Toucher un sticker montre dans quels projets je l'ai utilisé.
- **Le parcours** : une bande de billets qui défile à l'horizontale pendant qu'on descend.
- **Le contact** : un petit mot à remplir. À l'envoi, il se plie en avion en papier et s'envole. On peut aussi l'attraper par sa poignée et le lancer vers le haut.
- Partout : FR / EN, curseur encre, boutons aimantés, menu mobile plein écran, page 404 « mal imprimée ».

## Structure

```
index.html          la page
404.html            page d'erreur (GitHub Pages)
css/style.css       tout le design (couleurs et polices en haut du fichier)
js/data.js          LE CONTENU : projets, compétences, parcours, textes FR/EN
js/icons.js         logos des technos
js/main.js          interactions et animations (JavaScript pur)
assets/img/         portrait, captures des projets, icônes, image de partage
assets/docs/        CV et certificat (PDF)
```

## Modifier le contenu

Presque tout se change dans **`js/data.js`**, sans toucher au HTML :

- **Ajouter un projet** : copie un bloc dans `NJ.PROJECTS`, change le `slug`, les textes `fr` / `en` et les images. Il apparaît tout seul dans le paquet, la grille et les études de cas.
- **Compétences** : `NJ.SKILLS`, avec les projets (slug) où chaque techno a servi.
- **Parcours** : `NJ.TIMELINE`. `now: true` = étape en cours, `next: true` = prochaine étape.
- **Textes** : `NJ.I18N.fr` et `NJ.I18N.en`.
- **CV** : remplace `assets/docs/CV-NGoran-Junior.pdf` en gardant le même nom.

## Mettre en ligne (GitHub Pages)

1. Crée un dépôt nommé exactement **`njdev154.github.io`**.
2. Mets tout le contenu de ce dossier à la racine du dépôt, y compris le fichier `.nojekyll`.
3. *Settings → Pages → Deploy from a branch → `main` / `(root)`*.
4. Le site est en ligne en une ou deux minutes sur https://njdev154.github.io/portfolio-06/.

Si tu utilises un autre nom de dépôt, mets à jour les adresses dans `index.html` (canonical, og:url, og:image), `robots.txt`, `sitemap.xml`, et les liens qui commencent par `/` dans `404.html`.

Tester en local : `python3 -m http.server` dans le dossier, puis http://localhost:8000.

## Sécurité

- Aucune librairie, aucun tracker. Seules ressources externes : les polices Google Fonts et l'envoi du formulaire (Formspree).
- Content Security Policy stricte : le navigateur n'exécute que les scripts du site.
- Tout le texte affiché passe par `textContent`, jamais inséré en HTML brut. Les liens externes sont filtrés (https uniquement) et ouverts en `noopener noreferrer`.
- Formulaire : validation, longueurs maximales, piège à robots, un message par minute au plus.
- L'adresse email est assemblée en JavaScript pour gêner les robots collecteurs.
- Aucun secret dans le code. L'identifiant Formspree est public par nature.
- `prefers-reduced-motion` respecté : les animations se coupent pour ceux qui le demandent.

## Crédits

Polices : Bricolage Grotesque, Bitter, IBM Plex Mono (licence SIL Open Font).
Code, textes et photos : © N'Goran Junior. Merci de ne pas réutiliser le portrait ni les contenus sans accord.
