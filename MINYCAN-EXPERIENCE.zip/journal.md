# Journal du projet

## 2026-11-01 — Copilot
- Préparé un workflow GitHub Actions qui extrait l'archive du site et la publie sur GitHub Pages.
- Mis à jour les instructions de redéploiement pour correspondre au workflow.
- À faire : ajouter l'archive au dépôt, activer GitHub Actions comme source Pages, puis vérifier le déploiement et les neuf URL.
