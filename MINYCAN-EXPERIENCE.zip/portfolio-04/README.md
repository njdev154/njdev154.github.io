# Ligne NJ · Portfolio de N'Goran Junior

Portfolio de **N'Goran Junior**, étudiant en développement d'applications à Pigier Côte d'Ivoire et stagiaire développeur web à Abidjan.

> Le concept : le portfolio est une **ligne de transport** qui part de Yopougon.
> Chaque projet est un arrêt, le parcours est le tracé, la destination est « Full-Stack ».
> Les couleurs viennent d'Abidjan : la lagune Ébrié la nuit, l'orange des taxis compteurs, le béton clair des chantiers.

**En ligne :** https://njdev154.github.io/portfolio-04/

---

## Ce qu'il y a dedans

| Partie | Ce qui bouge |
| --- | --- |
| Intro | Tableau des départs à palettes (split-flap), rideau en lamelles. Une seule fois par visite, on peut la passer. |
| Hero | Nom géant en police variable : les lettres s'élargissent près du curseur, une vague les traverse quand rien ne bouge. Tableau qui change de rôle. Lumières de la ville sur canvas qui réagissent à la souris. Ligne des projets avec un train qui dessert chaque arrêt. Heure d'Abidjan en direct. |
| Bandeau | Technos en défilement : la vitesse et l'inclinaison suivent le scroll. |
| Projets | Filtres avec animation FLIP, cartes inclinables en 3D, curseur contextuel, statut « en ligne » / « en chantier ». |
| Étude de cas | Fenêtre qui s'ouvre en cercle depuis le clic, URL partageable (`#/projets/cibanque`), section « Honnêtement » (réel / simulé / à faire), projet suivant. |
| Compétences | Matrice technos × projets : survoler une techno montre où elle a servi. Pas de pourcentages. |
| Parcours | La ligne se dessine au scroll, le train avance, les stations s'allument. |
| À propos | Portrait bichrome qui se colore au survol, parallaxe, démarche, points forts, certification. |
| Contact | Email copiable en un clic, liens directs, formulaire Formspree. |
| Partout | Curseur personnalisé, boutons magnétiques, barre de progression avec train, en-tête qui change de couleur selon la section, FR / EN, menu mobile plein écran, page 404 « Arrêt inconnu ». |

## Structure

```
index.html            la page (une seule page, rapide à charger)
404.html              page d'erreur servie par GitHub Pages
css/style.css         tout le design (tokens en haut du fichier)
css/noscript.css      affichage propre si JavaScript est désactivé
js/data.js            LE CONTENU : projets, compétences, parcours, textes FR/EN
js/main.js            interactions et animations (JavaScript pur, commenté)
assets/fonts/         polices hébergées sur le site (Archivo, JetBrains Mono)
assets/img/           logo, captures (WebP), portrait, image de partage
assets/docs/          CV et certificat (PDF)
```

## Modifier le contenu

Presque tout se change dans **`js/data.js`**, sans toucher au HTML :

- **Ajouter un projet** : copie un bloc dans `NJ.PROJECTS`, change `slug`, `code` (3 lettres), les textes `fr` / `en`, les images. Il apparaît automatiquement dans les cartes, la ligne du hero, la matrice et les études de cas.
- **Compétences** : `NJ.SKILLS`, indique les codes des projets qui utilisent chaque techno.
- **Parcours** : `NJ.TIMELINE`. `now: true` = étape en cours, `next: true` = prochaine étape.
- **Textes de l'interface** : `NJ.I18N.fr` et `NJ.I18N.en`.
- **CV** : remplace `assets/docs/CV-NGoran-Junior.pdf` en gardant le même nom.
- **Couleurs / polices** : section « Tokens » en haut de `css/style.css`.

## Mettre en ligne (gratuit, GitHub Pages)

1. Crée un dépôt nommé **exactement** `njdev154.github.io`.
2. Mets tous les fichiers de ce dossier à la racine du dépôt (y compris `.nojekyll`).
3. *Settings → Pages → Deploy from a branch → `main` / `(root)`*.
4. Le site est en ligne en une minute sur https://njdev154.github.io/portfolio-04/.

> Si tu préfères un autre nom de dépôt (ex. `portfolio`), le site marchera, mais pense à
> mettre à jour les adresses dans `index.html` (canonical, og:url, og:image), `robots.txt`
> et `sitemap.xml`, et les liens commençant par `/` dans `404.html`.

Tester en local : `python3 -m http.server` dans le dossier, puis http://localhost:8000.

## Sécurité

- **Aucune dépendance, aucun script externe** : pas de CDN, pas de librairie, pas de tracker. Rien qui puisse être piraté en amont.
- **Content Security Policy stricte** : le navigateur n'exécute que les fichiers du site lui-même. Seul Formspree est autorisé, uniquement pour envoyer le formulaire.
- **Polices hébergées sur le site** : aucune requête vers Google, meilleure confidentialité pour les visiteurs.
- **Liens externes** en `rel="noopener noreferrer"`, politique de référent stricte.
- **Formulaire** : validation, longueurs maximales, piège à robots (honeypot), un message par minute maximum, aucune donnée insérée en HTML brut.
- **Contenu échappé** avant affichage, liens filtrés (https uniquement).
- **Aucun secret** dans le code. L'identifiant Formspree est public par nature. Ne publie jamais de fichier `.env`.
- Email assemblé en JavaScript pour gêner les robots collecteurs. Un seul numéro affiché (WhatsApp).
- Respect de `prefers-reduced-motion` : animations coupées pour ceux qui le demandent.

## Accessibilité et performance

Lien d'évitement, navigation au clavier complète (fenêtre d'étude de cas avec piège de focus et touche Échap), états de focus visibles, textes alternatifs FR/EN, contrastes vérifiés, animations en pause quand elles sont hors écran, images en WebP et chargement différé, polices allégées (woff2, sous-ensemble latin).

## Licence

Code sous licence MIT (voir `LICENSE`). Les textes, photos, captures, CV et certificat appartiennent à N'Goran Junior et ne sont pas réutilisables. Polices sous licence SIL Open Font License.
