/* ================================================================
   LIGNE NJ — Interactions et motion design
   ----------------------------------------------------------------
   JavaScript "vanilla" : aucune librairie, aucun script externe.
   Chaque bloc est indépendant et commenté.
   Sommaire :
     1. Outils            8. Projets (cartes, filtres)
     2. Langue FR / EN    9. Matrice des compétences
     3. Intro             10. Parcours (ligne au scroll)
     4. Hero (lettres,    11. Étude de cas (fenêtre + URL)
        tableau, ligne)   12. Contact (email, formulaire)
     5. Lumières (canvas) 13. Curseur + boutons magnétiques
     6. Bandeau           14. Défilement (en-tête, progression)
     7. Révélations       15. Démarrage
   ================================================================ */
(function () {
  "use strict";

  /* ---------- 1. Outils ---------- */
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
  var clamp = function (v, a, b) { return Math.min(b, Math.max(a, v)); };
  var lerp = function (a, b, t) { return a + (b - a) * t; };
  var reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  var finePointer = window.matchMedia("(hover: hover) and (pointer: fine)").matches;
  var root = document.documentElement;
  var DATA = window.NJ || {};
  var PROJECTS = DATA.PROJECTS || [];

  // Échappe le texte avant de l'insérer dans du HTML (hygiène anti-injection)
  function esc(str) {
    return String(str == null ? "" : str)
      .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;").replace(/'/g, "&#39;");
  }
  // N'autorise que des liens https ou internes (jamais "javascript:")
  function safeUrl(u) {
    if (!u) return null;
    return /^https:\/\//.test(u) || /^(assets|#)/.test(u) ? u : null;
  }
  function el(tag, cls, html) {
    var n = document.createElement(tag);
    if (cls) n.className = cls;
    if (html != null) n.innerHTML = html;
    return n;
  }

  /* ---------- 2. Langue FR / EN ---------- */
  var lang = "fr";
  try {
    var saved = localStorage.getItem("p04-nj-lang");
    if (saved === "fr" || saved === "en") lang = saved;
  } catch (e) { /* stockage indisponible : on garde le français */ }

  function t(key) {
    var d = DATA.I18N && DATA.I18N[lang];
    return d && d[key] != null ? d[key] : (DATA.I18N && DATA.I18N.fr[key]) || key;
  }
  function P(p) { return p[lang] || p.fr; }

  var langListeners = [];
  function applyLang() {
    root.lang = lang;
    $$("[data-i18n]").forEach(function (n) {
      var v = t(n.getAttribute("data-i18n"));
      if (typeof v !== "string") return;
      n.textContent = v;
      if (n.hasAttribute("data-split")) splitWords(n, true);
    });
    $$(".lang-btn").forEach(function (b) {
      var on = b.getAttribute("data-lang") === lang;
      b.classList.toggle("is-active", on);
      b.setAttribute("aria-pressed", on ? "true" : "false");
    });
    document.title = lang === "en"
      ? "N'Goran Junior · Junior web developer in Abidjan"
      : "N'Goran Junior · Développeur web junior à Abidjan";
    langListeners.forEach(function (fn) { fn(); });
  }
  function initLang() {
    $$(".lang-btn").forEach(function (b) {
      b.addEventListener("click", function () {
        var next = b.getAttribute("data-lang");
        if (next === lang) return;
        lang = next;
        try { localStorage.setItem("p04-nj-lang", lang); } catch (e) {}
        applyLang();
      });
    });
  }

  /* ---------- Split-flap : le tableau des départs ---------- */
  var FLAP_CHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
  function flapTo(container, text, opts) {
    opts = opts || {};
    var len = Math.max(text.length, opts.length || 0);
    var cells = $$(".flap-cell", container);
    while (cells.length < len) {
      var c = el("span", "flap-cell");
      c.textContent = "";
      container.appendChild(c);
      cells.push(c);
    }
    while (cells.length > len) container.removeChild(cells.pop());
    container.setAttribute("aria-label", text);
    var timers = [];
    cells.forEach(function (cell, i) {
      var target = text[i] || " ";
      cell.setAttribute("aria-hidden", "true");
      if (reduced) {
        cell.textContent = target;
        cell.classList.toggle("is-space", target === " ");
        cell.classList.add("is-set");
        return;
      }
      if (cell.textContent === target && target !== "") return;
      var flips = 3 + Math.floor(Math.random() * 5);
      var n = 0;
      cell.classList.remove("is-set", "is-space");
      var start = setTimeout(function tick() {
        n++;
        cell.classList.remove("is-flip");
        void cell.offsetWidth; // relance l'animation
        cell.classList.add("is-flip");
        if (n >= flips) {
          cell.textContent = target;
          cell.classList.toggle("is-space", target === " ");
          if (opts.mark) cell.classList.add("is-set");
          return;
        }
        cell.textContent = FLAP_CHARS[Math.floor(Math.random() * FLAP_CHARS.length)];
        timers.push(setTimeout(tick, 55));
      }, (opts.delay || 0) + i * 32);
      timers.push(start);
    });
    return timers;
  }

  /* ---------- 3. Intro ---------- */
  function runIntro(done) {
    var intro = $("#intro");
    var seen = false;
    try { seen = sessionStorage.getItem("p04-nj-intro") === "1"; } catch (e) {}
    if (!intro || reduced || seen || slugFromHash()) {
      if (intro) intro.classList.add("is-gone");
      done();
      return;
    }
    root.classList.add("lock");
    var finished = false;
    $$(".flap", intro).forEach(function (f, row) {
      flapTo(f, f.getAttribute("data-flap"), { delay: 120 + row * 180, mark: true, length: 10 });
    });
    function leave() {
      if (finished) return;
      finished = true;
      try { sessionStorage.setItem("p04-nj-intro", "1"); } catch (e) {}
      intro.classList.add("is-leaving");
      root.classList.remove("lock");
      setTimeout(done, 220);
      setTimeout(function () { intro.classList.add("is-gone"); }, 1150);
    }
    var auto = setTimeout(leave, 2100);
    $(".intro-skip", intro).addEventListener("click", function () { clearTimeout(auto); leave(); });
    window.addEventListener("keydown", function k() { clearTimeout(auto); leave(); window.removeEventListener("keydown", k); });
  }

  /* ---------- 4. Hero ---------- */
  var letters = [];
  function initLetters() {
    $$("[data-letters]").forEach(function (word) {
      var txt = word.textContent;
      word.textContent = "";
      word.setAttribute("aria-hidden", "true");
      txt.split("").forEach(function (ch, i) {
        var mask = el("span", "letter-mask");
        var l = el("span", "letter");
        l.textContent = ch;
        mask.appendChild(l);
        word.appendChild(mask);
        letters.push({ node: l, f: 0, i: letters.length });
      });
    });
    root.classList.add("is-loading");
  }
  function lettersIn() {
    letters.forEach(function (L, i) {
      L.node.style.transitionDelay = (i * 45) + "ms";
      L.node.classList.add("is-in");
    });
    requestAnimationFrame(function () { root.classList.remove("is-loading"); });
    setTimeout(function () {
      letters.forEach(function (L) { L.node.style.transitionDelay = "0ms"; L.node.classList.remove("is-in"); });
    }, 1800);
  }

  // Les lettres respirent : elles s'élargissent près du curseur,
  // et une vague lente les traverse quand personne ne bouge.
  var pointer = { x: -9999, y: -9999, last: 0 };
  function animateLetters(time) {
    if (reduced || !letters.length) return;
    var hero = $(".hero");
    var heroVisible = true;
    var io = new IntersectionObserver(function (e) { heroVisible = e[0].isIntersecting; });
    io.observe(hero);
    var rects = [];
    var measure = function () { rects = letters.map(function (L) { var r = L.node.getBoundingClientRect(); return { x: r.left + r.width / 2, y: r.top + r.height / 2 }; }); };
    var lastMeasure = 0;
    function frame(now) {
      requestAnimationFrame(frame);
      if (!heroVisible) return;
      if (now - lastMeasure > 300) { measure(); lastMeasure = now; }
      var idle = now - pointer.last > 2500;
      letters.forEach(function (L, i) {
        var r = rects[i];
        var target = 0;
        if (r) {
          var dx = pointer.x - r.x, dy = pointer.y - r.y;
          var d = Math.sqrt(dx * dx + dy * dy);
          target = clamp(1 - d / 320, 0, 1);
        }
        if (idle || !finePointer) {
          var wave = 0.5 + 0.5 * Math.sin(now / 900 - i * 0.55);
          target = Math.max(target, Math.pow(wave, 3) * 0.55);
        }
        L.f = lerp(L.f, target, 0.09);
        L.node.style.setProperty("--w", (106 + L.f * 19).toFixed(1) + "%");
        L.node.style.setProperty("--wg", Math.round(780 + L.f * 120));
      });
    }
    requestAnimationFrame(frame);
  }

  // Le tableau qui change de rôle toutes les 3 secondes
  function initBoard() {
    var board = $("#role-board");
    if (!board) return;
    var idx = 0;
    var maxLen = function () { return t("hero.board").reduce(function (m, w) { return Math.max(m, w.length); }, 0); };
    board.textContent = "";
    var show = function () { flapTo(board, t("hero.board")[idx], { length: maxLen() }); };
    show();
    langListeners.push(function () { idx = 0; show(); });
    if (reduced) return;
    setInterval(function () {
      if (document.hidden) return;
      idx = (idx + 1) % t("hero.board").length;
      show();
    }, 3400);
  }

  // La ligne : arrêts = projets, un train les dessert en boucle
  var route = { stops: [] };
  function initRoute() {
    var wrap = $(".route");
    var path = $("#route-path");
    var list = $("#route-stops");
    if (!wrap || !path || !list) return;
    var stops = [{ code: "YOP", name: { fr: "Départ : Yopougon", en: "Departure: Yopougon" }, href: "#parcours" }]
      .concat(PROJECTS.map(function (p) { return { code: p.code, project: p }; }))
      .concat([{ code: "F-S", name: { fr: "Terminus : Full-Stack", en: "Terminus: Full-Stack" }, href: "#contact", end: true }]);
    var total = path.getTotalLength();
    list.innerHTML = "";
    route.stops = stops.map(function (s, i) {
      var li = el("li", "stop" + (s.end ? " stop--end" : ""));
      var btn = el(s.project ? "a" : "a", "stop-btn");
      btn.href = s.project ? "#/projets/" + s.project.slug : s.href;
      btn.setAttribute("data-cursor", s.code);
      if (s.project) btn.setAttribute("data-open", s.project.slug);
      var code = el("span", "stop-code"); code.textContent = s.code;
      var name = el("span", "stop-name");
      li.appendChild(btn); li.appendChild(code); li.appendChild(name);
      list.appendChild(li);
      li.style.transitionDelay = (300 + i * 120) + "ms";
      return { li: li, btn: btn, name: name, data: s, at: (0.06 + (i / (stops.length - 1)) * 0.86) * total };
    });
    function labels() {
      route.stops.forEach(function (s) {
        var label = s.data.project ? s.data.project.name : P(s.data.name);
        s.name.textContent = label;
        s.btn.setAttribute("aria-label", label);
      });
    }
    labels();
    langListeners.push(labels);

    var box = { w: 1, h: 140 };
    function toScreen(pt) { return { x: (pt.x / 1600) * box.w, y: (pt.y / 140) * box.h }; }
    function place() {
      var r = wrap.getBoundingClientRect();
      box.w = r.width; box.h = $(".route-svg").getBoundingClientRect().height;
      route.stops.forEach(function (s) {
        var p = toScreen(path.getPointAtLength(s.at));
        s.li.style.left = p.x + "px";
        s.li.style.top = p.y + "px";
      });
    }
    place();
    window.addEventListener("resize", place);
    route.place = place;

    // Le train
    var train = $(".route-train");
    if (reduced || !train) return;
    var seg = 0, phase = "dwell", phaseStart = 0;
    var TRAVEL = 1500, DWELL = 700;
    var ease = function (x) { return x < 0.5 ? 4 * x * x * x : 1 - Math.pow(-2 * x + 2, 3) / 2; };
    var visible = true;
    new IntersectionObserver(function (e) { visible = e[0].isIntersecting; }).observe(wrap);
    function setTrain(len) {
      var a = toScreen(path.getPointAtLength(len));
      var b = toScreen(path.getPointAtLength(Math.min(total, len + 2)));
      var ang = Math.atan2(b.y - a.y, b.x - a.x) * 180 / Math.PI;
      train.style.transform = "translate(" + a.x.toFixed(1) + "px," + a.y.toFixed(1) + "px) rotate(" + ang.toFixed(1) + "deg)";
    }
    function light(i) { route.stops.forEach(function (s, j) { s.li.classList.toggle("is-lit", j === i); }); }
    setTrain(route.stops[0].at); light(0);
    function frame(now) {
      requestAnimationFrame(frame);
      if (!visible || !wrap.classList.contains("is-drawn")) { phaseStart = now; return; }
      if (!phaseStart) phaseStart = now;
      var el2 = now - phaseStart;
      if (phase === "dwell") {
        if (el2 > DWELL) { phase = "travel"; phaseStart = now; }
      } else {
        var from = route.stops[seg].at;
        var nextIdx = (seg + 1) % route.stops.length;
        if (nextIdx === 0) { // retour au départ
          seg = 0; phase = "dwell"; phaseStart = now; setTrain(route.stops[0].at); light(0); return;
        }
        var to = route.stops[nextIdx].at;
        var k = clamp(el2 / TRAVEL, 0, 1);
        setTrain(lerp(from, to, ease(k)));
        if (k >= 1) { seg = nextIdx; phase = "dwell"; phaseStart = now; light(seg); }
      }
    }
    requestAnimationFrame(frame);
  }

  // Heure d'Abidjan en direct
  function initClock() {
    var fmt;
    try { fmt = new Intl.DateTimeFormat("fr-FR", { timeZone: "Africa/Abidjan", hour: "2-digit", minute: "2-digit" }); }
    catch (e) { fmt = { format: function (d) { return d.toISOString().slice(11, 16); } }; }
    var tick = function () { var v = fmt.format(new Date()); $$("[data-clock]").forEach(function (n) { n.textContent = v; }); };
    tick();
    setInterval(tick, 10000);
  }

  /* ---------- 5. Lumières de la ville (canvas du hero) ---------- */
  function initLights() {
    var canvas = $(".hero-lights");
    if (!canvas || !canvas.getContext) return;
    var ctx = canvas.getContext("2d");
    var dpr = Math.min(window.devicePixelRatio || 1, 2);
    var dots = [], W = 0, H = 0, visible = true;
    var GAP = 28;
    function build() {
      var r = canvas.getBoundingClientRect();
      W = r.width; H = r.height;
      canvas.width = Math.round(W * dpr); canvas.height = Math.round(H * dpr);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      dots = [];
      for (var y = GAP / 2; y < H; y += GAP) {
        for (var x = GAP / 2; x < W; x += GAP) {
          var warm = Math.random() < 0.035;
          dots.push({ x: x + (Math.random() - 0.5) * 6, y: y + (Math.random() - 0.5) * 6, p: Math.random() * Math.PI * 2, s: 0.4 + Math.random() * 1.2, warm: warm, g: 0 });
        }
      }
    }
    var rect = { left: 0, top: 0 };
    function draw(now) {
      ctx.clearRect(0, 0, W, H);
      var px = pointer.x - rect.left, py = pointer.y - rect.top;
      for (var i = 0; i < dots.length; i++) {
        var d = dots[i];
        var dx = d.x - px, dy = d.y - py;
        var near = clamp(1 - Math.sqrt(dx * dx + dy * dy) / 200, 0, 1);
        d.g = lerp(d.g, near, 0.12);
        var tw = reduced ? 0.5 : 0.5 + 0.5 * Math.sin(now / 1000 * d.s + d.p);
        var a = (d.warm ? 0.32 : 0.09) + tw * (d.warm ? 0.45 : 0.08) + d.g * 0.7;
        var rad = (d.warm ? 1.5 : 1.05) + d.g * 1.6;
        ctx.fillStyle = d.warm || d.g > 0.3 ? "rgba(240,138,36," + a.toFixed(3) + ")" : "rgba(242,238,228," + a.toFixed(3) + ")";
        ctx.beginPath(); ctx.arc(d.x, d.y, rad, 0, 6.2832); ctx.fill();
      }
    }
    function frame(now) {
      requestAnimationFrame(frame);
      if (!visible || document.hidden) return;
      var r = canvas.getBoundingClientRect(); rect.left = r.left; rect.top = r.top;
      draw(now);
    }
    build();
    var rt;
    window.addEventListener("resize", function () { clearTimeout(rt); rt = setTimeout(function () { build(); if (reduced) draw(0); }, 150); });
    new IntersectionObserver(function (e) { visible = e[0].isIntersecting; }).observe(canvas);
    if (reduced) { draw(0); return; }
    requestAnimationFrame(frame);
  }

  /* ---------- 6. Bandeau des technos (vitesse liée au scroll) ---------- */
  function initMarquee() {
    var track = $("#marquee");
    if (!track) return;
    var original = track.innerHTML;
    track.innerHTML = original + original + original + original;
    if (reduced) return;
    var x = 0, dir = -1, vel = 0, lastY = window.scrollY, half = 0;
    var measure = function () { half = track.scrollWidth / 2; };
    measure();
    window.addEventListener("resize", measure);
    var visible = true;
    new IntersectionObserver(function (e) { visible = e[0].isIntersecting; }).observe(track);
    var last = performance.now();
    function frame(now) {
      requestAnimationFrame(frame);
      var dt = Math.min(64, now - last); last = now;
      var y = window.scrollY, dy = y - lastY; lastY = y;
      if (dy !== 0) dir = dy > 0 ? -1 : 1;
      vel = lerp(vel, Math.abs(dy) * 0.9, 0.1);
      if (!visible) return;
      x += dir * (0.06 * dt + vel);
      if (x <= -half) x += half;
      if (x > 0) x -= half;
      track.style.transform = "translate3d(" + x.toFixed(2) + "px,0,0) skewX(" + (clamp(vel, 0, 24) * -dir * -0.35).toFixed(2) + "deg)";
    }
    requestAnimationFrame(frame);
  }

  /* ---------- 7. Révélations au scroll ---------- */
  function splitWords(node, force) {
    if (node.dataset.splitDone && !force) return;
    var text = node.textContent.trim();
    node.setAttribute("aria-label", text);
    node.textContent = "";
    text.split(/[ \t\n\r]+/).forEach(function (w, i) {
      var outer = el("span", "w");
      var inner = el("span");
      inner.textContent = w;
      outer.setAttribute("aria-hidden", "true");
      inner.style.setProperty("--i", i);
      outer.appendChild(inner);
      node.appendChild(outer);
      node.appendChild(document.createTextNode(" "));
    });
    node.dataset.splitDone = "1";
  }
  var revealIO, pending = [];
  // Filet de sécurité : si on saute une section (lien, scroll rapide),
  // tout ce qui est déjà passé au-dessus de l'écran s'affiche.
  function flushReveal() {
    if (!pending.length) return;
    var vh = window.innerHeight;
    pending = pending.filter(function (n) {
      if (n.classList.contains("is-in")) return false;
      if (n.getBoundingClientRect().top < vh * 0.9) { n.classList.add("is-in"); if (revealIO) revealIO.unobserve(n); return false; }
      return true;
    });
  }
  function observeReveal(nodes) {
    if (!revealIO) {
      revealIO = new IntersectionObserver(function (entries) {
        entries.forEach(function (e) {
          if (e.isIntersecting) { e.target.classList.add("is-in"); revealIO.unobserve(e.target); }
        });
      }, { rootMargin: "0px 0px -10% 0px", threshold: 0.08 });
    }
    nodes.forEach(function (n) { if (reduced) n.classList.add("is-in"); else { revealIO.observe(n); pending.push(n); } });
  }
  function initReveal() {
    $$("[data-split]").forEach(function (n) { splitWords(n); });
    observeReveal($$("[data-split], [data-reveal], .matrix, .cert"));
  }

  /* ---------- 8. Projets ---------- */
  var currentFilter = "all";
  function renderCards() {
    var list = $("#cards");
    if (!list) return;
    list.innerHTML = "";
    PROJECTS.forEach(function (p, i) {
      var c = P(p);
      var li = el("li", "card");
      li.setAttribute("data-cats", p.cats.join(" "));
      li.setAttribute("data-reveal", "");
      li.style.setProperty("--d", (i % 3) * 90);
      li.innerHTML =
        '<a class="card-link" href="#/projets/' + esc(p.slug) + '" data-open="' + esc(p.slug) + '" data-cursor="' + esc(t("card.open")) + '">' +
          '<span class="card-arrow" aria-hidden="true">↗</span>' +
          '<div class="card-media"><img src="' + esc(p.cover) + '" alt="' + esc(p.name + " : " + (p.gallery[0] ? P(p.gallery[0]) || p.gallery[0][lang] : "")) + '" loading="lazy" decoding="async"></div>' +
          '<div class="card-body">' +
            '<div class="card-top"><span class="roundel">' + esc(p.code) + '</span><span class="badge' + (p.status === "wip" ? " badge--wip" : "") + '">' + esc(c.statusLabel) + "</span></div>" +
            '<h3 class="card-title">' + esc(p.name) + "</h3>" +
            '<p class="card-tag">' + esc(c.tagline) + "</p>" +
            '<ul class="card-stack" aria-label="Technologies">' + p.stack.map(function (s) { return "<li>" + esc(s) + "</li>"; }).join("") + "</ul>" +
          "</div>" +
        "</a>";
      list.appendChild(li);
    });
    // alt de l'image : nom + légende (P() ne marche pas sur gallery, on corrige proprement)
    $$(".card", list).forEach(function (li, i) {
      var g = PROJECTS[i].gallery[0];
      $("img", li).alt = PROJECTS[i].name + " : " + (g ? g[lang] || g.fr : "");
    });
    applyFilter(currentFilter, false);
    observeReveal($$(".card", list));
    bindTilt();
  }

  function applyFilter(f, animate) {
    currentFilter = f;
    var cards = $$("#cards .card");
    var first = cards.map(function (c) { return c.getBoundingClientRect(); });
    cards.forEach(function (c) {
      var show = f === "all" || c.getAttribute("data-cats").split(" ").indexOf(f) !== -1;
      c.classList.toggle("is-hidden", !show);
    });
    // Tailles des cartes selon leur position parmi les cartes visibles
    var vis = cards.filter(function (c) { return !c.classList.contains("is-hidden"); });
    vis.forEach(function (c, i) {
      var size = ["a", "b", "c"][i % 3];
      if (size === "a" && i === vis.length - 1) size = "c"; // carte seule sur sa ligne
      c.setAttribute("data-size", size);
    });
    $$(".chip").forEach(function (b) {
      var on = b.getAttribute("data-filter") === f;
      b.classList.toggle("is-active", on);
      b.setAttribute("aria-pressed", on ? "true" : "false");
    });
    if (!animate || reduced || !Element.prototype.animate) return;
    // Animation FLIP : chaque carte glisse de son ancienne à sa nouvelle place
    cards.forEach(function (c, i) {
      if (c.classList.contains("is-hidden")) return;
      c.classList.add("is-in");
      var last = c.getBoundingClientRect();
      var a = first[i];
      if (!a.width) {
        c.animate([{ opacity: 0, transform: "scale(0.94) translateY(20px)" }, { opacity: 1, transform: "none" }], { duration: 600, easing: "cubic-bezier(.22,.8,.24,1)", delay: i * 40 });
        return;
      }
      var dx = a.left - last.left, dy = a.top - last.top;
      var sx = a.width / last.width, sy = a.height / last.height;
      c.animate([
        { transformOrigin: "top left", transform: "translate(" + dx + "px," + dy + "px) scale(" + sx + "," + sy + ")" },
        { transformOrigin: "top left", transform: "none" }
      ], { duration: 650, easing: "cubic-bezier(.22,.8,.24,1)" });
    });
  }
  function initFilters() {
    $$(".chip").forEach(function (b) {
      b.addEventListener("click", function () { applyFilter(b.getAttribute("data-filter"), true); });
    });
  }

  // Inclinaison 3D des cartes et parallaxe de la capture
  function bindTilt() {
    if (!finePointer || reduced) return;
    $$(".card-link").forEach(function (a) {
      var img = $(".card-media img", a);
      a.addEventListener("pointermove", function (e) {
        var r = a.getBoundingClientRect();
        var nx = (e.clientX - r.left) / r.width - 0.5;
        var ny = (e.clientY - r.top) / r.height - 0.5;
        a.style.setProperty("--ry", (nx * 5).toFixed(2) + "deg");
        a.style.setProperty("--rx", (-ny * 5).toFixed(2) + "deg");
        img.style.setProperty("--px", (-nx * 14).toFixed(1) + "px");
        img.style.setProperty("--py", (-ny * 10).toFixed(1) + "px");
      });
      a.addEventListener("pointerleave", function () {
        a.style.setProperty("--ry", "0deg"); a.style.setProperty("--rx", "0deg");
        img.style.setProperty("--px", "0px"); img.style.setProperty("--py", "0px");
      });
    });
  }

  /* ---------- 9. Matrice des compétences ---------- */
  function renderMatrix() {
    var m = $("#matrix");
    if (!m) return;
    var codes = PROJECTS.map(function (p) { return p.code; });
    m.style.setProperty("--cols", codes.length);
    var html = '<div class="mx-row mx-head" role="row"><div class="mx-cell" role="columnheader"><span class="sr">Technologie</span></div>';
    PROJECTS.forEach(function (p) {
      html += '<div class="mx-cell" role="columnheader" data-col="' + esc(p.code) + '"><button type="button" data-open="' + esc(p.slug) + '" data-cursor="' + esc(p.code) + '" aria-label="' + esc(p.name) + '">' + esc(p.code) + "</button></div>";
    });
    html += '<div class="mx-cell mx-count" role="columnheader">Σ</div></div>';
    var groups = { web: "skills.web", back: "skills.back", data: "skills.data", tools: "skills.tools" };
    var lastGroup = null, dotIndex = 0;
    (DATA.SKILLS || []).forEach(function (s, r) {
      if (s.group !== lastGroup) {
        html += '<div class="mx-row" role="row"><div class="mx-cell mx-group" role="cell">' + esc(t(groups[s.group])) + "</div></div>";
        lastGroup = s.group;
      }
      html += '<div class="mx-row" role="row" data-row="' + r + '"><div class="mx-cell mx-name" role="rowheader" data-row="' + r + '" tabindex="0">' + esc(s.name) + "</div>";
      codes.forEach(function (code) {
        var used = s.uses.indexOf(code) !== -1;
        html += '<div class="mx-cell mx-use' + (used ? " is-used" : "") + '" role="cell" data-row="' + r + '" data-col="' + esc(code) + '" data-code="' + esc(code) + '">' +
          (used ? '<span class="mx-dot" data-i="' + (dotIndex++) + '"></span><span class="sr">' + esc(code) + "</span>" : '<span class="mx-none" aria-hidden="true"></span>') + "</div>";
      });
      html += '<div class="mx-cell mx-count" role="cell" data-row="' + r + '">' + s.uses.length + "</div></div>";
    });
    m.innerHTML = html;
    $$(".mx-dot", m).forEach(function (d) { d.style.setProperty("--i", d.getAttribute("data-i")); });

    function clear() { m.classList.remove("is-hovering"); $$(".is-on", m).forEach(function (n) { n.classList.remove("is-on"); }); }
    function hiRow(r) {
      clear(); m.classList.add("is-hovering");
      $$('[data-row="' + r + '"]', m).forEach(function (n) {
        if (n.classList.contains("mx-use") && !n.classList.contains("is-used")) return;
        n.classList.add("is-on");
        var col = n.getAttribute("data-col");
        if (col) $('.mx-head [data-col="' + col + '"]', m).classList.add("is-on");
      });
    }
    function hiCol(col) {
      clear(); m.classList.add("is-hovering");
      $$('.mx-head [data-col="' + col + '"]', m).forEach(function (n) { n.classList.add("is-on"); });
      $$('.mx-use.is-used[data-col="' + col + '"]', m).forEach(function (n) {
        n.classList.add("is-on");
        var r = n.getAttribute("data-row");
        $('.mx-name[data-row="' + r + '"]', m).classList.add("is-on");
      });
    }
    $$(".mx-name, .mx-use, .mx-count", m).forEach(function (n) {
      var r = n.getAttribute("data-row");
      n.addEventListener("pointerenter", function () { hiRow(r); });
      n.addEventListener("focus", function () { hiRow(r); });
      n.addEventListener("blur", clear);
    });
    $$(".mx-head [data-col]", m).forEach(function (n) {
      var c = n.getAttribute("data-col");
      n.addEventListener("pointerenter", function () { hiCol(c); });
      var b = $("button", n);
      b.addEventListener("focus", function () { hiCol(c); });
      b.addEventListener("blur", clear);
    });
    m.addEventListener("pointerleave", clear);
  }

  /* ---------- 10. Parcours ---------- */
  function renderStations() {
    var list = $("#stations");
    if (!list) return;
    list.innerHTML = "";
    (DATA.TIMELINE || []).forEach(function (s, i) {
      var c = P(s);
      var li = el("li", "station" + (s.now ? " station--now" : "") + (s.next ? " station--next" : ""));
      li.setAttribute("data-reveal", "");
      li.innerHTML =
        '<span class="station-when">' + esc(s.when[lang] || s.when.fr) + "</span>" +
        '<h3 class="station-title">' + esc(c.t) + "</h3>" +
        '<p class="station-desc">' + esc(c.d) + "</p>" +
        (s.now ? '<span class="station-pill">' + esc(t("path.now")) + "</span>" : "") +
        (s.next ? '<span class="station-pill">' + esc(t("path.next")) + "</span>" : "");
      list.appendChild(li);
    });
    observeReveal($$(".station", list));
  }
  function updatePath() {
    var line = $(".path-line");
    if (!line) return;
    var r = line.getBoundingClientRect();
    var vh = window.innerHeight;
    var p = clamp((vh * 0.55 - r.top) / r.height, 0, 1);
    line.style.setProperty("--p", p.toFixed(4));
    var y = p * r.height;
    $(".path-train", line).style.setProperty("--y", y.toFixed(1) + "px");
    $$(".station", line).forEach(function (s) { s.classList.toggle("is-passed", s.offsetTop + 10 <= y); });
  }

  /* ---------- 11. Étude de cas ---------- */
  var sheet, sheetBody, lastTrigger = null, pushedByUs = false;
  function caseHTML(p) {
    var c = P(p);
    var idx = PROJECTS.indexOf(p);
    var next = PROJECTS[(idx + 1) % PROJECTS.length];
    var demo = safeUrl(p.demo), code = safeUrl(p.code_url);
    var h = "";
    h += '<header class="cs-head">';
    h += '<p class="kicker" data-reveal>' + esc(p.code) + " · " + esc(c.type) + "</p>";
    h += '<h2 class="cs-title" id="sheet-title" data-reveal>' + esc(p.name) + "</h2>";
    h += '<p class="cs-tagline" data-reveal>' + esc(c.tagline) + "</p>";
    h += '<dl class="cs-meta" data-reveal>' +
      "<div><dt>" + esc(t("cs.type")) + "</dt><dd>" + esc(c.type) + "</dd></div>" +
      "<div><dt>" + esc(t("cs.stack")) + "</dt><dd>" + esc(p.stack.join(" · ")) + "</dd></div>" +
      "<div><dt>" + esc(t("cs.status")) + '</dt><dd><span class="badge' + (p.status === "wip" ? " badge--wip" : "") + '">' + esc(c.statusLabel) + "</span></dd></div></dl>";
    h += '<div class="cs-links" data-reveal>';
    if (demo) h += '<a class="btn btn-taxi" href="' + esc(demo) + '" target="_blank" rel="noopener noreferrer" data-cursor="Live">' + esc(t("cs.demo")) + ' <span aria-hidden="true">↗</span></a>';
    if (code) h += '<a class="btn btn-ghost" href="' + esc(code) + '" target="_blank" rel="noopener noreferrer" data-cursor="Code">' + esc(t("cs.code")) + ' <span aria-hidden="true">↗</span></a>';
    if (!demo) h += '<span class="cs-nodemo">' + esc(t("cs.nodemo")) + "</span>";
    h += "</div></header>";
    h += '<div class="cs-gallery">' + p.gallery.map(function (g, i) {
      return '<figure data-reveal><img src="' + esc(g.src) + '" alt="' + esc(p.name + " : " + (g[lang] || g.fr)) + '" loading="' + (i ? "lazy" : "eager") + '" decoding="async"><figcaption>' + esc(g[lang] || g.fr) + "</figcaption></figure>";
    }).join("") + "</div>";
    h += '<div class="cs-grid">';
    h += '<section class="cs-block" data-reveal><h3 class="h3">' + esc(t("cs.context")) + "</h3><p>" + esc(c.context) + "</p></section>";
    h += '<section class="cs-block" data-reveal><h3 class="h3">' + esc(t("cs.shows")) + '</h3><ul class="cs-list">' + c.shows.map(function (s) { return "<li>" + esc(s) + "</li>"; }).join("") + "</ul></section>";
    h += '<section class="cs-block" data-reveal><h3 class="h3">' + esc(t("cs.learned")) + '</h3><ul class="cs-list">' + c.learned.map(function (s) { return "<li>" + esc(s) + "</li>"; }).join("") + "</ul></section>";
    h += '<section class="cs-honest" data-reveal><h3 class="h3">' + esc(t("cs.limits")) + "</h3><p>" + esc(c.limits) + "</p></section>";
    h += "</div>";
    h += '<button type="button" class="cs-next" data-next="' + esc(next.slug) + '" data-cursor="' + esc(next.code) + '"><span><span class="cs-next-label">' + esc(t("cs.next")) + '</span><span class="cs-next-name">' + esc(next.name) + '</span></span><span class="cs-next-arrow" aria-hidden="true">→</span></button>';
    return h;
  }
  function findProject(slug) { return PROJECTS.filter(function (p) { return p.slug === slug; })[0]; }
  function renderSheet(p) {
    sheetBody.innerHTML = caseHTML(p);
    $("#sheet-code").textContent = p.code + " / " + String(PROJECTS.indexOf(p) + 1).padStart(2, "0");
    var reveals = $$("[data-reveal]", sheetBody);
    reveals.forEach(function (n, i) { n.style.setProperty("--d", Math.min(i, 6) * 70); });
    requestAnimationFrame(function () { requestAnimationFrame(function () { reveals.forEach(function (n) { n.classList.add("is-in"); }); }); });
    $(".cs-next", sheetBody).addEventListener("click", function () {
      var nx = findProject(this.getAttribute("data-next"));
      history.replaceState({ nj: 1 }, "", "#/projets/" + nx.slug);
      $("#sheet-scroll").scrollTo({ top: 0, behavior: reduced ? "auto" : "smooth" });
      setTimeout(function () { renderSheet(nx); $("#sheet-title").focus({ preventScroll: true }); }, reduced ? 0 : 260);
    });
    var title = $("#sheet-title");
    title.setAttribute("tabindex", "-1");
  }
  function openSheet(slug, origin) {
    var p = findProject(slug);
    if (!p) return false;
    if (origin) {
      sheet.style.setProperty("--cx", origin.x + "px");
      sheet.style.setProperty("--cy", origin.y + "px");
    } else {
      sheet.style.setProperty("--cx", "50%");
      sheet.style.setProperty("--cy", "50%");
    }
    renderSheet(p);
    sheet.hidden = false;
    root.classList.add("lock");
    $("#sheet-scroll").scrollTop = 0;
    requestAnimationFrame(function () { requestAnimationFrame(function () { sheet.classList.add("is-open"); }); });
    setTimeout(function () { $("#sheet-close").focus({ preventScroll: true }); }, 60);
    document.title = p.name + " · N'Goran Junior";
    return true;
  }
  function closeSheet() {
    if (sheet.hidden) return;
    sheet.classList.remove("is-open");
    root.classList.remove("lock");
    applyTitle();
    setTimeout(function () { sheet.hidden = true; sheetBody.innerHTML = ""; }, reduced ? 0 : 800);
    if (lastTrigger && document.body.contains(lastTrigger)) lastTrigger.focus({ preventScroll: true });
  }
  function applyTitle() {
    document.title = lang === "en" ? "N'Goran Junior · Junior web developer in Abidjan" : "N'Goran Junior · Développeur web junior à Abidjan";
  }
  function slugFromHash() {
    var m = location.hash.match(/^#\/projets\/([a-z0-9-]+)$/);
    return m ? m[1] : null;
  }
  function initSheet() {
    sheet = $("#sheet"); sheetBody = $("#sheet-body");
    if (!sheet) return;
    document.addEventListener("click", function (e) {
      var a = e.target.closest("[data-open]");
      if (!a) return;
      e.preventDefault();
      lastTrigger = a;
      var slug = a.getAttribute("data-open");
      if (openSheet(slug, { x: e.clientX || window.innerWidth / 2, y: e.clientY || window.innerHeight / 2 })) {
        history.pushState({ nj: 1 }, "", "#/projets/" + slug);
        pushedByUs = true;
      }
    });
    $("#sheet-close").addEventListener("click", function () {
      if (pushedByUs) { pushedByUs = false; history.back(); }
      else { history.replaceState(null, "", location.pathname + location.search); closeSheet(); }
    });
    window.addEventListener("popstate", function () {
      var slug = slugFromHash();
      if (slug) openSheet(slug); else { pushedByUs = false; closeSheet(); }
    });
    sheet.addEventListener("keydown", function (e) {
      if (e.key === "Escape") { $("#sheet-close").click(); return; }
      if (e.key !== "Tab") return;
      var f = $$('a[href], button:not([disabled]), [tabindex="0"]', sheet).filter(function (n) { return n.offsetParent !== null; });
      if (!f.length) return;
      var first = f[0], last = f[f.length - 1];
      if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
      else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
    });
    langListeners.push(function () {
      var slug = slugFromHash();
      if (slug && !sheet.hidden) renderSheet(findProject(slug));
    });
    var initial = slugFromHash();
    if (initial) openSheet(initial);
  }

  /* ---------- 12. Contact ---------- */
  var EMAIL = ["ngoranjunior154", "gmail.com"].join("@"); // assemblé ici pour gêner les robots
  function toast(msg) {
    var tEl = $("#toast");
    tEl.textContent = msg;
    tEl.classList.add("is-on");
    clearTimeout(toast._t);
    toast._t = setTimeout(function () { tEl.classList.remove("is-on"); }, 2400);
  }
  function initContact() {
    var addr = $("#mail-addr"), link = $("#mail-link"), btn = $("#mail-btn");
    if (addr) addr.textContent = EMAIL;
    if (link) link.href = "mailto:" + EMAIL;
    if (btn) btn.addEventListener("click", function () {
      var ok = function () {
        toast(t("toast.copy"));
        var hint = $(".mail-hint", btn);
        hint.textContent = t("contact.copied");
        setTimeout(function () { hint.textContent = t("contact.copy"); }, 2000);
      };
      if (navigator.clipboard && window.isSecureContext) navigator.clipboard.writeText(EMAIL).then(ok, function () { location.href = "mailto:" + EMAIL; });
      else location.href = "mailto:" + EMAIL;
    });

    var form = $("#contact-form");
    if (!form) return;
    var status = $("#form-status");
    var send = $(".btn-send", form);
    var label = $(".btn-send-label", form);
    var emailRe = /^[^\s@]{1,64}@[^\s@]{1,190}\.[^\s@]{2,24}$/;
    function setStatus(msg, kind) { status.textContent = msg; status.className = "form-status" + (kind ? " is-" + kind : ""); }
    form.addEventListener("submit", function (e) {
      e.preventDefault();
      var fields = {
        name: form.elements.name, email: form.elements.email, message: form.elements.message
      };
      var bad = false;
      Object.keys(fields).forEach(function (k) {
        var f = fields[k], v = f.value.trim();
        var invalid = (k === "name" && (v.length < 2 || v.length > 80)) ||
          (k === "email" && !emailRe.test(v)) ||
          (k === "message" && (v.length < 10 || v.length > 2000));
        f.closest(".field").classList.toggle("is-invalid", invalid);
        f.setAttribute("aria-invalid", invalid ? "true" : "false");
        if (invalid) bad = true;
      });
      if (bad) { setStatus(t("form.invalid"), "err"); var firstBad = $(".is-invalid input, .is-invalid textarea", form); if (firstBad) firstBad.focus(); return; }
      // Piège à robots rempli : on fait semblant que tout va bien
      if (form.elements._gotcha.value) { form.reset(); setStatus(t("form.ok"), "ok"); return; }
      // Anti-spam simple : un message par minute depuis ce navigateur
      try {
        var lastSent = +localStorage.getItem("p04-nj-last-sent") || 0;
        if (Date.now() - lastSent < 60000) { setStatus(t("form.wait"), "err"); return; }
      } catch (err) {}
      send.disabled = true; label.textContent = t("form.sending"); setStatus("", "");
      var data = new FormData(form);
      data.set("name", fields.name.value.trim());
      data.set("email", fields.email.value.trim());
      data.set("message", fields.message.value.trim());
      fetch(form.action, { method: "POST", body: data, headers: { Accept: "application/json" }, credentials: "omit", referrerPolicy: "strict-origin-when-cross-origin" })
        .then(function (r) {
          if (!r.ok) throw new Error("HTTP " + r.status);
          form.reset();
          try { localStorage.setItem("p04-nj-last-sent", String(Date.now())); } catch (err) {}
          setStatus(t("form.ok"), "ok");
        })
        .catch(function () { setStatus(t("form.err"), "err"); })
        .then(function () { send.disabled = false; label.textContent = t("form.send"); });
    });
    $$("input, textarea", form).forEach(function (f) {
      f.addEventListener("input", function () { f.closest(".field").classList.remove("is-invalid"); f.removeAttribute("aria-invalid"); });
    });
  }

  /* ---------- 13. Curseur + boutons magnétiques ---------- */
  function initCursor() {
    window.addEventListener("pointermove", function (e) {
      pointer.x = e.clientX; pointer.y = e.clientY; pointer.last = performance.now();
    }, { passive: true });
    if (!finePointer || reduced) return;
    document.body.classList.add("has-cursor");
    var cur = $(".cursor"), dot = $(".cursor-dot"), ring = $(".cursor-ring"), lab = $(".cursor-label");
    var rx = window.innerWidth / 2, ry = window.innerHeight / 2;
    document.addEventListener("pointerover", function (e) {
      var target = e.target.closest("[data-cursor]");
      if (target) { lab.textContent = target.getAttribute("data-cursor"); cur.classList.add("is-label"); }
      else if (e.target.closest("a, button, input, textarea, select, .mx-name")) { cur.classList.remove("is-label"); ring.style.width = ""; }
      else cur.classList.remove("is-label");
    });
    document.addEventListener("pointerleave", function () { cur.classList.add("is-hidden"); });
    document.addEventListener("pointerenter", function () { cur.classList.remove("is-hidden"); });
    (function frame() {
      requestAnimationFrame(frame);
      rx = lerp(rx, pointer.x, 0.18); ry = lerp(ry, pointer.y, 0.18);
      dot.style.transform = "translate3d(" + pointer.x + "px," + pointer.y + "px,0)";
      ring.style.transform = "translate3d(" + rx.toFixed(1) + "px," + ry.toFixed(1) + "px,0)";
    })();
    // Boutons magnétiques : ils se laissent attirer par le curseur
    $$(".magnetic").forEach(function (b) {
      b.addEventListener("pointermove", function (e) {
        var r = b.getBoundingClientRect();
        var x = e.clientX - (r.left + r.width / 2), y = e.clientY - (r.top + r.height / 2);
        b.style.transform = "translate(" + (x * 0.25).toFixed(1) + "px," + (y * 0.35).toFixed(1) + "px)";
      });
      b.addEventListener("pointerleave", function () { b.style.transform = ""; });
    });
  }

  /* ---------- 14. Défilement ---------- */
  function initScroll() {
    var bar = $("#topbar"), fill = $(".progress-fill"), train = $(".progress-train");
    var lastY = window.scrollY, ticking = false;
    var portraitImg = $(".portrait-frame img");
    var navLinks = $$(".nav a");
    function onScroll() {
      ticking = false;
      var y = window.scrollY;
      var max = document.documentElement.scrollHeight - window.innerHeight;
      var p = max > 0 ? y / max : 0;
      fill.style.transform = "scaleX(" + p.toFixed(4) + ")";
      train.style.transform = "translateX(" + (p * (window.innerWidth + 22)).toFixed(1) + "px)";
      bar.classList.toggle("is-scrolled", y > 20);
      if (!root.classList.contains("menu-open")) bar.classList.toggle("is-hidden", y > 700 && y > lastY + 2);
      if (y < lastY - 2) bar.classList.remove("is-hidden");
      lastY = y;
      // Couleur de l'en-tête selon la section en dessous
      var probe = document.elementFromPoint(window.innerWidth / 2, Math.min(window.innerHeight - 1, bar.getBoundingClientRect().bottom + 2));
      var sec = probe && probe.closest && probe.closest(".path, .contact");
      bar.classList.toggle("on-light", !!(sec && sec.classList.contains("path")));
      bar.classList.toggle("on-taxi", !!(sec && sec.classList.contains("contact")));
      updatePath();
      flushReveal();
      if (portraitImg && !reduced) {
        var r = portraitImg.parentNode.getBoundingClientRect();
        var k = clamp((window.innerHeight - r.top) / (window.innerHeight + r.height), 0, 1);
        portraitImg.style.setProperty("--pp", ((k - 0.5) * -30).toFixed(1) + "px");
      }
      // Lien actif dans le menu
      var current = null;
      ["projets", "competences", "parcours", "apropos", "contact"].forEach(function (id) {
        var s = document.getElementById(id);
        if (s && s.getBoundingClientRect().top < window.innerHeight * 0.4) current = id;
      });
      navLinks.forEach(function (a) { a.classList.toggle("is-current", a.getAttribute("href") === "#" + current); });
    }
    window.addEventListener("scroll", function () { if (!ticking) { ticking = true; requestAnimationFrame(onScroll); } }, { passive: true });
    window.addEventListener("resize", onScroll);
    onScroll();

    // Défilement doux pour les ancres internes (respecte "moins d'animations")
    document.addEventListener("click", function (e) {
      var a = e.target.closest('a[href^="#"]');
      if (!a || a.hasAttribute("data-open")) return;
      var id = a.getAttribute("href");
      if (id.indexOf("#/") === 0) return;
      var target = id === "#top" ? document.body : document.querySelector(id);
      if (!target) return;
      e.preventDefault();
      closeMenu();
      var top = id === "#top" ? 0 : target.getBoundingClientRect().top + window.scrollY - 70;
      window.scrollTo({ top: top, behavior: reduced ? "auto" : "smooth" });
      if (id !== "#top") { target.setAttribute("tabindex", "-1"); target.focus({ preventScroll: true }); }
    });
  }

  // Menu mobile
  var burger, menu;
  function closeMenu() {
    if (!menu || menu.hidden) return;
    menu.classList.remove("is-open");
    root.classList.remove("menu-open", "lock");
    burger.setAttribute("aria-expanded", "false");
    setTimeout(function () { menu.hidden = true; }, reduced ? 0 : 650);
  }
  function initMenu() {
    burger = $(".burger"); menu = $("#mobile-menu");
    if (!burger || !menu) return;
    burger.addEventListener("click", function () {
      if (burger.getAttribute("aria-expanded") === "true") { closeMenu(); return; }
      menu.hidden = false;
      root.classList.add("menu-open", "lock");
      burger.setAttribute("aria-expanded", "true");
      requestAnimationFrame(function () { requestAnimationFrame(function () { menu.classList.add("is-open"); }); });
    });
    document.addEventListener("keydown", function (e) { if (e.key === "Escape") closeMenu(); });
  }

  function renderTraits() {
    var ul = $("#traits");
    if (!ul) return;
    ul.innerHTML = "";
    (t("about.t") || []).forEach(function (x) { var li = el("li"); li.textContent = x; ul.appendChild(li); });
  }

  /* ---------- 15. Démarrage ---------- */
  function start() {
    $("#year").textContent = new Date().getFullYear();
    initLetters();
    initLang();
    renderCards();
    renderMatrix();
    renderStations();
    renderTraits();
    langListeners.push(renderCards, renderMatrix, renderStations, renderTraits);
    applyLang();
    initReveal();
    initFilters();
    initRoute();
    initClock();
    initLights();
    initMarquee();
    initSheet();
    initContact();
    initCursor();
    initScroll();
    initMenu();
    runIntro(function () {
      lettersIn();
      initBoard();
      setTimeout(function () { $(".route").classList.add("is-drawn"); if (route.place) route.place(); }, 250);
      animateLetters();
    });
    // Petit mot pour les recruteurs qui ouvrent la console
    try {
      console.log("%cLigne NJ%c  Tu lis le code ? On va bien s'entendre.\n" + EMAIL + " · github.com/njdev154",
        "background:#F08A24;color:#2a1a08;font-weight:800;padding:4px 8px;border-radius:4px", "color:inherit");
    } catch (e) {}
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", start);
  else start();
})();
