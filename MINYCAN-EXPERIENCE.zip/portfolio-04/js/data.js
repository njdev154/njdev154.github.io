/* ==========================================================
   LIGNE NJ — Données du portfolio
   ----------------------------------------------------------
   Tout le contenu "qui bouge" (projets, compétences, parcours)
   vit ici. Pour ajouter un projet : copie un bloc dans
   PROJECTS, change les textes et ajoute les images dans
   assets/img/. Le site se met à jour tout seul.
   Chaque texte existe en français (fr) et en anglais (en).
   ========================================================== */

var NJ = (window.NJ = window.NJ || {});

NJ.PROJECTS = [
  {
    slug: "cibanque",
    code: "CIB",
    name: "CIBANQUE",
    cats: ["front", "live"],
    status: "live",
    stack: ["HTML", "CSS", "JavaScript"],
    cover: "assets/img/cibanque-dashboard.webp",
    gallery: [
      { src: "assets/img/cibanque-accueil.webp", fr: "Page d'accueil", en: "Home page" },
      { src: "assets/img/cibanque-login.webp", fr: "Connexion", en: "Sign in" },
      { src: "assets/img/cibanque-dashboard.webp", fr: "Tableau de bord", en: "Dashboard" }
    ],
    demo: "https://njdev154.github.io/cibanque/",
    code_url: "https://github.com/njdev154/cibanque",
    fr: {
      type: "Projet personnel",
      statusLabel: "En ligne · simulation",
      tagline: "Une banque mobile pensée pour la Côte d'Ivoire : FCFA, virements, factures CIE et SODECI.",
      context: "Un prototype inspiré des services financiers que les Ivoiriens utilisent vraiment (FCFA, Orange Money, Wave, MTN MoMo). Site 100 % statique : les données vivent dans le navigateur, la connexion et les transactions sont simulées.",
      shows: [
        "Une interface cohérente sur 8 pages liées : accueil, inscription, connexion, tableau de bord, virements, historique, carte, profil",
        "Inscription et connexion gérées en JavaScript",
        "Données conservées côté navigateur avec localStorage",
        "Un vrai parcours utilisateur, de l'inscription au virement"
      ],
      learned: [
        "Organiser un projet multi-pages de façon cohérente",
        "Stocker et relire des données avec localStorage",
        "Adapter une interface au contexte local (FCFA, mobile money)"
      ],
      limits: "CIBANQUE n'est pas une banque. Montants fictifs, opérations simulées, aucun mot de passe vérifié par un serveur."
    },
    en: {
      type: "Personal project",
      statusLabel: "Live · simulation",
      tagline: "A mobile bank designed for Côte d'Ivoire: CFA francs, transfers, CIE and SODECI bills.",
      context: "A prototype inspired by the financial services Ivorians actually use (CFA francs, Orange Money, Wave, MTN MoMo). 100% static: data lives in the browser, sign-in and transactions are simulated.",
      shows: [
        "A consistent interface across 8 linked pages: home, sign-up, sign-in, dashboard, transfers, history, card, profile",
        "Sign-up and sign-in handled in JavaScript",
        "Data persisted in the browser with localStorage",
        "A complete user journey, from sign-up to transfer"
      ],
      learned: [
        "Structuring a multi-page project consistently",
        "Storing and reading data with localStorage",
        "Adapting an interface to the local context (CFA francs, mobile money)"
      ],
      limits: "CIBANQUE is not a bank. Fake amounts, simulated operations, no password checked by a server."
    }
  },
  {
    slug: "dona-ci",
    code: "DON",
    name: "DONA CI",
    cats: ["front", "live"],
    status: "live",
    stack: ["HTML", "CSS", "JavaScript"],
    cover: "assets/img/dona-accueil.webp",
    gallery: [{ src: "assets/img/dona-accueil.webp", fr: "Page d'accueil", en: "Home page" }],
    demo: "https://njdev154.github.io/dona-ci/",
    code_url: "https://github.com/njdev154/dona-ci",
    fr: {
      type: "Projet personnel",
      statusLabel: "En ligne",
      tagline: "Mobiliser autour du don de sang : préparer une collecte, comprendre le don, passer à l'action.",
      context: "Le site s'adresse aux entreprises, écoles et associations qui veulent organiser une campagne de don de sang, et aux visiteurs qui veulent s'impliquer concrètement.",
      shows: [
        "Une identité visuelle dédiée au sujet",
        "Un site multi-pages et responsive",
        "Des parcours d'action selon le profil : organisations, visiteurs, ressources"
      ],
      learned: [
        "Construire une identité visuelle à partir d'un sujet",
        "Hiérarchiser une information sensible pour qu'elle reste claire"
      ],
      limits: "Démonstration de conception : avant une vraie mise en service, les contacts et circuits de collecte doivent être validés avec une structure médicale partenaire."
    },
    en: {
      type: "Personal project",
      statusLabel: "Live",
      tagline: "Rallying people around blood donation: plan a drive, understand donating, take action.",
      context: "Built for companies, schools and associations that want to run a blood drive, and for visitors who want to get involved.",
      shows: [
        "A visual identity built for the subject",
        "A responsive multi-page website",
        "Action paths by profile: organisations, visitors, resources"
      ],
      learned: [
        "Building a visual identity from a subject",
        "Structuring sensitive information so it stays clear"
      ],
      limits: "A design demo: before real use, contacts and collection channels must be validated with a medical partner."
    }
  },
  {
    slug: "pigier-connect",
    code: "PIG",
    name: "PIGIER CONNECT",
    cats: ["front", "live"],
    status: "live",
    stack: ["HTML", "CSS", "JavaScript"],
    cover: "assets/img/pigier-accueil.webp",
    gallery: [
      { src: "assets/img/pigier-accueil.webp", fr: "Page d'accueil", en: "Home page" },
      { src: "assets/img/pigier-formations.webp", fr: "Recherche de formations", en: "Programme search" }
    ],
    demo: "https://njdev154.github.io/pigier-connect/",
    code_url: "https://github.com/njdev154/pigier-connect",
    fr: {
      type: "Projet personnel",
      statusLabel: "En ligne",
      tagline: "Un portail d'information sur les formations : filières, recherche, FAQ et préinscription.",
      context: "Mon premier site mis en ligne. Imaginé pour pratiquer la structure d'un vrai site, la mise en page et les interactions front-end, avec un portail de formations comme sujet.",
      shows: [
        "Une navigation claire entre plusieurs sections",
        "Une mise en page responsive avec Flexbox",
        "Une FAQ interactive et une recherche de formation en JavaScript",
        "Un formulaire de préinscription traité côté client, avec confirmation"
      ],
      learned: [
        "Organiser la navigation d'un site à plusieurs sections",
        "Rendre une interface agréable sur mobile comme sur ordinateur"
      ],
      limits: "Projet personnel, sans affiliation officielle avec l'établissement. Le formulaire ne transmet aucune inscription réelle."
    },
    en: {
      type: "Personal project",
      statusLabel: "Live",
      tagline: "An information portal for study programmes: courses, search, FAQ and pre-registration.",
      context: "My first website to go live. Built to practise real site structure, layout and front-end interactions, using a study-programme portal as the subject.",
      shows: [
        "Clear navigation across several sections",
        "A responsive Flexbox layout",
        "An interactive FAQ and programme search in JavaScript",
        "A client-side pre-registration form with confirmation"
      ],
      learned: [
        "Organising navigation on a multi-section site",
        "Making an interface pleasant on mobile and desktop"
      ],
      limits: "Personal project with no official affiliation with the school. The form does not send any real registration."
    }
  },
  {
    slug: "jeuneavenir-ci",
    code: "JAV",
    name: "JEUNEAVENIR CI",
    cats: ["front", "wip"],
    status: "wip",
    stack: ["HTML", "CSS", "JavaScript"],
    cover: "assets/img/jeuneavenir-accueil.webp",
    gallery: [
      { src: "assets/img/jeuneavenir-accueil.webp", fr: "Page d'accueil", en: "Home page" },
      { src: "assets/img/jeuneavenir-piliers.webp", fr: "Les 5 piliers", en: "The 5 pillars" }
    ],
    demo: null,
    code_url: null,
    fr: {
      type: "Projet personnel",
      statusLabel: "En chantier",
      tagline: "Orientation, mentorat et premiers stages pour les jeunes Ivoiriens, du lycée à l'emploi.",
      context: "Aider un jeune à passer d'une question à des pistes concrètes : filières, établissements, métiers, insertion. Sans prétendre remplacer un conseiller.",
      shows: [
        "Cinq piliers pensés comme un parcours : orientation, découverte, mentorat, insertion pro, espace personnel",
        "Une base front-end avec ses écrans et ses parcours"
      ],
      learned: [
        "Découper un grand sujet en parcours simples",
        "Penser une plateforme avant d'écrire le code"
      ],
      limits: "Exploré en local : contenus, données, comptes et logique serveur restent à construire. Pas encore de démo publique."
    },
    en: {
      type: "Personal project",
      statusLabel: "Under construction",
      tagline: "Guidance, mentoring and first internships for young Ivorians, from high school to work.",
      context: "Helping a young person go from a question to concrete options: courses, schools, careers, first jobs. Without pretending to replace a counsellor.",
      shows: [
        "Five pillars designed as a journey: guidance, discovery, mentoring, career, personal space",
        "A front-end base with its screens and flows"
      ],
      learned: [
        "Breaking a big subject into simple journeys",
        "Thinking through a platform before writing code"
      ],
      limits: "Explored locally: content, data, accounts and server logic are still to be built. No public demo yet."
    }
  },
  {
    slug: "passerelle",
    code: "PAS",
    name: "PASSERELLE",
    cats: ["laravel", "wip"],
    status: "wip",
    stack: ["Laravel", "PHP", "MySQL", "Blade"],
    cover: "assets/img/passerelle-accueil.webp",
    gallery: [{ src: "assets/img/passerelle-accueil.webp", fr: "Page d'accueil", en: "Home page" }],
    demo: null,
    code_url: "https://github.com/njdev154/passerelle",
    fr: {
      type: "Projet full-stack",
      statusLabel: "En chantier",
      tagline: "Stages et alternance : étudiants, entreprises et établissements sur une même plateforme.",
      context: "Faciliter l'accès à une première expérience : besoins de stage, opportunités et suivi des candidatures au même endroit. Plus qu'un tableau d'offres : un parcours suivi de bout en bout.",
      shows: [
        "Une application Laravel structurée : routes, vues Blade, formulaires",
        "Une base MySQL avec migrations, relations et données de démonstration",
        "Des espaces pensés pour chaque rôle : étudiant, entreprise, établissement, administration"
      ],
      learned: [
        "Passer du site statique à une vraie application serveur",
        "Modéliser des rôles et des relations dans une base de données"
      ],
      limits: "En construction : rôles, étapes de candidature, validation des offres et suivi restent à finaliser et à tester. Pas encore de démo publique."
    },
    en: {
      type: "Full-stack project",
      statusLabel: "Under construction",
      tagline: "Internships and work-study: students, companies and schools on one platform.",
      context: "Making a first work experience easier to reach: internship needs, opportunities and application tracking in one place. More than a job board: a journey followed end to end.",
      shows: [
        "A structured Laravel app: routes, Blade views, forms",
        "A MySQL database with migrations, relations and seed data",
        "Spaces designed for each role: student, company, school, admin"
      ],
      learned: [
        "Moving from static sites to a real server application",
        "Modelling roles and relations in a database"
      ],
      limits: "Under construction: roles, application steps, offer validation and tracking still need finishing and testing. No public demo yet."
    }
  },
  {
    slug: "bizflow",
    code: "BIZ",
    name: "BIZFLOW",
    cats: ["laravel", "wip"],
    status: "wip",
    stack: ["Laravel", "PHP", "Tailwind CSS", "SQLite"],
    cover: "assets/img/bizflow-dashboard.webp",
    gallery: [{ src: "assets/img/bizflow-dashboard.webp", fr: "Tableau de bord", en: "Dashboard" }],
    demo: null,
    code_url: null,
    fr: {
      type: "Projet full-stack",
      statusLabel: "En chantier",
      tagline: "Clients, rendez-vous et paiements réunis pour les petites entreprises de services.",
      context: "Relier les gestes quotidiens d'une activité : suivre sa clientèle, son offre, ses rendez-vous et ses paiements au même endroit, au lieu de jongler entre plusieurs outils.",
      shows: [
        "Une application Laravel avec Blade et Tailwind CSS",
        "Un tableau de bord : rendez-vous du jour, clients actifs, chiffre d'affaires en FCFA",
        "Une base SQLite en environnement de développement"
      ],
      learned: [
        "Concevoir un tableau de bord utile au quotidien",
        "Utiliser Tailwind CSS dans un projet Laravel"
      ],
      limits: "En construction : écrans, règles métier, validations et parcours restent à compléter. Pas encore de démo publique."
    },
    en: {
      type: "Full-stack project",
      statusLabel: "Under construction",
      tagline: "Clients, appointments and payments in one place for small service businesses.",
      context: "Connecting the daily gestures of a business: tracking clients, services, appointments and payments in one place instead of juggling several tools.",
      shows: [
        "A Laravel app with Blade and Tailwind CSS",
        "A dashboard: today's appointments, active clients, revenue in CFA francs",
        "A SQLite database for development"
      ],
      learned: [
        "Designing a dashboard that helps day to day",
        "Using Tailwind CSS in a Laravel project"
      ],
      limits: "Under construction: screens, business rules, validation and flows still need work. No public demo yet."
    }
  }
];

/* Compétences : quelle techno est utilisée dans quel projet (codes) */
NJ.SKILLS = [
  { group: "web", name: "HTML", uses: ["CIB", "DON", "PIG", "JAV", "PAS", "BIZ"] },
  { group: "web", name: "CSS", uses: ["CIB", "DON", "PIG", "JAV", "PAS", "BIZ"] },
  { group: "web", name: "JavaScript", uses: ["CIB", "DON", "PIG", "JAV", "PAS"] },
  { group: "web", name: "Tailwind CSS", uses: ["BIZ"] },
  { group: "back", name: "PHP", uses: ["PAS", "BIZ"] },
  { group: "back", name: "Laravel", uses: ["PAS", "BIZ"] },
  { group: "data", name: "MySQL", uses: ["PAS"] },
  { group: "data", name: "SQLite", uses: ["BIZ"] },
  { group: "tools", name: "Git · GitHub", uses: ["CIB", "DON", "PIG", "BIZ"] }
];

/* Parcours : les "stations" de la ligne */
NJ.TIMELINE = [
  { when: { fr: "2023 — 2024", en: "2023 — 2024" }, fr: { t: "Baccalauréat série D", d: "Collège Le Rodin, Yopougon." }, en: { t: "Baccalaureate, science track (D)", d: "Collège Le Rodin, Yopougon." } },
  { when: { fr: "2024 — 2025", en: "2024 — 2025" }, fr: { t: "Licence 1, IDA", d: "Pigier Côte d'Ivoire. Premiers pas en HTML, CSS, C et SQL." }, en: { t: "Bachelor year 1, Application Development", d: "Pigier Côte d'Ivoire. First steps in HTML, CSS, C and SQL." } },
  { when: { fr: "Juin 2025", en: "June 2025" }, fr: { t: "Certifié Microsoft Office Specialist", d: "Excel 2016, délivré par Certiport." }, en: { t: "Microsoft Office Specialist certified", d: "Excel 2016, issued by Certiport." } },
  { when: { fr: "2025 — 2026", en: "2025 — 2026" }, fr: { t: "Licence 2 et BTS IDA", d: "BTS Informatique, option Développeur d'Applications : admissible, validé par le stage." }, en: { t: "Bachelor year 2 + BTS in Application Development", d: "National diploma in IT, application development option: passed exams, validated by the internship." } },
  { when: { fr: "Mars 2026", en: "March 2026" }, fr: { t: "Premier site en ligne", d: "Un site vitrine publié sur GitHub Pages. Le début de la ligne." }, en: { t: "First website live", d: "A showcase site published on GitHub Pages. Where the line begins." } },
  { when: { fr: "Août — nov. 2026", en: "Aug — Nov 2026" }, now: true, fr: { t: "Stage de développement web", d: "YA Consulting, Abidjan." }, en: { t: "Web development internship", d: "YA Consulting, Abidjan." } },
  { when: { fr: "Prochaine station", en: "Next stop" }, next: true, fr: { t: "Licence 3, IDA", d: "Pigier Côte d'Ivoire. Direction : développeur Full-Stack." }, en: { t: "Bachelor year 3, Application Development", d: "Pigier Côte d'Ivoire. Heading for: full-stack developer." } }
];

/* Textes fixes de l'interface (FR / EN) */
NJ.I18N = {
  fr: {
    "skip": "Aller au contenu",
    "nav.projects": "Projets",
    "nav.skills": "Compétences",
    "nav.path": "Parcours",
    "nav.about": "À propos",
    "nav.contact": "Contact",
    "nav.cv": "CV",
    "nav.menu": "Menu",
    "nav.close": "Fermer",
    "intro.skip": "Passer",
    "hero.line": "Ligne NJ · Yopougon → Full-Stack",
    "hero.status": "En stage chez YA Consulting · ouvert aux opportunités",
    "hero.clock": "à Abidjan",
    "hero.lead": "Étudiant en informatique à Pigier Côte d'Ivoire. Je construis des sites et des applications web pensés pour ici : banque mobile, don de sang, orientation, stages.",
    "hero.cta": "Voir les projets",
    "hero.cv": "Télécharger le CV",
    "hero.scroll": "Défiler",
    "hero.board": ["DÉVELOPPEUR WEB", "ÉTUDIANT L3 IDA", "STAGIAIRE DEV WEB", "BASÉ À ABIDJAN"],
    "work.kicker": "Les arrêts · 06 projets",
    "work.title": "Des projets réels, pensés pour la Côte\u00a0d'Ivoire.",
    "work.note": "Chaque fiche dit ce qui est réel, ce qui est simulé et ce qui reste à faire.",
    "filter.all": "Tous",
    "filter.live": "En ligne",
    "filter.wip": "En chantier",
    "filter.front": "Front-end",
    "filter.laravel": "Laravel · PHP",
    "card.open": "Ouvrir",
    "skills.kicker": "Compétences",
    "skills.title": "Pas de pourcentages. Des preuves.",
    "skills.note": "Survole une techno pour voir où je l'ai utilisée.",
    "skills.web": "Web",
    "skills.back": "Back-end",
    "skills.data": "Données",
    "skills.tools": "Outils",
    "skills.studied": "Étudié en cours",
    "skills.studied.v": "Langage C, SQL, Merise (MCD, MCT), Linux",
    "skills.office": "Bureautique",
    "skills.office.v": "Excel (certifié Microsoft), Word, Office 365",
    "skills.next": "Prochaines stations",
    "skills.next.v": "Architecture et qualité du code, tests, sécurité, déploiement",
    "skills.uses": "projets",
    "path.kicker": "Parcours",
    "path.title": "J'avance station par station.",
    "path.now": "En ce moment",
    "path.next": "Terminus visé",
    "about.kicker": "À propos",
    "about.title": "J'apprends en construisant.",
    "about.p1": "Je m'appelle N'Goran Junior, j'ai grandi et je vis à Yopougon. J'étudie le développement d'applications à Pigier Côte d'Ivoire et je suis en stage de développement web chez YA Consulting depuis août 2026.",
    "about.p2": "Chaque projet de cette page m'a fait pratiquer une nouvelle partie du métier, du site statique à l'application Laravel avec base de données. Mon objectif : devenir développeur web Full-Stack.",
    "about.f.loc": "Basé à",
    "about.f.loc.v": "Yopougon, Abidjan",
    "about.f.study": "Études",
    "about.f.study.v": "BTS IDA · Licence 3 à venir",
    "about.f.goal": "Objectif",
    "about.f.goal.v": "Développeur Full-Stack",
    "about.f.lang": "Langues",
    "about.f.lang.v": "Français · Anglais technique",
    "about.method": "Ma démarche",
    "about.m1": "Comprendre le besoin avant d'écrire une ligne de code.",
    "about.m2": "Dire ce qui est réel, ce qui est simulé, ce qui reste à faire.",
    "about.m3": "Progresser projet après projet, sans prétendre tout maîtriser.",
    "about.traits": "Mes points forts",
    "about.t": ["Apprend vite", "Rigoureux et ponctuel", "Esprit d'équipe", "Curieux", "Persévérant"],
    "about.off": "Hors du code",
    "about.off.v": "Jeux vidéo, sport, lecture, veille tech.",
    "cert.kicker": "Certification",
    "cert.title": "Microsoft Office Specialist : Excel 2016",
    "cert.meta": "Certiport · juin 2025",
    "cert.cta": "Voir le certificat",
    "contact.kicker": "Contact",
    "contact.title1": "Un stage, un projet,",
    "contact.title2": "une question\u00a0?",
    "contact.lead": "Écris-moi. Je réponds vite, en français ou en anglais.",
    "contact.copy": "Copier l'email",
    "contact.copied": "Email copié !",
    "contact.wa": "WhatsApp",
    "contact.time": "Il est",
    "contact.time2": "à Abidjan",
    "form.name": "Nom",
    "form.email": "Email",
    "form.subject": "Sujet",
    "form.message": "Message",
    "form.send": "Envoyer le message",
    "form.sending": "Envoi…",
    "form.ok": "Message envoyé. Je te réponds très vite !",
    "form.err": "L'envoi a échoué. Écris-moi directement par email.",
    "form.invalid": "Vérifie les champs en orange.",
    "form.wait": "Un message vient de partir. Attends une minute avant d'en renvoyer un.",
    "form.s.stage": "Proposition de stage",
    "form.s.project": "Projet de site",
    "form.s.collab": "Collaboration",
    "form.s.other": "Autre",
    "foot.made": "Conçu et codé à la main par N'Goran Junior, à Abidjan.",
    "foot.top": "Retour au départ",
    "cs.type": "Type",
    "cs.stack": "Technos",
    "cs.status": "Statut",
    "cs.context": "Contexte",
    "cs.shows": "Ce que ça démontre",
    "cs.learned": "Ce que j'ai appris",
    "cs.limits": "Honnêtement",
    "cs.demo": "Voir le site",
    "cs.code": "Voir le code",
    "cs.nodemo": "Pas encore de démo publique.",
    "cs.next": "Projet suivant",
    "cs.close": "Fermer",
    "cs.back": "Tous les projets",
    "toast.copy": "Email copié dans le presse-papiers"
  },
  en: {
    "skip": "Skip to content",
    "nav.projects": "Work",
    "nav.skills": "Skills",
    "nav.path": "Journey",
    "nav.about": "About",
    "nav.contact": "Contact",
    "nav.cv": "CV",
    "nav.menu": "Menu",
    "nav.close": "Close",
    "intro.skip": "Skip",
    "hero.line": "Line NJ · Yopougon → Full-Stack",
    "hero.status": "Interning at YA Consulting · open to opportunities",
    "hero.clock": "in Abidjan",
    "hero.lead": "IT student at Pigier Côte d'Ivoire. I build websites and web apps designed for here: mobile banking, blood donation, career guidance, internships.",
    "hero.cta": "See the work",
    "hero.cv": "Download CV",
    "hero.scroll": "Scroll",
    "hero.board": ["WEB DEVELOPER", "IT STUDENT L3", "WEB DEV INTERN", "BASED IN ABIDJAN"],
    "work.kicker": "The stops · 06 projects",
    "work.title": "Real projects, built for Côte d'Ivoire.",
    "work.note": "Each case study says what is real, what is simulated and what is left to do.",
    "filter.all": "All",
    "filter.live": "Live",
    "filter.wip": "In progress",
    "filter.front": "Front-end",
    "filter.laravel": "Laravel · PHP",
    "card.open": "Open",
    "skills.kicker": "Skills",
    "skills.title": "No percentages. Proof.",
    "skills.note": "Hover a technology to see where I used it.",
    "skills.web": "Web",
    "skills.back": "Back-end",
    "skills.data": "Data",
    "skills.tools": "Tools",
    "skills.studied": "Studied in class",
    "skills.studied.v": "C language, SQL, Merise modelling, Linux",
    "skills.office": "Office",
    "skills.office.v": "Excel (Microsoft certified), Word, Office 365",
    "skills.next": "Next stops",
    "skills.next.v": "Code architecture and quality, testing, security, deployment",
    "skills.uses": "projects",
    "path.kicker": "Journey",
    "path.title": "Moving forward, stop by stop.",
    "path.now": "Right now",
    "path.next": "Destination",
    "about.kicker": "About",
    "about.title": "I learn by building.",
    "about.p1": "I'm N'Goran Junior, born and raised in Yopougon, Abidjan. I study application development at Pigier Côte d'Ivoire and I've been a web development intern at YA Consulting since August 2026.",
    "about.p2": "Every project on this page taught me a new part of the craft, from static sites to Laravel apps with a database. My goal: becoming a full-stack web developer.",
    "about.f.loc": "Based in",
    "about.f.loc.v": "Yopougon, Abidjan",
    "about.f.study": "Studies",
    "about.f.study.v": "BTS in App Dev · Bachelor year 3 next",
    "about.f.goal": "Goal",
    "about.f.goal.v": "Full-stack developer",
    "about.f.lang": "Languages",
    "about.f.lang.v": "French · Technical English",
    "about.method": "How I work",
    "about.m1": "Understand the need before writing a line of code.",
    "about.m2": "Say what is real, what is simulated, what is left to do.",
    "about.m3": "Grow project after project, without pretending to know it all.",
    "about.traits": "Strengths",
    "about.t": ["Fast learner", "Rigorous and punctual", "Team player", "Curious", "Persistent"],
    "about.off": "Off the keyboard",
    "about.off.v": "Video games, sport, reading, tech watch.",
    "cert.kicker": "Certification",
    "cert.title": "Microsoft Office Specialist: Excel 2016",
    "cert.meta": "Certiport · June 2025",
    "cert.cta": "View certificate",
    "contact.kicker": "Contact",
    "contact.title1": "An internship, a project,",
    "contact.title2": "a question?",
    "contact.lead": "Write to me. I reply fast, in French or English.",
    "contact.copy": "Copy email",
    "contact.copied": "Email copied!",
    "contact.wa": "WhatsApp",
    "contact.time": "It's",
    "contact.time2": "in Abidjan",
    "form.name": "Name",
    "form.email": "Email",
    "form.subject": "Subject",
    "form.message": "Message",
    "form.send": "Send message",
    "form.sending": "Sending…",
    "form.ok": "Message sent. I'll get back to you soon!",
    "form.err": "Sending failed. Email me directly instead.",
    "form.invalid": "Check the fields in orange.",
    "form.wait": "A message just went out. Wait a minute before sending another.",
    "form.s.stage": "Internship offer",
    "form.s.project": "Website project",
    "form.s.collab": "Collaboration",
    "form.s.other": "Other",
    "foot.made": "Designed and hand-coded by N'Goran Junior, in Abidjan.",
    "foot.top": "Back to departure",
    "cs.type": "Type",
    "cs.stack": "Stack",
    "cs.status": "Status",
    "cs.context": "Context",
    "cs.shows": "What it shows",
    "cs.learned": "What I learned",
    "cs.limits": "Honestly",
    "cs.demo": "Visit site",
    "cs.code": "View code",
    "cs.nodemo": "No public demo yet.",
    "cs.next": "Next project",
    "cs.close": "Close",
    "cs.back": "All projects",
    "toast.copy": "Email copied to clipboard"
  }
};
