/* ============================================================
   CONTENU DU SITE
   ------------------------------------------------------------
   Tout ce qui change souvent vit ici : projets, outils,
   parcours, modules du configurateur, textes FR / EN.
   Pour ajouter un projet : copie un bloc de PROJECTS,
   mets tes captures dans assets/img/ et c'est tout.
   ============================================================ */
(function () {
  "use strict";
  var NJ = (window.NJ = window.NJ || {});

  NJ.CONTACT = {
    user: "ngoranjunior154",
    host: "gmail.com",
    whatsapp: "2250161506296",
    github: "https://github.com/njdev154",
    linkedin: "https://www.linkedin.com/in/junior-ngoran/",
    formspree: "https://formspree.io/f/mgaevrwr"
  };

  /* ---------- Projets ---------- */
  NJ.PROJECTS = [
    {
      slug: "cibanque",
      name: "CIBANQUE",
      year: "2026",
      status: "live",
      stack: ["html", "css", "js", "git"],
      url: "njdev154.github.io/cibanque",
      demo: "https://njdev154.github.io/cibanque/",
      code: "https://github.com/njdev154/cibanque",
      cover: "assets/img/cibanque-dashboard.webp",
      size: [1586, 726],
      gallery: [
        { src: "assets/img/cibanque-accueil.webp", fr: "Accueil", en: "Home" },
        { src: "assets/img/cibanque-login.webp", fr: "Connexion", en: "Sign in" },
        { src: "assets/img/cibanque-dashboard.webp", fr: "Tableau de bord", en: "Dashboard" }
      ],
      fr: {
        kind: "Application front-end",
        line: "Une banque en ligne imaginée pour la Côte d'Ivoire : solde en FCFA, virements, factures CIE et SODECI.",
        idea: "Je voulais savoir si j'étais capable de construire un vrai parcours utilisateur, pas juste une page. J'ai choisi une banque mobile parce que tout le monde sait ce qu'on attend d'elle : se connecter, voir son solde, envoyer de l'argent.",
        built: [
          "8 écrans reliés : accueil, inscription, connexion, tableau de bord, virements, historique, carte, profil",
          "Inscription et connexion gérées en JavaScript",
          "Comptes et transactions gardés dans le navigateur avec localStorage",
          "Un parcours complet, de la création du compte au premier virement"
        ],
        learned: [
          "Garder une interface cohérente sur plusieurs pages",
          "Lire, écrire et mettre à jour des données côté navigateur",
          "Adapter une interface à un usage local : FCFA, mobile money, factures"
        ],
        state: "En ligne. C'est une simulation : montants fictifs, aucun serveur, aucune vraie transaction."
      },
      en: {
        kind: "Front-end application",
        line: "An online bank designed for Côte d'Ivoire: balance in CFA francs, transfers, CIE and SODECI bills.",
        idea: "I wanted to know if I could build a real user journey, not just a page. I picked a mobile bank because everyone knows what it should do: sign in, check your balance, send money.",
        built: [
          "8 linked screens: home, sign-up, sign-in, dashboard, transfers, history, card, profile",
          "Sign-up and sign-in handled in JavaScript",
          "Accounts and transactions stored in the browser with localStorage",
          "A complete journey, from creating an account to the first transfer"
        ],
        learned: [
          "Keeping an interface consistent across many pages",
          "Reading, writing and updating data in the browser",
          "Fitting an interface to local use: CFA francs, mobile money, bills"
        ],
        state: "Live. It's a simulation: fake amounts, no server, no real transactions."
      }
    },
    {
      slug: "passerelle",
      name: "PASSERELLE",
      year: "2026",
      status: "wip",
      stack: ["laravel", "php", "mysql", "html", "css", "git"],
      url: "localhost / passerelle",
      demo: null,
      code: "https://github.com/njdev154/passerelle",
      cover: "assets/img/passerelle-accueil.webp",
      size: [1180, 553],
      gallery: [{ src: "assets/img/passerelle-accueil.webp", fr: "Accueil", en: "Home" }],
      fr: {
        kind: "Application full-stack · Laravel",
        line: "Une plateforme de stages et d'alternance qui relie étudiants, entreprises et établissements.",
        idea: "Trouver un premier stage, c'est souvent envoyer des CV dans le vide. Passerelle réunit les offres, les candidatures et leur suivi au même endroit, pour que chacun sache où en est chaque demande.",
        built: [
          "Une application Laravel : routes, contrôleurs, vues Blade, formulaires validés",
          "Une base MySQL avec migrations, relations et données de démonstration",
          "Un espace par rôle : étudiant, entreprise, établissement, administration"
        ],
        learned: [
          "Passer du site statique à une application avec un vrai serveur",
          "Modéliser des rôles et leurs relations dans une base de données",
          "Organiser un projet qui grossit sans s'y perdre"
        ],
        state: "En développement. Les rôles, les étapes de candidature et la validation des offres sont en cours. Pas encore de démo publique."
      },
      en: {
        kind: "Full-stack application · Laravel",
        line: "An internship and work-study platform connecting students, companies and schools.",
        idea: "Finding a first internship often means sending CVs into the void. Passerelle brings offers, applications and their follow-up into one place, so everyone knows where each request stands.",
        built: [
          "A Laravel app: routes, controllers, Blade views, validated forms",
          "A MySQL database with migrations, relations and seed data",
          "One space per role: student, company, school, admin"
        ],
        learned: [
          "Moving from static sites to an app with a real server",
          "Modelling roles and their relations in a database",
          "Keeping a growing project organised"
        ],
        state: "In development. Roles, application steps and offer validation are in progress. No public demo yet."
      }
    },
    {
      slug: "dona-ci",
      name: "DONA CI",
      year: "2026",
      status: "live",
      stack: ["html", "css", "js", "git"],
      url: "njdev154.github.io/dona-ci",
      demo: "https://njdev154.github.io/dona-ci/",
      code: "https://github.com/njdev154/dona-ci",
      cover: "assets/img/dona-accueil.webp",
      size: [1180, 539],
      gallery: [{ src: "assets/img/dona-accueil.webp", fr: "Accueil", en: "Home" }],
      fr: {
        kind: "Site multi-pages",
        line: "Un site qui aide les entreprises, les écoles et les associations à organiser une collecte de sang.",
        idea: "Le sujet est sérieux, le site devait donc être rassurant et très clair. Chaque visiteur doit trouver en quelques secondes ce qu'il peut faire : organiser une collecte, comprendre le don, ou passer à l'action.",
        built: [
          "Une identité visuelle créée pour le sujet",
          "Un site multi-pages responsive",
          "Des parcours selon le profil : organisations, donneurs, ressources"
        ],
        learned: [
          "Construire une identité à partir d'un sujet",
          "Hiérarchiser une information sensible pour qu'elle reste lisible"
        ],
        state: "En ligne. Avant une vraie utilisation, les contacts et les circuits de collecte devront être validés avec une structure médicale."
      },
      en: {
        kind: "Multi-page website",
        line: "A website helping companies, schools and associations organise a blood drive.",
        idea: "It's a serious subject, so the site had to feel reassuring and very clear. Every visitor should find in seconds what they can do: organise a drive, understand donating, or take action.",
        built: [
          "A visual identity built for the subject",
          "A responsive multi-page website",
          "Paths by profile: organisations, donors, resources"
        ],
        learned: [
          "Building an identity from a subject",
          "Structuring sensitive information so it stays readable"
        ],
        state: "Live. Before real use, contacts and collection channels must be validated with a medical partner."
      }
    },
    {
      slug: "pigier-connect",
      name: "PIGIER CONNECT",
      year: "2026",
      status: "live",
      stack: ["html", "css", "js", "git"],
      url: "njdev154.github.io/pigier-connect",
      demo: "https://njdev154.github.io/pigier-connect/",
      code: "https://github.com/njdev154/pigier-connect",
      cover: "assets/img/pigier-accueil.webp",
      size: [1180, 546],
      gallery: [
        { src: "assets/img/pigier-accueil.webp", fr: "Accueil", en: "Home" },
        { src: "assets/img/pigier-formations.webp", fr: "Recherche de formations", en: "Programme search" }
      ],
      fr: {
        kind: "Site vitrine",
        line: "Un portail pour découvrir les formations d'une école : filières, recherche, FAQ, préinscription.",
        idea: "Mon tout premier site mis en ligne, en mars 2026. Le but : apprendre à structurer un site complet, avec une vraie navigation, et le rendre agréable sur téléphone.",
        built: [
          "Une navigation claire entre plusieurs sections",
          "Une mise en page responsive en Flexbox",
          "Une recherche de formations et une FAQ interactives en JavaScript",
          "Un formulaire de préinscription avec message de confirmation"
        ],
        learned: [
          "Organiser la navigation d'un site complet",
          "Penser mobile dès le départ"
        ],
        state: "En ligne. Projet personnel, sans lien officiel avec l'école. Le formulaire n'envoie aucune inscription réelle."
      },
      en: {
        kind: "Showcase website",
        line: "A portal to explore a school's programmes: courses, search, FAQ, pre-registration.",
        idea: "My very first website online, in March 2026. The goal: learn to structure a complete site with real navigation, and make it pleasant on a phone.",
        built: [
          "Clear navigation across several sections",
          "A responsive Flexbox layout",
          "Interactive programme search and FAQ in JavaScript",
          "A pre-registration form with a confirmation message"
        ],
        learned: [
          "Organising navigation on a complete site",
          "Thinking mobile from the start"
        ],
        state: "Live. Personal project, not officially linked to the school. The form sends no real registration."
      }
    },
    {
      slug: "jeuneavenir-ci",
      name: "JEUNEAVENIR CI",
      year: "2026",
      status: "wip",
      stack: ["html", "css", "js"],
      url: "localhost / jeuneavenir",
      demo: null,
      code: null,
      cover: "assets/img/jeuneavenir-accueil.webp",
      size: [1180, 559],
      gallery: [
        { src: "assets/img/jeuneavenir-accueil.webp", fr: "Accueil", en: "Home" },
        { src: "assets/img/jeuneavenir-piliers.webp", fr: "Les cinq piliers", en: "The five pillars" }
      ],
      fr: {
        kind: "Plateforme · en conception",
        line: "Orientation, mentorat et premiers stages pour les jeunes, du lycée au premier emploi.",
        idea: "Beaucoup de jeunes choisissent une filière sans savoir où elle mène. JeuneAvenir veut transformer une question floue en pistes concrètes : filières, écoles, métiers, premiers stages.",
        built: [
          "Cinq piliers pensés comme un parcours : orientation, découverte, mentorat, insertion, espace personnel",
          "Les écrans principaux et leur navigation en front-end"
        ],
        learned: [
          "Découper un grand sujet en parcours simples",
          "Concevoir une plateforme avant d'écrire le code"
        ],
        state: "En conception, en local. Contenus, comptes et partie serveur restent à construire."
      },
      en: {
        kind: "Platform · in design",
        line: "Guidance, mentoring and first internships for young people, from high school to a first job.",
        idea: "Many young people pick a course without knowing where it leads. JeuneAvenir aims to turn a vague question into concrete options: courses, schools, careers, first internships.",
        built: [
          "Five pillars designed as a journey: guidance, discovery, mentoring, career, personal space",
          "The main screens and their navigation, front-end"
        ],
        learned: [
          "Breaking a big subject into simple journeys",
          "Designing a platform before writing code"
        ],
        state: "In design, running locally. Content, accounts and the server side are still to build."
      }
    }
  ];

  /* ---------- Outils ---------- */
  NJ.TOOLS = [
    { id: "html", name: "HTML" },
    { id: "css", name: "CSS" },
    { id: "js", name: "JavaScript" },
    { id: "php", name: "PHP" },
    { id: "laravel", name: "Laravel" },
    { id: "mysql", name: "MySQL" },
    { id: "git", name: "Git" },
    { id: "github", name: "GitHub" },
    { id: "vscode", name: "VS Code" }
  ];

  /* ---------- Parcours (calques de la timeline) ----------
     from / to au format AAAA-MM. Un "point" n'a pas de "to". */
  NJ.PATH = {
    start: "2023-09",
    end: "2027-08",
    today: "2026-10",
    layers: [
      { from: "2023-09", to: "2024-07", fr: ["Baccalauréat série D", "Collège Le Rodin"], en: ["Baccalaureate, science track", "Collège Le Rodin"] },
      { from: "2024-10", to: "2025-07", fr: ["Licence 1 · IDA", "Pigier Côte d'Ivoire · HTML, CSS, C, SQL"], en: ["Bachelor year 1 · App development", "Pigier Côte d'Ivoire · HTML, CSS, C, SQL"] },
      { from: "2025-06", point: true, fr: ["Certification Excel 2016", "Microsoft Office Specialist · Certiport"], en: ["Excel 2016 certification", "Microsoft Office Specialist · Certiport"], link: "assets/docs/certificat-mos-excel-2016.pdf" },
      { from: "2025-10", to: "2026-07", fr: ["Licence 2 · BTS IDA", "BTS admissible, validé par le stage"], en: ["Bachelor year 2 · BTS in app development", "Exams passed, validated by the internship"] },
      { from: "2026-03", point: true, fr: ["Premier site en ligne", "Pigier Connect, sur GitHub Pages"], en: ["First website live", "Pigier Connect, on GitHub Pages"] },
      { from: "2026-08", to: "2026-11", now: true, fr: ["Stage développeur web", "YA Consulting"], en: ["Web developer intern", "YA Consulting"] },
      { from: "2026-11", to: "2027-07", next: true, fr: ["Licence 3 · IDA", "Pigier Côte d'Ivoire · cap sur le full-stack"], en: ["Bachelor year 3 · App development", "Pigier Côte d'Ivoire · heading full-stack"] }
    ]
  };

  /* ---------- Configurateur de projet ----------
     w = poids dans l'estimation de taille */
  NJ.MODULES = [
    { id: "hero", w: 1, fr: "Bannière d'accueil", en: "Hero banner" },
    { id: "about", w: 1, fr: "Présentation", en: "About" },
    { id: "services", w: 1, fr: "Services / offres", en: "Services" },
    { id: "gallery", w: 1, fr: "Galerie photos", en: "Photo gallery" },
    { id: "catalog", w: 2, fr: "Catalogue produits", en: "Product catalogue" },
    { id: "booking", w: 3, fr: "Prise de rendez-vous", en: "Booking" },
    { id: "reviews", w: 1, fr: "Avis clients", en: "Reviews" },
    { id: "faq", w: 1, fr: "FAQ", en: "FAQ" },
    { id: "map", w: 1, fr: "Plan d'accès", en: "Map" },
    { id: "login", w: 3, fr: "Espace membre", en: "Member area" },
    { id: "dashboard", w: 3, fr: "Tableau de bord", en: "Dashboard" },
    { id: "contact", w: 1, fr: "Formulaire de contact", en: "Contact form" }
  ];

  /* ---------- Textes de l'interface ---------- */
  NJ.I18N = {
    fr: {
      "meta.title": "Junior N'Goran · Développeur web junior",
      "skip": "Aller au contenu",
      "intro.skip": "Passer",
      "intro.render": "Rendu",
      "top.cv": "CV",
      "hero.status": "En stage chez YA Consulting · disponible pour vos projets",
      "hero.l1": "Je construis",
      "hero.l2": "des sites web",
      "hero.l3": "qui servent.",
      "hero.lead": "Développeur web junior. Sites vitrines, landing pages et applications Laravel, conçus pour vos visiteurs et codés à la main.",
      "hero.cta1": "Voir les projets",
      "hero.cta2": "Démarrer un projet",
      "hero.hint": "Attrape une fenêtre et lance-la. Elle revient.",
      "work.title": "Projets",
      "work.note": "Cinq projets construits de bout en bout. Chaque fiche dit ce qui marche, ce qui est simulé et ce qui reste à faire.",
      "work.case": "Étude de cas",
      "work.visit": "Voir le site",
      "work.code": "Code",
      "status.live": "En ligne",
      "status.wip": "En cours",
      "tools.title": "Outils",
      "tools.note": "Ce que j'utilise vraiment. Survole un outil pour voir dans quels projets.",
      "tools.idle": "Survole ou touche un outil.",
      "tools.used": "Utilisé dans",
      "tools.learning": "Étudié en cours",
      "tools.learning.v": "Langage C · SQL · Merise · Linux",
      "svc.kicker": "Pour les clients",
      "svc.title": "Ce que je peux construire pour vous",
      "svc.1.t": "Site vitrine",
      "svc.1.d": "Votre activité, vos services et vos contacts sur un site clair, rapide et lisible sur téléphone.",
      "svc.2.t": "Landing page",
      "svc.2.d": "Une page unique pour une offre, un événement ou un lancement, avec un seul objectif : faire agir le visiteur.",
      "svc.3.t": "Application web",
      "svc.3.d": "Comptes, formulaires, tableau de bord et base de données avec Laravel, pour gérer inscriptions, demandes ou réservations.",
      "svc.4.t": "Refonte",
      "svc.4.d": "Moderniser un site existant, corriger l'affichage mobile, accélérer le chargement.",
      "svc.inc": "Inclus partout : responsive, mise en ligne, prise en main.",
      "b.title": "Composez votre site",
      "b.note": "Glissez les blocs dans la fenêtre (ou touchez-les). Sortez un bloc de la fenêtre pour le retirer.",
      "b.type": "Type de projet",
      "b.t.vitrine": "Site vitrine",
      "b.t.landing": "Landing page",
      "b.t.app": "Application web",
      "b.empty": "Déposez un bloc ici",
      "b.blocks": "blocs",
      "b.size": "Envergure",
      "b.s1": "Projet léger",
      "b.s2": "Projet moyen",
      "b.s3": "Projet ambitieux",
      "b.wa": "Envoyer sur WhatsApp",
      "b.form": "Mettre dans le formulaire",
      "b.reset": "Vider",
      "b.msg.hello": "Bonjour Junior, j'ai un projet de",
      "b.msg.with": "avec",
      "b.msg.size": "Envergure estimée",
      "proc.title": "Comment on avance",
      "proc.1.t": "On en parle",
      "proc.1.d": "Votre besoin, votre public, ce que le site doit faire.",
      "proc.2.t": "Maquette",
      "proc.2.d": "La structure et le design, validés avant la moindre ligne de code.",
      "proc.3.t": "Développement",
      "proc.3.d": "Vous suivez l'avancement en ligne, étape par étape.",
      "proc.4.t": "Mise en ligne",
      "proc.4.d": "Hébergement, nom de domaine, et je vous montre comment tout fonctionne.",
      "path.title": "Parcours",
      "path.note": "Formation, certification, premier site, stage. Ce qui est fait, ce qui est en cours, ce qui arrive.",
      "path.today": "Aujourd'hui",
      "path.now": "En cours",
      "path.next": "À venir",
      "path.cert": "Voir le certificat",
      "about.title": "Derrière le code",
      "about.p1": "Je m'appelle Junior. Je suis étudiant en BTS Développeur d'Applications à Pigier Côte d'Ivoire et en stage de développement web chez YA Consulting depuis août 2026.",
      "about.p2": "J'aime partir d'un besoin concret et le transformer en interface simple à utiliser. Chaque projet m'a appris une nouvelle partie du métier, de la page statique à l'application avec base de données. Mon cap : devenir développeur full-stack.",
      "about.how": "Ma façon de travailler",
      "about.h1": "Je pose des questions avant d'écrire du code.",
      "about.h2": "Je montre l'avancement tôt et souvent.",
      "about.h3": "Je dis clairement ce qui est fini et ce qui ne l'est pas.",
      "about.f.study": "Formation",
      "about.f.study.v": "BTS IDA · Licence 3 à venir",
      "about.f.lang": "Langues",
      "about.f.lang.v": "Français · anglais technique",
      "about.f.cert": "Certification",
      "about.f.cert.v": "Microsoft Office Specialist, Excel",
      "about.f.off": "Hors du code",
      "about.f.off.v": "Jeux vidéo, sport, lecture, veille tech",
      "about.cv": "Télécharger le CV",
      "about.photo": "Portrait de Junior N'Goran",
      "contact.kicker": "Contact",
      "contact.t1": "Un projet,",
      "contact.t2": "un stage ?",
      "contact.t3": "Parlons-en.",
      "contact.lead": "Je réponds vite, en français ou en anglais.",
      "contact.copy": "Copier",
      "contact.copied": "Copié",
      "f.title": "nouveau-message.txt",
      "f.name": "Nom",
      "f.email": "Email",
      "f.subject": "Sujet",
      "f.s.project": "Projet de site",
      "f.s.intern": "Proposition de stage",
      "f.s.collab": "Collaboration",
      "f.s.other": "Autre",
      "f.message": "Message",
      "f.send": "Envoyer",
      "f.sending": "Envoi…",
      "f.ok": "Message envoyé. Je vous réponds très vite.",
      "f.err": "L'envoi a échoué. Écrivez-moi directement par email.",
      "f.invalid": "Vérifiez les champs en surbrillance.",
      "f.wait": "Un message vient de partir. Patientez une minute.",
      "f.again": "Écrire un autre message",
      "foot.made": "Conçu et codé à la main · HTML, CSS, JavaScript",
      "foot.src": "Code source",
      "foot.top": "Haut de page",
      "cs.close": "Fermer",
      "cs.kind": "Type",
      "cs.stack": "Outils",
      "cs.state": "Statut",
      "cs.idea": "L'idée",
      "cs.built": "Ce que j'ai construit",
      "cs.learned": "Ce que j'ai appris",
      "cs.where": "Où en est le projet",
      "cs.next": "Projet suivant",
      "cs.drag": "Fais glisser les captures",
      "cs.nodemo": "Pas encore de démo publique",
      "cur.throw": "Lancer",
      "cur.open": "Ouvrir",
      "cur.drag": "Glisser",
      "nav.hero": "Début",
      "nav.work": "Projets",
      "nav.tools": "Outils",
      "nav.svc": "Services",
      "nav.path": "Parcours",
      "nav.about": "À propos",
      "nav.contact": "Contact",
      "nav.cta": "Me contacter"
    },
    en: {
      "meta.title": "Junior N'Goran · Junior web developer",
      "skip": "Skip to content",
      "intro.skip": "Skip",
      "intro.render": "Render",
      "top.cv": "CV",
      "hero.status": "Interning at YA Consulting · available for your projects",
      "hero.l1": "I build",
      "hero.l2": "websites",
      "hero.l3": "that work.",
      "hero.lead": "Junior web developer. Showcase sites, landing pages and Laravel apps, designed for your visitors and hand-coded.",
      "hero.cta1": "See the work",
      "hero.cta2": "Start a project",
      "hero.hint": "Grab a window and throw it. It comes back.",
      "work.title": "Work",
      "work.note": "Five projects built end to end. Each case study says what works, what is simulated and what is left to do.",
      "work.case": "Case study",
      "work.visit": "Visit site",
      "work.code": "Code",
      "status.live": "Live",
      "status.wip": "In progress",
      "tools.title": "Tools",
      "tools.note": "What I actually use. Hover a tool to see which projects.",
      "tools.idle": "Hover or tap a tool.",
      "tools.used": "Used in",
      "tools.learning": "Studied in class",
      "tools.learning.v": "C language · SQL · Merise · Linux",
      "svc.kicker": "For clients",
      "svc.title": "What I can build for you",
      "svc.1.t": "Showcase site",
      "svc.1.d": "Your business, services and contacts on a clear, fast site that reads well on a phone.",
      "svc.2.t": "Landing page",
      "svc.2.d": "A single page for an offer, an event or a launch, with one goal: getting the visitor to act.",
      "svc.3.t": "Web application",
      "svc.3.d": "Accounts, forms, dashboard and database with Laravel, to manage sign-ups, requests or bookings.",
      "svc.4.t": "Redesign",
      "svc.4.d": "Modernise an existing site, fix the mobile layout, speed up loading.",
      "svc.inc": "Always included: responsive, deployment, handover.",
      "b.title": "Build your site",
      "b.note": "Drag blocks into the window (or tap them). Drag a block out of the window to remove it.",
      "b.type": "Project type",
      "b.t.vitrine": "Showcase site",
      "b.t.landing": "Landing page",
      "b.t.app": "Web app",
      "b.empty": "Drop a block here",
      "b.blocks": "blocks",
      "b.size": "Scope",
      "b.s1": "Small project",
      "b.s2": "Medium project",
      "b.s3": "Ambitious project",
      "b.wa": "Send on WhatsApp",
      "b.form": "Put it in the form",
      "b.reset": "Clear",
      "b.msg.hello": "Hi Junior, I have a project:",
      "b.msg.with": "with",
      "b.msg.size": "Estimated scope",
      "proc.title": "How we move forward",
      "proc.1.t": "We talk",
      "proc.1.d": "Your need, your audience, what the site must do.",
      "proc.2.t": "Mockup",
      "proc.2.d": "Structure and design, approved before a single line of code.",
      "proc.3.t": "Development",
      "proc.3.d": "You follow progress online, step by step.",
      "proc.4.t": "Launch",
      "proc.4.d": "Hosting, domain name, and I show you how everything works.",
      "path.title": "Journey",
      "path.note": "Studies, certification, first website, internship. What's done, what's ongoing, what's next.",
      "path.today": "Today",
      "path.now": "Ongoing",
      "path.next": "Next",
      "path.cert": "View certificate",
      "about.title": "Behind the code",
      "about.p1": "I'm Junior. I'm studying application development (BTS) at Pigier Côte d'Ivoire and I've been a web development intern at YA Consulting since August 2026.",
      "about.p2": "I like starting from a concrete need and turning it into an interface that's simple to use. Every project taught me a new part of the craft, from static pages to apps with a database. My goal: becoming a full-stack developer.",
      "about.how": "How I work",
      "about.h1": "I ask questions before writing code.",
      "about.h2": "I show progress early and often.",
      "about.h3": "I say clearly what is finished and what isn't.",
      "about.f.study": "Studies",
      "about.f.study.v": "BTS in app development · Bachelor year 3 next",
      "about.f.lang": "Languages",
      "about.f.lang.v": "French · technical English",
      "about.f.cert": "Certification",
      "about.f.cert.v": "Microsoft Office Specialist, Excel",
      "about.f.off": "Off the keyboard",
      "about.f.off.v": "Video games, sport, reading, tech news",
      "about.cv": "Download CV",
      "about.photo": "Portrait of Junior N'Goran",
      "contact.kicker": "Contact",
      "contact.t1": "A project,",
      "contact.t2": "an internship?",
      "contact.t3": "Let's talk.",
      "contact.lead": "I reply fast, in French or English.",
      "contact.copy": "Copy",
      "contact.copied": "Copied",
      "f.title": "new-message.txt",
      "f.name": "Name",
      "f.email": "Email",
      "f.subject": "Subject",
      "f.s.project": "Website project",
      "f.s.intern": "Internship offer",
      "f.s.collab": "Collaboration",
      "f.s.other": "Other",
      "f.message": "Message",
      "f.send": "Send",
      "f.sending": "Sending…",
      "f.ok": "Message sent. I'll get back to you very soon.",
      "f.err": "Sending failed. Email me directly instead.",
      "f.invalid": "Check the highlighted fields.",
      "f.wait": "A message just went out. Please wait a minute.",
      "f.again": "Write another message",
      "foot.made": "Designed and hand-coded · HTML, CSS, JavaScript",
      "foot.src": "Source code",
      "foot.top": "Back to top",
      "cs.close": "Close",
      "cs.kind": "Type",
      "cs.stack": "Tools",
      "cs.state": "Status",
      "cs.idea": "The idea",
      "cs.built": "What I built",
      "cs.learned": "What I learned",
      "cs.where": "Where it stands",
      "cs.next": "Next project",
      "cs.drag": "Drag the screenshots",
      "cs.nodemo": "No public demo yet",
      "cur.throw": "Throw",
      "cur.open": "Open",
      "cur.drag": "Drag",
      "nav.hero": "Start",
      "nav.work": "Work",
      "nav.tools": "Tools",
      "nav.svc": "Services",
      "nav.path": "Journey",
      "nav.about": "About",
      "nav.contact": "Contact",
      "nav.cta": "Contact me"
    }
  };
})();
