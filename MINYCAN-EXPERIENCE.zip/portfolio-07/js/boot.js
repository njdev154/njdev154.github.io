/* Avant l'affichage : active les animations et décide si l'intro joue (une fois par session). */
(function () {
  var d = document.documentElement;
  d.classList.add("js");
  try {
    var reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (reduce || sessionStorage.getItem("p07-nj-intro") === "1") d.classList.add("no-intro");
    if (localStorage.getItem("p07-nj-lang") === "en") d.lang = "en";
  } catch (e) { /* stockage indisponible : on garde les valeurs par défaut */ }
})();
