/* ==============================================================
   PORTFOLIO · JUNIOR N'GORAN · interactions
   JavaScript pur, aucune librairie. Sommaire :
   1. outils           7. projets (scènes)      13. étude de cas
   2. langue           8. outils / technos      14. contact + formulaire
   3. physique         9. configurateur         15. intro
   4. trajectoires    10. parcours              16. démarrage
   5. curseur         11. timeline de nav
   6. hero            12. défilement
   ============================================================== */
(function () {
  "use strict";

  var NJ = window.NJ;
  var D = document;
  var root = D.documentElement;
  var body = D.body;
  var reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  var finePointer = window.matchMedia("(pointer: fine)").matches;

  /* ---------- 1. outils ---------- */
  function $(s, c) { return (c || D).querySelector(s); }
  function $$(s, c) { return Array.prototype.slice.call((c || D).querySelectorAll(s)); }
  function el(tag, cls, text) {
    var e = D.createElement(tag);
    if (cls) e.className = cls;
    if (text != null) e.textContent = text;
    return e;
  }
  function clamp(v, a, b) { return v < a ? a : v > b ? b : v; }
  function safeUrl(u) { return typeof u === "string" && /^https:\/\//.test(u) ? u : null; }
  function icon(name) { var s = el("i"); s.setAttribute("data-ui", name); s.innerHTML = NJ.UI[name] || ""; return s; }
  function toolIcon(id) { var s = el("span"); s.innerHTML = NJ.ICONS[id] || ""; return s.firstChild || s; }
  function now() { return performance.now(); }

  /* ---------- 2. langue ---------- */
  var lang = root.lang === "en" ? "en" : "fr";
  function t(k) { return (NJ.I18N[lang] && NJ.I18N[lang][k]) || NJ.I18N.fr[k] || ""; }
  var onLang = [];
  function applyLang(init) {
    root.lang = lang;
    D.title = t("meta.title");
    $$("[data-i18n]").forEach(function (n) { var v = t(n.getAttribute("data-i18n")); if (v) n.textContent = v; });
    $$("[data-i18n-alt]").forEach(function (n) { n.alt = t(n.getAttribute("data-i18n-alt")); });
    $$(".lang button").forEach(function (b) { b.setAttribute("aria-pressed", String(b.getAttribute("data-lang") === lang)); });
    onLang.forEach(function (f) { f(init); });
  }
  $$(".lang button").forEach(function (b) {
    b.addEventListener("click", function () {
      lang = b.getAttribute("data-lang") === "en" ? "en" : "fr";
      try { localStorage.setItem("p07-nj-lang", lang); } catch (e) {}
      applyLang(false);
      layout();
    });
  });
  function hydrateIcons(scope) {
    $$("[data-ui]", scope).forEach(function (n) { if (!n.firstChild) n.innerHTML = NJ.UI[n.getAttribute("data-ui")] || ""; });
  }

  /* ---------- 3. physique : objets lançables, retour en boomerang ----------
     Un ressort ramène l'objet à sa place. Peu amorti : il part, ralentit,
     revient, dépasse un peu et se pose. La rotation tourne librement puis
     se cale sur le tour complet le plus proche. */
  var K = 0.011, C = 0.055, VMAX = 70;
  var active = new Set();
  var loopOn = false;
  var uid = 0;

  function Throwable(node, opt) {
    opt = opt || {};
    this.node = node;
    this.id = ++uid;
    this.x = 0; this.y = 0; this.r = 0;
    this.vx = 0; this.vy = 0; this.vr = 0;
    this.drag = false;
    this.onTap = opt.onTap;
    var self = this;
    var handles = opt.handles || [node];
    var start, samples, ox, oy, moved, base;

    function down(e) {
      if (e.button !== 0 && e.pointerType === "mouse") return;
      if (e.target.closest("input, textarea, select, a, button, label")) return;
      if (e.pointerType !== "mouse" && !e.target.closest(".win-bar")) return; // au doigt : on attrape par la barre
      e.preventDefault();
      self.drag = true; moved = 0;
      start = { x: e.clientX, y: e.clientY, t: now() };
      ox = self.x; oy = self.y;
      samples = [{ x: e.clientX, y: e.clientY, t: start.t }];
      var r = node.getBoundingClientRect();
      base = { cx: r.left + r.width / 2 - self.x, cy: r.top + r.height / 2 - self.y };
      self.base = base;
      self.vr = 0;
      node.classList.add("flying");
      try { e.currentTarget.setPointerCapture(e.pointerId); } catch (err) {}
      active.delete(self);
    }
    function move(e) {
      if (!self.drag) return;
      var dx = e.clientX - start.x, dy = e.clientY - start.y;
      moved = Math.max(moved, Math.abs(dx) + Math.abs(dy));
      self.x = ox + dx; self.y = oy + dy;
      samples.push({ x: e.clientX, y: e.clientY, t: now() });
      if (samples.length > 6) samples.shift();
      var a = samples[0], b = samples[samples.length - 1], dt = Math.max(1, b.t - a.t);
      self.r += (clamp(((b.x - a.x) / dt) * 9, -18, 18) - self.r) * 0.25;
      self.render();
      if (moved > 6) Trails.push(self);
    }
    function up(e) {
      if (!self.drag) return;
      self.drag = false;
      var dur = now() - start.t;
      if (moved < 6 && dur < 400) {
        self.x = ox; self.y = oy; self.render();
        node.classList.remove("flying");
        if (self.onTap && e.type === "pointerup") self.onTap(node);
        return;
      }
      var a = samples[0], b = samples[samples.length - 1], dt = Math.max(8, b.t - a.t);
      if (now() - b.t > 90) { self.vx = 0; self.vy = 0; }
      else {
        self.vx = clamp(((b.x - a.x) / dt) * 16.7, -VMAX, VMAX);
        self.vy = clamp(((b.y - a.y) / dt) * 16.7, -VMAX, VMAX);
      }
      self.vr = clamp(self.vx * 0.9 + self.vy * 0.25, -38, 38);
      if (reduce) { self.vx = self.vy = self.vr = 0; }
      active.add(self);
      startLoop();
    }
    handles.forEach(function (h) {
      h.addEventListener("pointerdown", down);
      h.addEventListener("pointermove", move);
      h.addEventListener("pointerup", up);
      h.addEventListener("pointercancel", up);
    });
    node.addEventListener("dragstart", function (e) { e.preventDefault(); });
    var lastType = "mouse";
    node.addEventListener("pointerdown", function (e) { lastType = e.pointerType; }, true);
    node.addEventListener("click", function (e) {
      if (lastType === "mouse" || !self.onTap || e.target.closest(".win-bar, a, button, input, textarea, label")) return;
      self.onTap(node);
    });
  }
  Throwable.prototype.render = function () {
    this.node.style.transform = "translate3d(" + this.x.toFixed(2) + "px," + this.y.toFixed(2) + "px,0) rotate(" + this.r.toFixed(2) + "deg)";
  };
  Throwable.prototype.step = function (f) {
    this.vx += (-K * this.x - C * this.vx) * f;
    this.vy += (-K * this.y - C * this.vy) * f;
    this.x += this.vx * f; this.y += this.vy * f;
    if (Math.abs(this.vr) > 1.6) {
      this.vr *= Math.pow(0.968, f);
      this.r += this.vr * f;
    } else {
      var target = Math.round(this.r / 360) * 360;
      this.vr += (-0.02 * (this.r - target) - 0.12 * this.vr) * f;
      this.r += this.vr * f;
      if (Math.abs(this.r - target) < 0.15 && Math.abs(this.vr) < 0.05) { this.r = 0; this.vr = 0; }
    }
    this.render();
    if (Math.abs(this.vx) + Math.abs(this.vy) > 0.6) Trails.push(this);
    var rest = Math.abs(this.x) < 0.3 && Math.abs(this.y) < 0.3 && Math.abs(this.vx) < 0.05 && Math.abs(this.vy) < 0.05 && this.r === 0;
    if (rest) {
      this.x = this.y = 0;
      this.node.style.transform = "";
      this.node.classList.remove("flying");
      return false;
    }
    return true;
  };

  var last = 0;
  function startLoop() { if (!loopOn) { loopOn = true; last = now(); requestAnimationFrame(tick); } }
  function tick(ts) {
    var f = clamp((ts - last) / 16.67, 0.2, 3); last = ts;
    active.forEach(function (o) { if (!o.step(f)) active.delete(o); });
    Ghosts.step(f);
    var trailsAlive = Trails.draw();
    if (active.size || Ghosts.count() || trailsAlive) requestAnimationFrame(tick);
    else loopOn = false;
  }

  /* ---------- 4. trajectoires : la courbe de mouvement, avec ses images-clés ---------- */
  var Trails = (function () {
    var cv = $("#trails"), ctx = cv.getContext("2d"), dpr = 1, paths = {};
    function size() {
      dpr = Math.min(2, window.devicePixelRatio || 1);
      cv.width = innerWidth * dpr; cv.height = innerHeight * dpr;
    }
    size();
    window.addEventListener("resize", size);
    return {
      push: function (o) {
        if (reduce || !o.base) return;
        var p = paths[o.id] || (paths[o.id] = []);
        p.push({ x: o.base.cx + o.x, y: o.base.cy + o.y, t: now() });
        if (p.length > 90) p.shift();
        startLoop();
      },
      pushXY: function (id, x, y) {
        if (reduce) return;
        var p = paths[id] || (paths[id] = []);
        p.push({ x: x, y: y, t: now() });
        if (p.length > 90) p.shift();
      },
      draw: function () {
        ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
        ctx.clearRect(0, 0, innerWidth, innerHeight);
        var tnow = now(), alive = false, LIFE = 900;
        Object.keys(paths).forEach(function (k) {
          var p = paths[k];
          while (p.length && tnow - p[0].t > LIFE) p.shift();
          if (p.length < 2) { if (!p.length) delete paths[k]; return; }
          alive = true;
          ctx.lineWidth = 2;
          ctx.setLineDash([6, 6]);
          for (var i = 1; i < p.length; i++) {
            var a = 1 - (tnow - p[i].t) / LIFE;
            ctx.strokeStyle = "rgba(38,128,64," + (a * 0.85).toFixed(3) + ")";
            ctx.beginPath(); ctx.moveTo(p[i - 1].x, p[i - 1].y); ctx.lineTo(p[i].x, p[i].y); ctx.stroke();
          }
          ctx.setLineDash([]);
          for (var j = 0; j < p.length; j += 6) {
            var al = 1 - (tnow - p[j].t) / LIFE;
            ctx.save();
            ctx.translate(p[j].x, p[j].y); ctx.rotate(Math.PI / 4);
            ctx.fillStyle = "rgba(74,214,104," + al.toFixed(3) + ")";
            ctx.strokeStyle = "rgba(29,42,36," + (al * 0.9).toFixed(3) + ")";
            ctx.lineWidth = 1.5;
            ctx.fillRect(-4, -4, 8, 8); ctx.strokeRect(-4, -4, 8, 8);
            ctx.restore();
          }
        });
        return alive;
      }
    };
  })();

  /* fantômes du configurateur (même ressort, mais vers une cible) */
  var Ghosts = (function () {
    var list = [];
    return {
      add: function (g) { list.push(g); startLoop(); },
      count: function () { return list.length; },
      step: function (f) {
        list = list.filter(function (g) {
          var k = g.k || 0.016, c = g.c || 0.075;
          g.vx += (-k * (g.x - g.tx) - c * g.vx) * f;
          g.vy += (-k * (g.y - g.ty) - c * g.vy) * f;
          g.x += g.vx * f; g.y += g.vy * f;
          g.r += (-(g.r) * 0.08 + g.vx * 0.05) * f;
          g.node.style.transform = "translate3d(" + g.x + "px," + g.y + "px,0) rotate(" + g.r + "deg)";
          Trails.pushXY("g" + g.id, g.x + g.w / 2, g.y + g.h / 2);
          var done = Math.abs(g.x - g.tx) < 1.2 && Math.abs(g.y - g.ty) < 1.2 && Math.abs(g.vx) + Math.abs(g.vy) < 0.3;
          if (done || reduce) { g.node.remove(); if (g.done) g.done(); return false; }
          return true;
        });
      }
    };
  })();

  /* ---------- 5. curseur contextuel ---------- */
  var cursor = $("#cursor"), curLabel = cursor.firstElementChild;
  if (finePointer) {
    D.addEventListener("pointermove", function (e) {
      if (e.pointerType !== "mouse") return;
      cursor.style.transform = "translate(" + e.clientX + "px," + e.clientY + "px)";
      var c = e.target.closest && e.target.closest("[data-cur]");
      if (c) { curLabel.textContent = t("cur." + c.getAttribute("data-cur")); cursor.classList.add("on"); }
      else cursor.classList.remove("on");
    }, { passive: true });
    D.addEventListener("pointerleave", function () { cursor.classList.remove("on"); });
  }

  /* boutons aimantés */
  if (finePointer && !reduce) {
    $$(".mag").forEach(function (m) {
      m.addEventListener("pointermove", function (e) {
        var r = m.getBoundingClientRect();
        var dx = (e.clientX - (r.left + r.width / 2)) / r.width, dy = (e.clientY - (r.top + r.height / 2)) / r.height;
        m.style.translate = (dx * 8).toFixed(1) + "px " + (dy * 6).toFixed(1) + "px";
      });
      m.addEventListener("pointerleave", function () { m.style.translate = ""; });
    });
  }

  /* ---------- fenêtre (composant) ---------- */
  function makeWin(src, w, h, label, alt) {
    var win = el("div", "win throw");
    var bar = el("div", "win-bar");
    bar.appendChild(icon("grip")).classList.add("win-grip");
    bar.appendChild(el("span", "", label));
    bar.appendChild(el("em", "", w + " × " + h));
    var img = el("img");
    img.src = src; img.width = w; img.height = h; img.alt = alt || ""; img.loading = "lazy"; img.decoding = "async"; img.draggable = false;
    var hd = el("span", "handles"); for (var i = 0; i < 4; i++) hd.appendChild(el("i"));
    win.appendChild(bar); win.appendChild(img); win.appendChild(hd);
    return win;
  }
  function byslug(s) { for (var i = 0; i < NJ.PROJECTS.length; i++) if (NJ.PROJECTS[i].slug === s) return NJ.PROJECTS[i]; return null; }

  /* ---------- 6. hero : la table de montage ---------- */
  var HERO = [
    { slug: "cibanque", src: "assets/img/cibanque-dashboard.webp", w: 1586, h: 726 },
    { slug: "dona-ci", src: "assets/img/dona-accueil.webp", w: 1180, h: 539 },
    { slug: "passerelle", src: "assets/img/passerelle-accueil.webp", w: 1180, h: 553 },
    { slug: "pigier-connect", src: "assets/img/pigier-formations.webp", w: 1180, h: 476 }
  ];
  var stage = $("#heroStage");
  HERO.forEach(function (h) {
    var p = byslug(h.slug);
    var slot = el("div", "slot"), bob = el("div", "bob");
    var win = makeWin(h.src, h.w, h.h, p.url, p.name);
    win.setAttribute("data-cur", "throw");
    win.querySelector("img").loading = "eager";
    bob.appendChild(win); slot.appendChild(bob); stage.appendChild(slot);
    new Throwable(win, { onTap: function (n) { openCase(h.slug, n); } });
  });
  stage.appendChild($(".hero-hint"));

  /* ---------- 7. projets : une scène par projet ---------- */
  var scenesBox = $("#scenes");
  function renderScenes() {
    scenesBox.textContent = "";
    $("#workCount").textContent = String(NJ.PROJECTS.length).padStart(2, "0");
    NJ.PROJECTS.forEach(function (p) {
      var L = p[lang];
      var sc = el("article", "scene");
      sc.setAttribute("data-slug", p.slug);
      sc.style.setProperty("--len", String(Math.max.apply(null, p.name.split(" ").map(function (w) { return w.length; })) + 0.5));
      var tx = el("div", "scene-text");
      var meta = el("div", "scene-meta");
      meta.appendChild(el("span", "chip" + (p.status === "wip" ? " wip" : ""), t("status." + p.status)));
      meta.appendChild(el("span", "", L.kind));
      tx.appendChild(meta);
      var h3 = el("h3", "scene-name"), nb = el("button", "", p.name);
      nb.type = "button";
      nb.addEventListener("click", function () { openCase(p.slug, sc.querySelector(".win")); });
      h3.appendChild(nb); tx.appendChild(h3);
      tx.appendChild(el("p", "scene-line", L.line));
      var st = el("ul", "stack");
      p.stack.forEach(function (id) { var li = el("li"); li.appendChild(toolIcon(id)); li.appendChild(D.createTextNode(toolName(id))); st.appendChild(li); });
      tx.appendChild(st);
      var links = el("div", "scene-links");
      var cs = el("button", "btn btn-ink mag"); cs.type = "button";
      cs.appendChild(el("span", "", t("work.case"))); cs.appendChild(icon("arrow"));
      cs.addEventListener("click", function () { openCase(p.slug, sc.querySelector(".win")); });
      links.appendChild(cs);
      if (safeUrl(p.demo)) { var a = el("a", "btn btn-line", t("work.visit")); a.href = p.demo; a.target = "_blank"; a.rel = "noopener noreferrer"; links.appendChild(a); }
      if (safeUrl(p.code)) { var c = el("a", "btn btn-line"); c.href = p.code; c.target = "_blank"; c.rel = "noopener noreferrer"; c.appendChild(icon("gh")); c.appendChild(el("span", "", t("work.code"))); links.appendChild(c); }
      tx.appendChild(links);

      var media = el("div", "scene-media"), tilt = el("div", "tilt");
      var win = makeWin(p.cover, p.size[0], p.size[1], p.url, p.name + " · " + L.line);
      win.setAttribute("data-cur", "open");
      tilt.appendChild(win); media.appendChild(tilt);
      sc.appendChild(tx); sc.appendChild(media);
      scenesBox.appendChild(sc);
      new Throwable(win, { onTap: function (n) { openCase(p.slug, n); } });
    });
  }
  function toolName(id) { for (var i = 0; i < NJ.TOOLS.length; i++) if (NJ.TOOLS[i].id === id) return NJ.TOOLS[i].name; return id; }

  /* ---------- 8. outils ---------- */
  function usesOf(id) {
    return NJ.PROJECTS.filter(function (p) {
      if (id === "vscode") return true;
      if (id === "github") return !!p.code || !!p.demo;
      return p.stack.indexOf(id) > -1;
    }).map(function (p) { return p.name; });
  }
  function renderTools() {
    var g = $("#toolGrid"); g.textContent = "";
    NJ.TOOLS.forEach(function (tl, i) {
      var li = el("li", "rv"); li.style.setProperty("--d", (i * 0.05) + "s");
      var b = el("button", "tool"); b.type = "button";
      b.appendChild(toolIcon(tl.id)); b.appendChild(el("span", "", tl.name));
      function on() {
        $$(".tool", g).forEach(function (x) { x.classList.toggle("on", x === b); });
        g.classList.add("dim");
        var out = $("#toolOut"); out.textContent = t("tools.used") + " : ";
        if (lang === "en") out.textContent = t("tools.used") + ": ";
        out.appendChild(el("b", "", usesOf(tl.id).join(" · ")));
      }
      function off() {
        g.classList.remove("dim"); $$(".tool", g).forEach(function (x) { x.classList.remove("on"); });
        var out = $("#toolOut"); out.textContent = ""; out.appendChild(el("span", "", t("tools.idle")));
      }
      b.addEventListener("pointerenter", on); b.addEventListener("focus", on); b.addEventListener("click", on);
      b.addEventListener("pointerleave", function (e) { if (e.pointerType === "mouse") off(); });
      b.addEventListener("blur", off);
      li.appendChild(b); g.appendChild(li);
      reveal(li);
    });
  }

  /* ---------- 9. configurateur : composez votre site ---------- */
  var B = { type: "vitrine", sel: [], dirty: false };
  var PRESET = { vitrine: ["hero", "about", "services", "gallery", "contact"], landing: ["hero", "services", "reviews", "contact"], app: ["hero", "login", "dashboard", "contact"] };
  var ART = {
    hero: [[58, 40, "d"], [38, 40, ""]], about: [[30, 40, ""], [66, 12, ""]], services: [[31, 40, ""], [31, 40, ""], [31, 40, ""]],
    gallery: [[23, 40, ""], [23, 40, ""], [23, 40, ""], [23, 40, ""]], catalog: [[18, 40, ""], [18, 40, ""], [18, 40, ""], [18, 40, ""], [18, 40, ""]],
    booking: [[60, 40, ""], [34, 16, "k"]], reviews: [[47, 30, ""], [47, 30, ""]], faq: [[72, 10, ""], [22, 10, "d"]],
    map: [[96, 40, "m"]], login: [[44, 40, ""], [22, 16, "d"]], dashboard: [[18, 40, "d"], [24, 40, ""], [24, 40, ""], [26, 40, ""]],
    contact: [[44, 40, ""], [30, 40, ""], [18, 16, "k"]]
  };
  function mod(id) { for (var i = 0; i < NJ.MODULES.length; i++) if (NJ.MODULES[i].id === id) return NJ.MODULES[i]; }
  function order(list) { return NJ.MODULES.map(function (m) { return m.id; }).filter(function (id) { return list.indexOf(id) > -1; }); }
  var bTray = $("#bTray"), bBlocks = $("#bBlocks"), bWindow = $("#bWindow");

  function renderTray() {
    bTray.textContent = "";
    NJ.MODULES.forEach(function (m) {
      var li = el("li"), b = el("button", "mod", m[lang]);
      b.type = "button"; b.setAttribute("data-id", m.id); b.setAttribute("aria-pressed", String(B.sel.indexOf(m.id) > -1));
      li.appendChild(b); bTray.appendChild(li);
      dragSource(b, m.id, "tray");
    });
  }
  function renderBlocks(addedId) {
    bBlocks.textContent = "";
    B.sel.forEach(function (id) {
      var m = mod(id), li = el("li", "blk"); li.setAttribute("data-id", id);
      if (addedId !== id) li.style.animation = "none";
      var art = el("div", "blk-art");
      (ART[id] || []).forEach(function (a) {
        var i = el("i", a[2] ? "is-" + a[2] : "");
        i.style.flexBasis = a[0] + "%"; i.style.height = a[1] + "px";
        if (a[2] === "d") i.style.background = "var(--ink)";
        if (a[2] === "k") i.style.background = "var(--key)";
        if (a[2] === "m") i.style.background = "repeating-linear-gradient(45deg, var(--paper-3) 0 8px, var(--paper) 8px 16px)";
        art.appendChild(i);
      });
      var x = el("button", "blk-x"); x.type = "button"; x.setAttribute("aria-label", "× " + m[lang]); x.appendChild(icon("close"));
      x.addEventListener("click", function () { toggleMod(id, false); });
      li.appendChild(el("span", "blk-lbl", m[lang])); li.appendChild(art); li.appendChild(x);
      bBlocks.appendChild(li);
      dragSource(li, id, "block");
    });
    $("#bEmpty").hidden = B.sel.length > 0;
    $$(".mod", bTray).forEach(function (b) { b.setAttribute("aria-pressed", String(B.sel.indexOf(b.getAttribute("data-id")) > -1)); });
    updateBrief();
  }
  function toggleMod(id, on) {
    var has = B.sel.indexOf(id) > -1;
    if (on === undefined) on = !has;
    if (on && !has) B.sel = order(B.sel.concat(id));
    if (!on && has) B.sel = B.sel.filter(function (x) { return x !== id; });
    B.dirty = true;
    renderBlocks(on ? id : null);
  }
  function sizeLevel() {
    var s = { landing: 0, vitrine: 1, app: 3 }[B.type];
    B.sel.forEach(function (id) { s += mod(id).w; });
    return B.sel.length === 0 ? 0 : s <= 6 ? 1 : s <= 11 ? 2 : 3;
  }
  function briefText() {
    var typeLabel = t("b.t." + B.type);
    var names = B.sel.map(function (id) { return mod(id)[lang]; });
    var lvl = sizeLevel();
    if (lang === "fr") {
      var tl = typeLabel.toLowerCase();
      var de = /^[aeiouyéèh]/i.test(tl) ? "d'" : "de ";
      return "Bonjour Junior, j'ai un projet " + de + tl + (names.length ? " avec : " + names.join(", ") : "") + ". " + t("b.msg.size") + " : " + (lvl ? t("b.s" + lvl).toLowerCase() : "?") + ".";
    }
    return "Hi Junior, I have a project: a " + typeLabel.toLowerCase() + (names.length ? " with " + names.join(", ") : "") + ". " + t("b.msg.size") + ": " + (lvl ? t("b.s" + lvl).toLowerCase() : "?") + ".";
  }
  function updateBrief() {
    var n = B.sel.length, lvl = sizeLevel();
    $("#bCount").textContent = n + " " + t("b.blocks");
    $("#bUrl").textContent = { vitrine: "votre-site.com", landing: "offre.votre-site.com", app: "app.votre-site.com" }[B.type];
    $("#bSize").textContent = lvl ? t("b.s" + lvl) : "–";
    $("#bMeter").setAttribute("data-l", String(lvl));
    var wa = $("#bWa");
    wa.href = "https://wa.me/" + NJ.CONTACT.whatsapp + "?text=" + encodeURIComponent(briefText());
    wa.setAttribute("aria-disabled", String(n === 0));
    $("#bForm").setAttribute("aria-disabled", String(n === 0));
  }
  $$("#bTypes button").forEach(function (b) {
    b.addEventListener("click", function () {
      B.type = b.getAttribute("data-type");
      $$("#bTypes button").forEach(function (x) { x.setAttribute("aria-pressed", String(x === b)); });
      if (!B.dirty || !B.sel.length) { B.sel = PRESET[B.type].slice(); B.dirty = false; renderBlocks(); }
      else updateBrief();
    });
  });
  $("#bReset").addEventListener("click", function () { B.sel = []; B.dirty = true; renderBlocks(); });
  $("#bForm").addEventListener("click", function () {
    if (!B.sel.length) return;
    var f = $("#form");
    f.elements.message.value = briefText();
    $$('input[name="subject"]', f).forEach(function (r) { r.checked = r.value === "project"; });
    updateCount();
    $("#contact").scrollIntoView({ behavior: reduce ? "auto" : "smooth" });
    setTimeout(function () { f.elements.name.focus({ preventScroll: true }); }, 900);
  });

  /* glisser un bloc : dedans = ajouté, dehors = il revient à sa place */
  function dragSource(node, id, from) {
    var st = null;
    node.addEventListener("pointerdown", function (e) {
      if (e.button !== 0 && e.pointerType === "mouse") return;
      if (e.target.closest(".blk-x")) return;
      st = { x: e.clientX, y: e.clientY, id: e.pointerId, g: null, s: [], t: now() };
      try { node.setPointerCapture(e.pointerId); } catch (err) {}
    });
    node.addEventListener("pointermove", function (e) {
      if (!st) return;
      var dx = e.clientX - st.x, dy = e.clientY - st.y;
      if (!st.g && Math.abs(dx) + Math.abs(dy) > 6) {
        var r = node.getBoundingClientRect();
        var g = el("div", "mod ghost", mod(id)[lang]);
        body.appendChild(g);
        st.g = g; st.ox = r.left + (from === "block" ? 12 : 0); st.oy = r.top + (from === "block" ? 8 : 0);
        st.w = g.offsetWidth; st.h = g.offsetHeight;
        if (from === "tray") node.style.opacity = ".35";
      }
      if (st.g) {
        e.preventDefault();
        var gx = st.ox + dx, gy = st.oy + dy;
        st.gx = gx; st.gy = gy;
        st.g.style.transform = "translate3d(" + gx + "px," + gy + "px,0) rotate(" + clamp(dx * 0.03, -8, 8) + "deg)";
        st.s.push({ x: e.clientX, y: e.clientY, t: now() }); if (st.s.length > 6) st.s.shift();
        var over = inside(e.clientX, e.clientY, bWindow);
        bWindow.classList.toggle("hot", over);
        st.g.classList.toggle("over", over);
        Trails.pushXY("drag" + id, gx + st.w / 2, gy + st.h / 2); startLoop();
      }
    });
    function end(e) {
      if (!st) return;
      var s = st; st = null;
      bWindow.classList.remove("hot");
      node.style.opacity = "";
      if (!s.g) { if (from === "tray" && e.type === "pointerup") toggleMod(id); return; }
      var over = inside(e.clientX, e.clientY, bWindow);
      var a = s.s[0] || { x: e.clientX, y: e.clientY, t: now() }, b = s.s[s.s.length - 1] || a, dt = Math.max(8, b.t - a.t);
      var g = { node: s.g, x: s.gx, y: s.gy, vx: ((b.x - a.x) / dt) * 16.7, vy: ((b.y - a.y) / dt) * 16.7, r: 0, w: s.w, h: s.h, id: ++uid };
      if (from === "tray" && over) {
        toggleMod(id, true);
        var blk = bBlocks.querySelector('[data-id="' + id + '"]'), br = blk.getBoundingClientRect();
        g.tx = br.left + 12; g.ty = br.top - 8; g.vx *= .2; g.vy *= .2; g.k = 0.06; g.c = 0.42;
      } else if (from === "block" && !over) {
        toggleMod(id, false);
        var chip = bTray.querySelector('[data-id="' + id + '"]'), cr = chip.getBoundingClientRect();
        g.tx = cr.left; g.ty = cr.top;
        chip.style.opacity = "0";
        g.done = function () { chip.style.opacity = ""; };
      } else {
        var r = node.getBoundingClientRect();
        g.tx = r.left + (from === "block" ? 12 : 0); g.ty = r.top + (from === "block" ? -8 : 0);
        if (from === "tray") { node.style.opacity = "0"; g.done = function () { node.style.opacity = ""; }; }
      }
      Ghosts.add(g);
    }
    node.addEventListener("pointerup", end);
    node.addEventListener("pointercancel", end);
  }
  function inside(x, y, n) { var r = n.getBoundingClientRect(); return x >= r.left && x <= r.right && y >= r.top && y <= r.bottom; }

  /* ---------- 10. parcours : des calques sur une timeline ---------- */
  var MONTHS = {
    fr: ["janv.", "févr.", "mars", "avr.", "mai", "juin", "juil.", "août", "sept.", "oct.", "nov.", "déc."],
    en: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
  };
  function mIdx(s) { var p = s.split("-"); return +p[0] * 12 + (+p[1] - 1); }
  function mLabel(s) { var p = s.split("-"); return MONTHS[lang][+p[1] - 1] + " " + p[0]; }
  function renderPath() {
    var P = NJ.PATH, box = $("#layers"); box.textContent = "";
    var a = mIdx(P.start), z = mIdx(P.end), span = z - a;
    function pct(s, extra) { return ((mIdx(s) + (extra || 0) - a) / span) * 100; }
    var axis = el("div", "ly-axis"); axis.appendChild(el("span"));
    var yrs = el("div", "ly-years");
    for (var y = +P.start.slice(0, 4) + 1; y <= +P.end.slice(0, 4); y++) {
      var s = el("span", "", String(y)); s.style.left = pct(y + "-01") + "%"; yrs.appendChild(s);
    }
    axis.appendChild(yrs); box.appendChild(axis);
    P.layers.forEach(function (L, i) {
      var row = el("div", "ly-row"), lab = el("div", "ly-lab"), tr = el("div", "ly-track");
      var T = L[lang];
      var b = el("b", "", T[0]);
      if (L.now) b.appendChild(el("span", "ly-tag", t("path.now")));
      if (L.next) b.appendChild(el("span", "ly-tag next", t("path.next")));
      lab.appendChild(b);
      lab.appendChild(el("span", "", T[1] + " · " + (L.point ? mLabel(L.from) : mLabel(L.from) + " → " + mLabel(L.to))));
      if (L.link) { var ln = el("a", "", t("path.cert")); ln.href = L.link; ln.target = "_blank"; ln.rel = "noopener"; lab.appendChild(ln); }
      if (L.point) {
        var pt = el("i", "ly-pt"); pt.style.setProperty("--x", pct(L.from, 0.5) + "%"); tr.appendChild(pt);
      } else {
        var bar = el("i", "ly-bar" + (L.now ? " now" : "") + (L.next ? " next" : ""));
        bar.style.setProperty("--x", pct(L.from) + "%");
        bar.style.setProperty("--w", (pct(L.to, 1) - pct(L.from)) + "%");
        tr.appendChild(bar);
      }
      row.style.setProperty("--d", (i * 0.07) + "s");
      row.appendChild(lab); row.appendChild(tr); box.appendChild(row);
      reveal(row);
    });
    var td = el("div", "ly-today"); td.appendChild(el("span", "", t("path.today")));
    box.appendChild(td);
    placeToday();
  }
  function placeToday() {
    var P = NJ.PATH, box = $("#layers"), td = $(".ly-today", box), tr = $(".ly-track", box);
    if (!td || !tr) return;
    var a = mIdx(P.start), z = mIdx(P.end);
    var d = new Date(), cur = d.getFullYear() * 12 + d.getMonth() + d.getDate() / 31;
    if (cur < a || cur > z) cur = mIdx(P.today) + 0.9;
    var br = box.getBoundingClientRect(), r = tr.getBoundingClientRect();
    td.style.left = (r.left - br.left + ((cur - a) / (z - a)) * r.width) + "px";
    td.style.top = ($(".ly-row", box).offsetTop) + "px";
    var yrs = $(".ly-years", box);
    if (yrs) yrs.style.setProperty("--axis-h", (box.offsetHeight - 30) + "px");
  }

  /* ---------- 11. timeline de navigation ---------- */
  var secs = $$("[data-nav]"), kfBox = $("#tlKfs"), head = $("#tlHead"), track = $("#tlTrack"), fill = $("#tlFill");
  var kfs = [], kpos = [], maxScroll = 1;
  function buildKfs() {
    kfBox.textContent = "";
    kfs = secs.map(function (s) {
      var b = el("button", "tl-kf"); b.type = "button";
      b.setAttribute("data-label", t(s.getAttribute("data-nav")));
      b.setAttribute("aria-label", t(s.getAttribute("data-nav")));
      b.addEventListener("click", function () { s.scrollIntoView({ behavior: reduce ? "auto" : "smooth" }); });
      kfBox.appendChild(b);
      return b;
    });
  }
  function layoutKfs() {
    maxScroll = Math.max(1, D.documentElement.scrollHeight - innerHeight);
    kpos = secs.map(function (s) { return clamp((s.getBoundingClientRect().top + scrollY) / maxScroll, 0, 1); });
    kfs.forEach(function (b, i) { b.style.left = (kpos[i] * 100) + "%"; });
  }
  var lastSec = -1;
  function updateTl() {
    var p = clamp(scrollY / maxScroll, 0, 1);
    var w = kfBox.offsetWidth;
    head.style.left = (10 + p * w) + "px";
    fill.style.width = (10 + p * w) + "px";
    head.setAttribute("aria-valuenow", String(Math.round(p * 100)));
    var secT = p * 90, mm = Math.floor(secT / 60), ss = Math.floor(secT % 60), ff = Math.floor((secT % 1) * 25);
    $("#tlTc").textContent = "00:" + String(mm).padStart(2, "0") + ":" + String(ss).padStart(2, "0") + ":" + String(ff).padStart(2, "0");
    var cur = 0, y = scrollY + innerHeight * 0.45;
    secs.forEach(function (s, i) { if (s.offsetTop <= y) cur = i; });
    if (scrollY >= maxScroll - 4) cur = secs.length - 1;
    kfs.forEach(function (b, i) { b.classList.toggle("on", i <= cur); b.classList.toggle("cur", i === cur); });
    if (cur !== lastSec) { lastSec = cur; $("#tlSec").textContent = t(secs[cur].getAttribute("data-nav")); }
  }
  (function scrub() {
    var on = false;
    function go(e) {
      var r = kfBox.getBoundingClientRect();
      var p = clamp((e.clientX - r.left) / r.width, 0, 1);
      window.scrollTo({ top: p * maxScroll, behavior: "instant" });
    }
    track.addEventListener("pointerdown", function (e) {
      if (e.target.closest(".tl-kf")) return;
      on = true; root.style.scrollBehavior = "auto";
      try { track.setPointerCapture(e.pointerId); } catch (err) {}
      go(e);
    });
    track.addEventListener("pointermove", function (e) { if (on) go(e); });
    function stop() { on = false; root.style.scrollBehavior = ""; }
    track.addEventListener("pointerup", stop); track.addEventListener("pointercancel", stop);
    head.addEventListener("keydown", function (e) {
      var d = e.key === "ArrowRight" ? 0.05 : e.key === "ArrowLeft" ? -0.05 : 0;
      if (!d) return;
      e.preventDefault();
      window.scrollTo({ top: clamp(scrollY / maxScroll + d, 0, 1) * maxScroll });
    });
  })();

  /* ---------- 12. défilement : scènes, ligne du processus, parallaxe ---------- */
  var scrollQueued = false;
  function onScroll() { if (!scrollQueued) { scrollQueued = true; requestAnimationFrame(frame); } }
  function frame() {
    scrollQueued = false;
    var vh = innerHeight;
    $$(".scene").forEach(function (sc) {
      var r = sc.getBoundingClientRect();
      if (r.bottom < -200 || r.top > vh + 200) return;
      var p = reduce ? 1 : clamp((vh - r.top) / (vh * 0.7), 0, 1);
      var e = 1 - Math.pow(1 - p, 3);
      sc.style.setProperty("--p", e.toFixed(3));
    });
    var ps = $("#procSteps");
    if (ps) { var pr = ps.getBoundingClientRect(); ps.style.setProperty("--line", clamp((vh * 0.85 - pr.top) / (vh * 0.5), 0, 1).toFixed(3)); }
    if (!reduce && scrollY < vh * 1.3) {
      $$(".hero-stage .slot").forEach(function (s, i) { s.style.translate = "0 " + (-scrollY * [0.12, 0.26, 0.2, 0.34][i]).toFixed(1) + "px"; });
    }
    updateTl();
  }
  window.addEventListener("scroll", onScroll, { passive: true });

  /* révélations */
  var io = "IntersectionObserver" in window ? new IntersectionObserver(function (es) {
    es.forEach(function (e) { if (e.isIntersecting) { e.target.classList.add("in"); io.unobserve(e.target); } });
  }, { rootMargin: "0px 0px -12% 0px", threshold: 0.05 }) : null;
  function reveal(n) { if (io) io.observe(n); else n.classList.add("in"); }

  /* ---------- 13. étude de cas ---------- */
  var caseEl = $("#case"), caseIn = $("#caseIn"), caseScroll = $("#caseScroll"), lastFocus = null, curCase = null, origin = null;
  function setClip(r) {
    if (!r) { caseEl.style.setProperty("--ct", "50%"); caseEl.style.setProperty("--cr", "50%"); caseEl.style.setProperty("--cb", "50%"); caseEl.style.setProperty("--cl", "50%"); return; }
    caseEl.style.setProperty("--ct", Math.max(0, r.top) + "px");
    caseEl.style.setProperty("--cr", Math.max(0, innerWidth - r.right) + "px");
    caseEl.style.setProperty("--cb", Math.max(0, innerHeight - r.bottom) + "px");
    caseEl.style.setProperty("--cl", Math.max(0, r.left) + "px");
  }
  function renderCase(p) {
    var L = p[lang], i = NJ.PROJECTS.indexOf(p), n = NJ.PROJECTS.length;
    $("#caseIdx").textContent = String(i + 1).padStart(2, "0") + " / " + String(n).padStart(2, "0");
    caseIn.textContent = "";
    var head = el("header", "cs-head");
    var meta0 = el("div", "scene-meta");
    meta0.appendChild(el("span", "chip" + (p.status === "wip" ? " wip" : ""), t("status." + p.status)));
    meta0.appendChild(el("span", "", p.year));
    head.appendChild(meta0);
    var h = el("h2", "cs-name", p.name); h.id = "caseName"; head.appendChild(h);
    head.appendChild(el("p", "cs-line", L.line));
    caseIn.appendChild(head);

    var meta = el("dl", "cs-meta");
    function cell(k, node) { var d = el("div"); d.appendChild(el("dt", "", t(k))); var dd = el("dd"); dd.appendChild(node); d.appendChild(dd); meta.appendChild(d); }
    cell("cs.kind", D.createTextNode(L.kind));
    var st = el("ul", "stack"); p.stack.forEach(function (id) { var li = el("li"); li.appendChild(toolIcon(id)); li.appendChild(D.createTextNode(toolName(id))); st.appendChild(li); });
    cell("cs.stack", st);
    cell("cs.state", D.createTextNode(t("status." + p.status)));
    var lk = el("div", "cs-links");
    if (safeUrl(p.demo)) { var a = el("a", "btn btn-key"); a.href = p.demo; a.target = "_blank"; a.rel = "noopener noreferrer"; a.appendChild(el("span", "", t("work.visit"))); a.appendChild(icon("arrow")); lk.appendChild(a); }
    if (safeUrl(p.code)) { var c = el("a", "btn btn-line"); c.href = p.code; c.target = "_blank"; c.rel = "noopener noreferrer"; c.appendChild(icon("gh")); c.appendChild(el("span", "", t("work.code"))); lk.appendChild(c); }
    if (!p.demo) lk.appendChild(el("span", "cs-nodemo", t("cs.nodemo")));
    var dl = el("div"); dl.appendChild(el("dt", "", lang === "fr" ? "Liens" : "Links")); var ddl = el("dd"); ddl.appendChild(lk); dl.appendChild(ddl); meta.appendChild(dl);
    caseIn.appendChild(meta);

    var reel = el("div", "cs-reel");
    p.gallery.forEach(function (g) {
      var fig = el("figure");
      var size = g.src.indexOf("dashboard") > -1 ? [1586, 726] : g.src.indexOf("login") > -1 ? [1383, 628] : g.src.indexOf("formations") > -1 ? [1180, 476] : p.size;
      var w = makeWin(g.src, size[0], size[1], p.url, p.name + " · " + g[lang]);
      w.querySelector("img").loading = "eager";
      fig.appendChild(w); fig.appendChild(el("figcaption", "", g[lang]));
      reel.appendChild(fig);
    });
    caseIn.appendChild(reel);
    if (p.gallery.length > 1) { var dr = el("p", "cs-drag"); dr.appendChild(el("i", "kf-ico")); dr.appendChild(D.createTextNode(t("cs.drag"))); caseIn.appendChild(dr); reel.setAttribute("data-cur", "drag"); flingScroll(reel); }

    var cols = el("div", "cs-cols");
    var c1 = el("div"); c1.appendChild(el("h3", "", t("cs.idea"))); c1.appendChild(el("p", "", L.idea)); cols.appendChild(c1);
    [["cs.built", L.built], ["cs.learned", L.learned]].forEach(function (pair) {
      var c = el("div"); c.appendChild(el("h3", "", t(pair[0]))); var ul = el("ul");
      pair[1].forEach(function (x) { ul.appendChild(el("li", "", x)); }); c.appendChild(ul); cols.appendChild(c);
    });
    caseIn.appendChild(cols);
    var wh = el("div", "cs-where"); wh.appendChild(el("h3", "", t("cs.where"))); wh.appendChild(el("p", "", L.state)); caseIn.appendChild(wh);

    var nx = NJ.PROJECTS[(i + 1) % n];
    var nb = el("button", "cs-next"); nb.type = "button";
    nb.appendChild(el("span", "", t("cs.next"))); nb.appendChild(el("b", "", nx.name));
    nb.addEventListener("click", function () { go("#/projet/" + nx.slug); });
    caseIn.appendChild(nb);
  }
  function setHash(h) {
    try { history.pushState(null, "", h || (location.pathname + location.search)); }
    catch (e) { location.hash = h || ""; }
  }
  function go(hash) { if (location.hash !== hash) setHash(hash); route(); }
  function openCase(slug, fromNode) {
    origin = fromNode ? fromNode.getBoundingClientRect() : null;
    if (location.hash !== "#/projet/" + slug) setHash("#/projet/" + slug);
    route();
  }
  function showCase(p) {
    var wasOpen = !caseEl.hidden && caseEl.classList.contains("open");
    curCase = p.slug;
    renderCase(p);
    caseScroll.scrollTop = 0;
    if (wasOpen) { $("#caseClose").focus({ preventScroll: true }); return; }
    lastFocus = D.activeElement;
    setClip(origin);
    caseEl.hidden = false;
    body.classList.add("case-open");
    void caseEl.offsetWidth;
    requestAnimationFrame(function () { caseEl.classList.add("open"); });
    setTimeout(function () { $("#caseClose").focus({ preventScroll: true }); }, 60);
  }
  function hideCase() {
    if (caseEl.hidden) return;
    var node = curCase && $('.scene[data-slug="' + curCase + '"] .win');
    var r = node ? node.getBoundingClientRect() : null;
    setClip(r && r.bottom > 0 && r.top < innerHeight ? r : null);
    caseEl.classList.remove("open");
    body.classList.remove("case-open");
    curCase = null;
    setTimeout(function () { if (!caseEl.classList.contains("open")) caseEl.hidden = true; }, reduce ? 0 : 760);
    if (lastFocus && lastFocus.focus) lastFocus.focus({ preventScroll: true });
  }
  function route() {
    var m = /^#\/projet\/([a-z0-9-]+)$/.exec(location.hash);
    var p = m && byslug(m[1]);
    if (p) showCase(p); else hideCase();
  }
  window.addEventListener("popstate", route);
  window.addEventListener("hashchange", route);
  $("#caseClose").addEventListener("click", function () {
    setHash("");
    hideCase();
  });
  D.addEventListener("keydown", function (e) {
    if (e.key === "Escape" && !caseEl.hidden) $("#caseClose").click();
    if (e.key === "Tab" && !caseEl.hidden) {
      var f = $$("a[href], button:not([disabled])", caseEl).filter(function (x) { return x.offsetParent !== null; });
      if (!f.length) return;
      if (e.shiftKey && D.activeElement === f[0]) { e.preventDefault(); f[f.length - 1].focus(); }
      else if (!e.shiftKey && D.activeElement === f[f.length - 1]) { e.preventDefault(); f[0].focus(); }
    }
  });

  /* galerie qu'on "chasse" : on la lance, elle glisse avec de l'élan */
  function flingScroll(box) {
    var st = null, v = 0, raf = 0;
    box.addEventListener("pointerdown", function (e) {
      if (e.pointerType !== "mouse" || e.button !== 0) return;
      cancelAnimationFrame(raf);
      st = { x: e.clientX, s: box.scrollLeft, lx: e.clientX, lt: now() }; v = 0;
      box.classList.add("grabbing");
      try { box.setPointerCapture(e.pointerId); } catch (err) {}
    });
    box.addEventListener("pointermove", function (e) {
      if (!st) return;
      box.scrollLeft = st.s - (e.clientX - st.x);
      var tt = now(); v = (e.clientX - st.lx) / Math.max(1, tt - st.lt) * 16.7; st.lx = e.clientX; st.lt = tt;
    });
    function up() {
      if (!st) return; st = null; box.classList.remove("grabbing");
      (function glide() { if (Math.abs(v) < 0.4 || reduce) return; box.scrollLeft -= v; v *= 0.94; raf = requestAnimationFrame(glide); })();
    }
    box.addEventListener("pointerup", up); box.addEventListener("pointercancel", up);
  }

  /* ---------- 14. contact + formulaire ---------- */
  var C0 = NJ.CONTACT, mail = C0.user + "@" + C0.host;
  $("#mailLink").href = "mailto:" + mail;
  $("#mailText").textContent = mail;
  $("#waLink").href = "https://wa.me/" + C0.whatsapp;
  $("#liLink").href = C0.linkedin;
  $("#ghLink").href = C0.github;
  function toast(msg) { var tt = $("#toast"); tt.textContent = msg; tt.classList.add("on"); clearTimeout(toast.t); toast.t = setTimeout(function () { tt.classList.remove("on"); }, 1800); }
  $("#copyMail").addEventListener("click", function () {
    var b = this;
    function ok() { b.classList.add("ok"); b.lastChild.textContent = t("contact.copied"); toast(mail); setTimeout(function () { b.classList.remove("ok"); b.lastChild.textContent = t("contact.copy"); }, 1600); }
    if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(mail).then(ok, function () { location.href = "mailto:" + mail; });
    else location.href = "mailto:" + mail;
  });

  var form = $("#form"), fmsg = $("#formMsg"), fsend = $("#formSend");
  function updateCount() { $("#charCount").textContent = form.elements.message.value.length + " / 3000"; }
  form.elements.message.addEventListener("input", updateCount);
  new Throwable(form, { handles: [$(".win-bar", form)] });
  new Throwable($("#photoWin"), { handles: [$("#photoWin")] });
  $("#photoWin").setAttribute("data-cur", "throw");
  $(".win-bar", form).setAttribute("data-cur", "throw");
  form.addEventListener("submit", function (e) {
    e.preventDefault();
    var F = form.elements;
    var name = F.name.value.trim(), email = F.email.value.trim(), message = F.message.value.trim();
    var subj = (form.querySelector('input[name="subject"]:checked') || {}).value || "other";
    [F.name, F.email, F.message].forEach(function (x) { x.classList.remove("bad"); });
    var bad = [];
    if (name.length < 2 || name.length > 80) bad.push(F.name);
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email) || email.length > 120) bad.push(F.email);
    if (message.length < 10 || message.length > 3000) bad.push(F.message);
    fmsg.className = "f-msg";
    if (bad.length) { bad.forEach(function (x) { x.classList.add("bad"); }); bad[0].focus(); fmsg.textContent = t("f.invalid"); fmsg.classList.add("err"); return; }
    if (F._gotcha.value) { done(); return; }
    var lastSent = 0; try { lastSent = +localStorage.getItem("p07-nj-sent") || 0; } catch (err) {}
    if (Date.now() - lastSent < 60000) { fmsg.textContent = t("f.wait"); fmsg.classList.add("err"); return; }
    fsend.disabled = true; fsend.firstChild.textContent = t("f.sending");
    var labels = { project: "f.s.project", internship: "f.s.intern", collab: "f.s.collab", other: "f.s.other" };
    fetch(C0.formspree, {
      method: "POST",
      headers: { "Accept": "application/json", "Content-Type": "application/json" },
      body: JSON.stringify({ name: name, email: email, subject: NJ.I18N.fr[labels[subj]] || "Autre", message: message, _subject: "Portfolio · " + (NJ.I18N.fr[labels[subj]] || "Message") })
    }).then(function (r) {
      if (!r.ok) throw new Error("http");
      try { localStorage.setItem("p07-nj-sent", String(Date.now())); } catch (err) {}
      done();
    }).catch(function () {
      fmsg.textContent = t("f.err"); fmsg.classList.add("err");
    }).then(function () { fsend.disabled = false; fsend.firstChild.textContent = t("f.send"); });
  });
  function done() {
    form.reset(); updateCount(); fmsg.textContent = "";
    $(".form-body", form).hidden = true; $("#formDone").hidden = false;
  }
  $("#formAgain").addEventListener("click", function () { $(".form-body", form).hidden = false; $("#formDone").hidden = true; form.elements.name.focus(); });

  /* ---------- 15. intro : la timeline fait le rendu du site ---------- */
  function intro(then) {
    var box = $("#intro");
    if (root.classList.contains("no-intro")) { box.classList.add("gone"); then(); return; }
    var dur = 2100, t0 = now(), ended = false;
    var n = $(".il-n", box), j = $(".il-j", box), k = $(".il-k", box), hd = $("#introHead"), tc = $("#introTc");
    var marks = $$(".intro-kf", box);
    marks.forEach(function (m) { m.style.left = (+m.getAttribute("data-at") * 100) + "%"; });
    function ease(x) { return 1 - Math.pow(1 - x, 3); }
    function frameI(ts) {
      if (ended) return;
      var p = clamp((ts - t0) / dur, 0, 1);
      hd.style.left = (p * 100) + "%";
      tc.textContent = "00:00:" + String(Math.floor(p * 2)).padStart(2, "0") + ":" + String(Math.floor((p * 50) % 25)).padStart(2, "0");
      marks.forEach(function (m) { m.classList.toggle("on", p >= +m.getAttribute("data-at")); });
      n.style.strokeDashoffset = String(1 - ease(clamp((p - 0.12) / 0.34, 0, 1)));
      j.style.strokeDashoffset = String(1 - ease(clamp((p - 0.42) / 0.3, 0, 1)));
      var kp = clamp((p - 0.72) / 0.18, 0, 1), ov = kp < 1 ? ease(kp) * 1.15 : 1;
      k.style.transform = "scale(" + (kp >= 1 ? 1 : ov) + ") rotate(" + (-90 + 90 * ease(kp)) + "deg)";
      if (p < 1) requestAnimationFrame(frameI); else finish();
    }
    function finish() {
      if (ended) return; ended = true;
      try { sessionStorage.setItem("p07-nj-intro", "1"); } catch (e) {}
      box.classList.add("out-1");
      setTimeout(function () { box.classList.add("out-2"); then(); }, 560);
      setTimeout(function () { box.classList.add("gone"); }, 1300);
    }
    $("#introSkip").addEventListener("click", function () { n.style.strokeDashoffset = "0"; j.style.strokeDashoffset = "0"; k.style.transform = "none"; finish(); });
    requestAnimationFrame(frameI);
  }

  /* ---------- 16. démarrage ---------- */
  function layout() { layoutKfs(); placeToday(); onScroll(); }
  onLang.push(function (init) {
    renderScenes(); renderTools(); renderTray(); renderBlocks(); renderPath(); buildKfs(); lastSec = -1;
    if (!init) $$(".tool-grid .rv, .ly-row").forEach(function (n) { n.classList.add("in"); });
  });

  hydrateIcons(D);
  B.sel = PRESET.vitrine.slice();
  applyLang(true);
  $("#year").textContent = String(new Date().getFullYear());
  $$(".wipe, .rv, .contact-title .hl").forEach(reveal);
  window.addEventListener("resize", layout);
  window.addEventListener("load", layout);
  if (D.fonts && D.fonts.ready) D.fonts.ready.then(layout);
  layout();

  intro(function () {
    body.classList.add("ready");
    setTimeout(layout, 50);
    if (/^#\/projet\//.test(location.hash)) route();
  });
})();
