# Portfolio · Junior N'Goran

Portfolio de développeur web junior : projets, services pour les clients, parcours et contact.
Site statique (HTML, CSS, JavaScript pur), sans framework, sans librairie, sans aucune requête vers un autre site.

**En ligne :** https://njdev154.github.io/portfolio-07/

## L'idée

Le site est une **table de montage**, comme dans un logiciel de motion design :

- **L'intro** est une timeline : la tête de lecture avance, les images-clés s'allument, le logo se dessine, puis un fond vert (chroma key) balaie l'écran et révèle le site. Une fois par visite, bouton « Passer ».
- **Chaque fenêtre est un objet physique.** On l'attrape, on la lance : elle part, tourne, ralentit et **revient à sa place comme un boomerang**, en laissant sa courbe de mouvement avec ses images-clés.
- **La navigation est une timeline** en bas de l'écran : une image-clé par section, une tête de lecture qui suit le défilement, un timecode. On peut cliquer une image-clé ou faire glisser la tête de lecture pour parcourir la page.
- **Les titres apparaissent derrière un cache vert**, comme une incrustation.

## Les sections

| Section | Ce qu'elle fait |
| --- | --- |
| Accueil | Ce que je fais en une phrase, mon statut (stage + disponible), deux actions. Quatre projets en fenêtres lançables. |
| Projets | Une scène par projet : statut, type, outils, liens. Le nom s'élargit et la capture se redresse au défilement. Clic = étude de cas. |
| Étude de cas | S'ouvre depuis la fenêtre cliquée. L'idée, ce que j'ai construit, ce que j'ai appris, où en est le projet. Galerie qu'on fait glisser avec élan. Lien partageable (`#/projet/cibanque`). |
| Outils | Les vrais outils, avec leur logo. Survoler un outil montre dans quels projets il a servi. |
| Services | Quatre offres claires pour les clients. **Configurateur** : on glisse des blocs dans une fenêtre de navigateur, on voit la maquette se construire, l'envergure s'estime, et le brief part sur WhatsApp ou dans le formulaire. Puis les 4 étapes de travail. |
| Parcours | Une timeline à calques : chaque étape est une barre sur les années, avec un repère « Aujourd'hui ». |
| À propos | Portrait (lançable lui aussi), présentation courte, façon de travailler, infos utiles, CV. |
| Contact | Email copiable, WhatsApp, LinkedIn, GitHub et un formulaire (Formspree) dans une fenêtre qu'on peut lancer. |

Le tout en **français et en anglais** (bouton FR / EN, choix mémorisé), responsive, utilisable au clavier.

## Structure

```
index.html            la page
404.html              page d'erreur « Image manquante » (servie par GitHub Pages)
css/style.css         tout le design (couleurs et polices tout en haut, dans :root)
css/404.css           styles de la page 404
css/noscript.css      affichage propre si JavaScript est désactivé
js/boot.js            active les animations et décide si l'intro joue
js/content.js         LE CONTENU : projets, outils, parcours, blocs du configurateur, textes FR/EN
js/icons.js           logos des outils et icônes (SVG)
js/app.js             physique, timeline, configurateur, étude de cas, formulaire, intro
assets/fonts/         Archivo (police variable) et JetBrains Mono, hébergées sur le site
assets/img/           captures des projets (WebP), portrait, logo, icônes, image de partage
assets/docs/          CV et certificat (PDF)
```

## Modifier le contenu

Presque tout se change dans **`js/content.js`** :

- **Ajouter un projet** : copie un bloc de `NJ.PROJECTS`, change `slug`, `name`, `status` (`live` ou `wip`), `stack`, les liens, les images (dans `assets/img/`) et les textes `fr` / `en`. Il apparaît dans les scènes, les outils et les études de cas.
- **Parcours** : `NJ.PATH.layers`. `from` / `to` au format `AAAA-MM`. `now: true` = en cours, `next: true` = à venir, `point: true` = un événement ponctuel.
- **Configurateur** : `NJ.MODULES` (le `w` est le poids dans l'estimation de taille).
- **Contact** : `NJ.CONTACT` (email, WhatsApp, LinkedIn, GitHub, adresse Formspree).
- **Textes** : `NJ.I18N.fr` et `NJ.I18N.en`.
- **CV** : remplace `assets/docs/cv-ngoran-junior.pdf` en gardant le même nom.
- **Couleurs** : le bloc `:root` en haut de `css/style.css`.

## Mettre en ligne (GitHub Pages, gratuit)

1. Crée un dépôt nommé **exactement** `njdev154.github.io`.
2. Mets tous les fichiers de ce dossier à la racine (y compris `.nojekyll`).
3. *Settings → Pages → Deploy from a branch → `main` / `(root)`*.
4. Le site est en ligne en une minute sur https://njdev154.github.io/portfolio-07/.

Si tu utilises un autre nom de dépôt (ex. `portfolio`), mets à jour les adresses dans `index.html` (canonical, og:url, og:image), `robots.txt`, `sitemap.xml`, et les liens commençant par `/` dans `404.html`.

Tester en local : `python3 -m http.server` dans le dossier, puis http://localhost:8000 (ou l'extension Live Server de VS Code).

## Sécurité

- **Aucune dépendance, aucun script externe**, aucun CDN, aucun traceur.
- **Content Security Policy stricte** : seuls les fichiers du site s'exécutent ; seul Formspree est autorisé, uniquement pour envoyer le formulaire.
- **Aucun HTML injecté depuis une saisie** : tout le contenu est inséré en texte. Les liens externes sont filtrés (https uniquement) et ouverts en `noopener noreferrer`.
- **Formulaire** : validation, longueurs maximales, piège à robots (honeypot), un message par minute au maximum.
- **Email assemblé en JavaScript** pour gêner les robots collecteurs.
- **Aucun secret dans le code.** L'identifiant Formspree est public par nature.
- `prefers-reduced-motion` respecté : l'intro est sautée et les animations sont coupées pour qui le demande.

## Licence des polices

Archivo et JetBrains Mono sont sous licence SIL Open Font License 1.1 (voir `assets/fonts/LICENSE-fonts.txt`).
