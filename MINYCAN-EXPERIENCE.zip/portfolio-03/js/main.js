/* ============================================================
   Portfolio N'Goran Junior — Motion Edition
   Curseur contextuel · rideau d'intro · révélations ·
   compteurs · filtres · bilingue FR/EN · formulaire · horloge
   ============================================================ */
(() => {
  "use strict";
  const reduced = matchMedia("(prefers-reduced-motion: reduce)").matches;
  const finePointer = matchMedia("(hover: hover) and (pointer: fine)").matches;

  /* ---------- 1. Rideau d'intro (une fois par session) ---------- */
  const intro = document.querySelector(".intro");
  if (intro && !reduced) {
    let done = false;
    const finish = () => {
      if (done) return; done = true;
      intro.classList.add("done");
      document.documentElement.classList.remove("lock");
      try { sessionStorage.setItem("p03-pf-seen", "1"); } catch (e) {}
      setTimeout(() => intro.remove(), 1000);
    };
    try {
      if (sessionStorage.getItem("p03-pf-seen")) { finish(); }
      else {
        document.documentElement.classList.add("lock");
        const t = setTimeout(finish, 2600);
        intro.querySelector(".intro-skip")?.addEventListener("click", () => { clearTimeout(t); finish(); });
      }
    } catch (e) { finish(); }
  } else if (intro) { intro.remove(); }

  /* ---------- 2. Curseur contextuel ---------- */
  const cursor = document.querySelector(".cursor");
  if (cursor && finePointer && !reduced) {
    document.body.classList.add("cursor-on");
    const label = cursor.querySelector(".cursor-label");
    let x = -100, y = -100, tx = -100, ty = -100, raf = 0;
    const loop = () => {
      x += (tx - x) * 0.2; y += (ty - y) * 0.2;
      cursor.style.transform = `translate(${x}px,${y}px) translate(-50%,-50%)`;
      raf = requestAnimationFrame(loop);
    };
    addEventListener("pointermove", (e) => {
      tx = e.clientX; ty = e.clientY;
      if (!raf) loop();
      const t = e.target instanceof Element ? e.target : null;
      const zone = t?.closest("[data-cursor]");
      const link = t?.closest("a,button");
      cursor.classList.toggle("link", !!link && !zone);
      if (zone) { label.textContent = zone.dataset.cursor || "VOIR"; cursor.classList.add("badge"); cursor.classList.remove("link"); }
      else cursor.classList.remove("badge");
    }, { passive: true });
    document.documentElement.addEventListener("pointerleave", () => { cancelAnimationFrame(raf); raf = 0; cursor.style.opacity = "0"; });
    document.documentElement.addEventListener("pointerenter", () => { cursor.style.opacity = ""; });
  }

  /* ---------- 3. Boutons magnétiques ---------- */
  if (finePointer && !reduced) {
    document.querySelectorAll("[data-magnet]").forEach((el) => {
      el.addEventListener("pointermove", (e) => {
        const r = el.getBoundingClientRect();
        const dx = Math.max(-6, Math.min(6, (e.clientX - (r.left + r.width / 2)) * 0.12));
        const dy = Math.max(-6, Math.min(6, (e.clientY - (r.top + r.height / 2)) * 0.12));
        el.style.transform = `translate(${dx}px,${dy}px)`;
      });
      el.addEventListener("pointerleave", () => { el.style.transform = ""; });
    });
  }

  /* ---------- 4. Révélations au scroll ---------- */
  const io = new IntersectionObserver((entries) => {
    entries.forEach((en) => { if (en.isIntersecting) { en.target.classList.add("in"); io.unobserve(en.target); } });
  }, { threshold: 0.12, rootMargin: "0px 0px -6% 0px" });
  document.querySelectorAll(".reveal").forEach((el) => io.observe(el));

  /* ---------- 5. Compteurs animés ---------- */
  const cio = new IntersectionObserver((entries) => {
    entries.forEach((en) => {
      if (!en.isIntersecting) return;
      const b = en.target, target = parseInt(b.dataset.count || "0", 10);
      cio.unobserve(b);
      if (reduced || !target) { b.firstChild.nodeValue = target; return; }
      const t0 = performance.now(), dur = 1400;
      const tick = (t) => {
        const p = Math.min(1, (t - t0) / dur), e = 1 - Math.pow(1 - p, 3);
        b.firstChild.nodeValue = Math.round(target * e);
        if (p < 1) requestAnimationFrame(tick);
      };
      requestAnimationFrame(tick);
    });
  }, { threshold: 0.6 });
  document.querySelectorAll("[data-count]").forEach((b) => {
    if (!b.firstChild || b.firstChild.nodeType !== 3) b.prepend(document.createTextNode("0"));
    cio.observe(b);
  });

  /* ---------- 6. Filtres projets ---------- */
  const fbtns = document.querySelectorAll(".fbtn");
  const cards = document.querySelectorAll(".card[data-cat]");
  if (fbtns.length) {
    fbtns.forEach((btn) => btn.addEventListener("click", () => {
      fbtns.forEach((b) => b.setAttribute("aria-pressed", "false"));
      btn.setAttribute("aria-pressed", "true");
      const f = btn.dataset.filter;
      cards.forEach((c) => {
        const show = f === "all" || (c.dataset.cat || "").split(" ").includes(f);
        c.classList.toggle("hide", !show);
        if (show && !reduced) { c.style.animation = "none"; void c.offsetWidth; c.style.animation = "cardIn .5s var(--ease)"; }
      });
    }));
    const st = document.createElement("style");
    st.textContent = "@keyframes cardIn{from{opacity:0;transform:translateY(24px)}to{opacity:1;transform:none}}";
    document.head.appendChild(st);
  }

  /* ---------- 7. Menu mobile ---------- */
  const burger = document.querySelector(".burger"), menu = document.querySelector(".menu");
  if (burger && menu) {
    burger.addEventListener("click", () => {
      const open = menu.classList.toggle("open");
      burger.setAttribute("aria-expanded", String(open));
      document.body.classList.toggle("menu-open", open);
    });
    menu.querySelectorAll("a").forEach((a) => a.addEventListener("click", () => {
      menu.classList.remove("open");
      document.body.classList.remove("menu-open");
    }));
  }

  /* ---------- 8. Voile de transition entre pages ---------- */
  const veil = document.querySelector(".veil");
  if (veil && !reduced) {
    const vlabel = document.createElement("span");
    vlabel.className = "veil-label"; vlabel.setAttribute("aria-hidden", "true");
    veil.appendChild(vlabel);
    document.querySelectorAll('a[href$=".html"]').forEach((a) => {
      const href = a.getAttribute("href");
      if (!href || href.startsWith("#") || a.target === "_blank" || a.hasAttribute("download")) return;
      a.addEventListener("click", (e) => {
        e.preventDefault();
        vlabel.textContent = (a.dataset.veil || a.textContent || "").trim().replace(/\s+/g, " ").slice(0, 28);
        veil.classList.remove("go"); void veil.offsetWidth; veil.classList.add("go");
        setTimeout(() => { location.href = href; }, 420);
      });
    });
  }

  /* ---------- 9. Bilingue FR / EN ---------- */
  window.PF_COMMON_EN = Object.assign({
    "skip": "Skip to content", "intro.skip": "Skip intro",
    "nav.home": "Home", "nav.projects": "Projects", "nav.journey": "Journey",
    "nav.about": "About", "nav.contact": "Contact", "nav.cv": "Résumé",
    "foot.role": "Computer science student", "foot.certs": "Certificates", "foot.top": "Top ↑",
    "status.live": "Live", "status.wip": "In progress",
    "f.all": "All", "f.front": "Front end", "f.laravel": "Laravel · PHP", "f.live": "Live", "f.wip": "In progress",
    "f.name": "Name", "f.subject": "Subject", "f.send": "Send message",
    "k.time": "Time in Abidjan", "back.projects": "← All projects"
  }, window.PF_COMMON_EN || {});
  const DICT = Object.assign({}, window.PF_COMMON_EN, window.PF_PAGE_EN || {});
  const applyLang = (lang) => {
    document.documentElement.lang = lang;
    document.querySelectorAll("[data-i18n]").forEach((el) => {
      const k = el.dataset.i18n;
      if (el.dataset.fr === undefined) el.dataset.fr = el.innerHTML;
      el.innerHTML = (lang === "en" && DICT[k] !== undefined) ? DICT[k] : el.dataset.fr;
    });
    document.querySelectorAll("[data-alt-en]").forEach((el) => {
      if (lang === "en") { el.dataset.altFr = el.dataset.altFr || el.alt; el.alt = el.dataset.altEn; }
      else if (el.dataset.altFr) el.alt = el.dataset.altFr;
    });
    document.querySelectorAll("[data-i18n-aria]").forEach((el) => {
      const k = el.getAttribute("data-i18n-aria");
      if (el.dataset.ariaFr === undefined) el.dataset.ariaFr = el.getAttribute("aria-label") || "";
      const v = (lang === "en" && DICT[k] !== undefined) ? DICT[k] : el.dataset.ariaFr;
      if (v) el.setAttribute("aria-label", v);
    });
    if (lang === "en" && window.PF_TITLE_EN) document.title = window.PF_TITLE_EN;
    else if (window.PF_TITLE_FR) document.title = window.PF_TITLE_FR;
    document.querySelectorAll(".lang button").forEach((b) =>
      b.setAttribute("aria-pressed", String(b.dataset.lang === lang)));
    try { localStorage.setItem("p03-pf-lang", lang); } catch (e) {}
  };
  let lang = "fr";
  try { lang = localStorage.getItem("p03-pf-lang") || "fr"; } catch (e) {}
  if (Object.keys(DICT).length) applyLang(lang);
  document.querySelectorAll(".lang button").forEach((b) =>
    b.addEventListener("click", () => applyLang(b.dataset.lang)));

  /* ---------- 10. Formulaire de contact (Formspree) ---------- */
  const form = document.querySelector("#contact-form");
  if (form) {
    const msg = form.querySelector(".form-msg");
    form.addEventListener("submit", async (e) => {
      e.preventDefault();
      if (msg) { msg.textContent = "…"; msg.className = "form-msg"; }
      const btn = form.querySelector('[type="submit"]');
      if (btn) btn.disabled = true;
      try {
        const res = await fetch(form.action, { method: "POST", body: new FormData(form), headers: { Accept: "application/json" } });
        if (!res.ok) throw new Error("send failed");
        if (msg) { msg.textContent = msg.dataset.ok || "Message envoyé. Je vous réponds vite."; msg.classList.add("ok"); }
        form.reset();
      } catch (err) {
        if (msg) { msg.textContent = msg.dataset.ko || "Échec de l'envoi. Écrivez-moi directement par email."; msg.classList.add("err"); }
      } finally { if (btn) btn.disabled = false; }
    });
  }

  /* ---------- 11. Horloge d'Abidjan ---------- */
  const clock = document.querySelector("#clock");
  if (clock) {
    const fmt = new Intl.DateTimeFormat("fr-FR", { hour: "2-digit", minute: "2-digit", timeZone: "Africa/Abidjan" });
    const tick = () => { clock.textContent = fmt.format(new Date()); };
    tick(); setInterval(tick, 30000);
  }

  /* ---------- 12. Année + retour en haut ---------- */
  document.querySelectorAll("#year").forEach((el) => { el.textContent = new Date().getFullYear(); });
  document.querySelectorAll(".to-top").forEach((b) =>
    b.addEventListener("click", () => scrollTo({ top: 0, behavior: reduced ? "auto" : "smooth" })));

  /* ---------- 13. Progression de la timeline ---------- */
  const tl = document.querySelector(".timeline");
  if (tl) {
    const fill = tl.querySelector(".fill");
    let ticking = false;
    const update = () => {
      ticking = false;
      const r = tl.getBoundingClientRect(), vp = innerHeight * 0.7;
      const p = Math.max(0, Math.min(1, (vp - r.top) / r.height));
      if (fill) fill.style.height = (p * 100).toFixed(1) + "%";
    };
    addEventListener("scroll", () => { if (!ticking) { ticking = true; requestAnimationFrame(update); } }, { passive: true });
    update();
  }
})();

/* ============================================================
   MOTION V2 — couche stratosphérique
   ============================================================ */
(() => {
  "use strict";
  const reduced = matchMedia("(prefers-reduced-motion: reduce)").matches;
  const finePointer = matchMedia("(hover: hover) and (pointer: fine)").matches;

  /* ---------- A. Barre de progression du scroll ---------- */
  const prog = document.createElement("div");
  prog.className = "scroll-progress"; prog.setAttribute("aria-hidden", "true");
  document.body.appendChild(prog);
  let pTick = false;
  const updateProg = () => {
    pTick = false;
    const h = document.documentElement;
    const max = h.scrollHeight - h.clientHeight;
    prog.style.transform = `scaleX(${max > 0 ? Math.min(1, h.scrollTop / max) : 0})`;
  };
  addEventListener("scroll", () => { if (!pTick) { pTick = true; requestAnimationFrame(updateProg); } }, { passive: true });
  updateProg();

  /* ---------- B. Préloader : compteur 0 → 100 ---------- */
  const intro = document.querySelector(".intro");
  const count = document.querySelector(".intro-count");
  if (intro && count && !reduced) {
    const t0 = performance.now(), dur = 2100;
    const step = (t) => {
      if (!document.body.contains(intro)) return;
      const p = Math.min(1, (t - t0) / dur);
      const eased = 1 - Math.pow(1 - p, 3);
      count.innerHTML = Math.round(eased * 100) + "<small>%</small>";
      if (p < 1 && !intro.classList.contains("done")) requestAnimationFrame(step);
      else count.innerHTML = '100<small>%</small>';
    };
    requestAnimationFrame(step);
  }

  /* ---------- C. Anneau du curseur (traînée) ---------- */
  const cursor = document.querySelector(".cursor");
  if (cursor && finePointer && !reduced) {
    const ring = document.createElement("div");
    ring.className = "cursor-ring"; ring.setAttribute("aria-hidden", "true");
    document.body.appendChild(ring);
    let rx = -100, ry = -100, tx = -100, ty = -100;
    addEventListener("pointermove", (e) => { tx = e.clientX; ty = e.clientY; }, { passive: true });
    (function loop() {
      rx += (tx - rx) * 0.14; ry += (ty - ry) * 0.14;
      ring.style.transform = `translate(${rx}px,${ry}px) translate(-50%,-50%)`;
      requestAnimationFrame(loop);
    })();
    addEventListener("pointermove", (e) => {
      const t = e.target instanceof Element ? e.target : null;
      ring.classList.toggle("grow", !!t?.closest("a,button,[data-cursor]"));
    }, { passive: true });
  }

  /* ---------- D. Split-text (chars) ---------- */
  function splitText(el) {
    if (el.dataset.splitDone === "1" && el.textContent === el.dataset.splitSrc) { el.classList.add("in"); return; }
    const src = el.textContent;
    el.dataset.splitSrc = src; el.dataset.splitDone = "1";
    el.setAttribute("aria-label", src);
    el.innerHTML = "";
    src.split(/(\s+)/).forEach((part) => {
      if (!part) return;
      if (/^\s+$/.test(part)) { el.appendChild(document.createTextNode(" ")); return; }
      const w = document.createElement("span"); w.className = "w"; w.setAttribute("aria-hidden", "true");
      [...part].forEach((ch, i) => {
        const c = document.createElement("span"); c.className = "ch"; c.textContent = ch;
        c.style.transitionDelay = (Math.random() * 0.06 + i * 0.018).toFixed(3) + "s";
        w.appendChild(c);
      });
      el.appendChild(w);
    });
    requestAnimationFrame(() => requestAnimationFrame(() => el.classList.add("in")));
  }
  window.__resplit = (el) => { el.dataset.splitDone = "0"; el.classList.remove("in"); splitText(el); };
  const splitTargets = () => document.querySelectorAll(".sec-head h2, .page-hero h1, .case-head h1");
  function splitAll() {
    if (reduced) return;
    splitTargets().forEach((el) => { el.setAttribute("data-split", ""); splitText(el); });
  }
  splitAll();
  // Re-split après changement de langue (le dictionnaire remplace le HTML)
  document.querySelectorAll(".lang button").forEach((b) =>
    b.addEventListener("click", () => setTimeout(() => {
      splitTargets().forEach((el) => window.__resplit(el));
    }, 80)));

  /* ---------- E. Tilt 3D des cartes ---------- */
  if (finePointer && !reduced) {
    document.querySelectorAll(".card").forEach((card) => {
      let raf = 0;
      card.addEventListener("pointermove", (e) => {
        const r = card.getBoundingClientRect();
        const px = (e.clientX - r.left) / r.width, py = (e.clientY - r.top) / r.height;
        card.style.setProperty("--mx", (px * 100).toFixed(1) + "%");
        card.style.setProperty("--my", (py * 100).toFixed(1) + "%");
        if (raf) return;
        raf = requestAnimationFrame(() => {
          raf = 0;
          card.style.transform =
            `perspective(900px) rotateX(${((0.5 - py) * 7).toFixed(2)}deg) rotateY(${((px - 0.5) * 9).toFixed(2)}deg) translateY(-8px)`;
        });
      });
      card.addEventListener("pointerleave", () => { cancelAnimationFrame(raf); raf = 0; card.style.transform = ""; });
    });
  }

  /* ---------- F. Marquee réactif à la vélocité ---------- */
  const tracks = [...document.querySelectorAll(".marquee-track")];
  const mq = tracks.map((t) => ({
    el: t,
    base: parseFloat(getComputedStyle(t).animationDuration) || 26,
    cur: parseFloat(getComputedStyle(t).animationDuration) || 26,
  }));
  if (mq.length && !reduced) {
    let lastY = scrollY, mTick = false;
    const updateMq = () => {
      mTick = false;
      const v = Math.abs(scrollY - lastY); lastY = scrollY;
      mq.forEach((m) => {
        const target = m.base / (1 + Math.min(v / 55, 2.6));
        m.cur += (target - m.cur) * 0.12;
        m.el.style.animationDuration = m.cur.toFixed(2) + "s";
      });
      if (Math.abs(scrollY - lastY) > 0.5 || mq.some((m) => Math.abs(m.cur - m.base / (1 + Math.min(Math.abs(scrollY - lastY) / 55, 2.6))) > 0.05)) {
        // continue easing back to base speed
      }
    };
    addEventListener("scroll", () => { if (!mTick) { mTick = true; requestAnimationFrame(updateMq); } }, { passive: true });
    // Retour progressif à la vitesse de base quand le scroll s'arrête
    setInterval(() => {
      mq.forEach((m) => {
        m.cur += (m.base - m.cur) * 0.06;
        m.el.style.animationDuration = m.cur.toFixed(2) + "s";
      });
    }, 120);
  }

  /* ---------- G. Parallaxe du hero ---------- */
  const hero = document.querySelector(".hero");
  const portrait = document.querySelector(".portrait");
  const blobs = document.querySelector(".hero-blobs");
  if (hero && finePointer && !reduced) {
    let hraf = 0;
    hero.addEventListener("pointermove", (e) => {
      if (hraf) return;
      hraf = requestAnimationFrame(() => {
        hraf = 0;
        const r = hero.getBoundingClientRect();
        const dx = (e.clientX - r.left) / r.width - 0.5;
        const dy = (e.clientY - r.top) / r.height - 0.5;
        if (portrait) portrait.style.transform = `translate(${dx * 16}px,${dy * 14}px)`;
        if (blobs) blobs.style.transform = `translate(${dx * -34}px,${dy * -26}px)`;
      });
    });
    hero.addEventListener("pointerleave", () => {
      if (portrait) portrait.style.transform = "";
      if (blobs) blobs.style.transform = "";
    });
  }

  /* ---------- H. Header auto-hide ---------- */
  const header = document.querySelector(".site-header");
  if (header && !reduced) {
    let lastY2 = scrollY, hTick = false;
    addEventListener("scroll", () => {
      if (hTick) return; hTick = true;
      requestAnimationFrame(() => {
        hTick = false;
        const y = scrollY;
        header.classList.toggle("hide", y > 140 && y > lastY2);
        lastY2 = y;
      });
    }, { passive: true });
  }
})();

/* ============================================================
   MOTION V3 — dynamique de partout
   ============================================================ */
(() => {
  "use strict";
  const reduced = matchMedia("(prefers-reduced-motion: reduce)").matches;
  const finePointer = matchMedia("(hover: hover) and (pointer: fine)").matches;

  /* ---------- 1. Canvas particules du hero ---------- */
  const hero = document.querySelector(".hero");
  if (hero && !reduced) {
    const cv = document.createElement("canvas");
    cv.className = "hero-canvas"; cv.setAttribute("aria-hidden", "true");
    hero.prepend(cv);
    const ctx = cv.getContext("2d");
    let W = 0, H = 0, pts = [], mx = -9999, my = -9999, running = true;
    const resize = () => {
      const r = hero.getBoundingClientRect();
      W = cv.width = r.width; H = cv.height = r.height;
      const n = Math.min(80, Math.floor(W * H / 22000));
      pts = Array.from({ length: n }, () => ({
        x: Math.random() * W, y: Math.random() * H,
        vx: (Math.random() - 0.5) * 0.35, vy: (Math.random() - 0.5) * 0.35,
        r: 1.2 + Math.random() * 2.2,
      }));
    };
    resize(); addEventListener("resize", resize);
    hero.addEventListener("pointermove", (e) => {
      const r = cv.getBoundingClientRect(); mx = e.clientX - r.left; my = e.clientY - r.top;
    }, { passive: true });
    hero.addEventListener("pointerleave", () => { mx = my = -9999; });
    new IntersectionObserver((en) => { running = en[0].isIntersecting; }).observe(hero);
    (function draw() {
      requestAnimationFrame(draw);
      if (!running || document.hidden) return;
      ctx.clearRect(0, 0, W, H);
      for (const p of pts) {
        const dx = p.x - mx, dy = p.y - my, d = Math.hypot(dx, dy);
        if (d < 130 && d > 1) { p.x += (dx / d) * 0.9; p.y += (dy / d) * 0.9; }
        p.x += p.vx; p.y += p.vy;
        if (p.x < 0 || p.x > W) p.vx *= -1;
        if (p.y < 0 || p.y > H) p.vy *= -1;
        ctx.beginPath(); ctx.arc(p.x, p.y, p.r, 0, 7);
        ctx.fillStyle = "rgba(42,127,163,.5)"; ctx.fill();
      }
      ctx.lineWidth = 1;
      for (let i = 0; i < pts.length; i++) for (let j = i + 1; j < pts.length; j++) {
        const a = pts[i], b = pts[j], d = Math.hypot(a.x - b.x, a.y - b.y);
        if (d < 120) {
          ctx.strokeStyle = `rgba(121,201,234,${(0.35 * (1 - d / 120)).toFixed(3)})`;
          ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke();
        }
      }
    })();
  }

  /* ---------- 2. Mot rotatif du H1 ---------- */
  const rotator = document.querySelector(".rotator");
  if (rotator && !reduced) {
    let words = [], idx = 0, timer = 0;
    const readWords = () => {
      const lang = document.documentElement.lang === "en" ? "en" : "fr";
      words = (rotator.getAttribute("data-words-" + lang) || "").split("|").filter(Boolean);
      idx = 0;
    };
    const show = (i) => {
      rotator.classList.remove("out");
      rotator.innerHTML = `<span>${words[i % words.length]}</span>`;
    };
    const cycle = () => {
      if (!words.length) return;
      rotator.classList.add("out");
      setTimeout(() => { idx = (idx + 1) % words.length; show(idx); }, 400);
    };
    const start = () => { clearInterval(timer); if (words.length > 1) timer = setInterval(cycle, 2800); };
    readWords(); show(0); start();
    document.querySelectorAll(".lang button").forEach((b) =>
      b.addEventListener("click", () => setTimeout(() => { readWords(); show(0); start(); }, 120)));
    document.addEventListener("visibilitychange", () => {
      if (document.hidden) clearInterval(timer); else start();
    });
  }

  /* ---------- 3. Scramble des kickers ---------- */
  const GLYPHS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ#*+<>·—";
  function scramble(el) {
    const final = el.textContent;
    let frame = 0; const total = 26;
    const iv = setInterval(() => {
      frame++;
      el.textContent = [...final].map((ch, i) => {
        if (/[\s/·—-]/.test(ch)) return ch;
        return frame > (i / final.length) * total ? ch : GLYPHS[(Math.random() * GLYPHS.length) | 0];
      }).join("");
      if (frame >= total) { clearInterval(iv); el.textContent = final; }
    }, 36);
  }
  if (!reduced) {
    const sio = new IntersectionObserver((ens) => {
      ens.forEach((en) => { if (en.isIntersecting) { scramble(en.target); sio.unobserve(en.target); } });
    }, { threshold: 0.6 });
    document.querySelectorAll(".kicker").forEach((k) => sio.observe(k));
  }

  /* ---------- 4. Clip-reveal auto des images ---------- */
  const rio = new IntersectionObserver((ens) => {
    ens.forEach((en) => { if (en.isIntersecting) { en.target.classList.add("in"); rio.unobserve(en.target); } });
  }, { threshold: 0.25 });
  document.querySelectorAll(".card figure, .case-cover, .shots figure, .portrait .ph").forEach((f) => {
    f.classList.add("reveal-img"); rio.observe(f);
  });

  /* ---------- 5. Watermarks géants ---------- */
  const wms = [];
  document.querySelectorAll("[data-watermark]").forEach((sec) => {
    const w = document.createElement("span");
    w.className = "watermark"; w.textContent = sec.dataset.watermark;
    w.setAttribute("aria-hidden", "true");
    sec.prepend(w); wms.push({ sec, w });
  });

  /* ---------- 6. Parallaxe images des cartes ---------- */
  const pImgs = [...document.querySelectorAll(".card figure img")];

  /* ---------- 7. Boucle scroll unique (watermarks + parallaxe) ---------- */
  let sTick = false;
  function onScroll() {
    sTick = false;
    const vh = innerHeight;
    for (const { sec, w } of wms) {
      const r = sec.getBoundingClientRect();
      if (r.bottom < 0 || r.top > vh) continue;
      const p = Math.max(0, Math.min(1, (vh * 0.85 - r.top) / (r.height + vh * 0.35)));
      w.style.transform = `translateX(${((0.5 - p) * 320).toFixed(1)}px)`;
    }
    if (!reduced) for (const img of pImgs) {
      const card = img.closest(".card"); if (!card) continue;
      const r = card.getBoundingClientRect();
      if (r.bottom < 0 || r.top > vh) continue;
      const p = (r.top + r.height / 2 - vh / 2) / vh;
      img.style.translate = `0 ${(p * 44).toFixed(1)}px`;
    }
  }
  addEventListener("scroll", () => { if (!sTick) { sTick = true; requestAnimationFrame(onScroll); } }, { passive: true });
  onScroll();
})();

/* ============================================================
   SÉLECTEUR PROJET + HEADER PILULE
   ============================================================ */
(() => {
  "use strict";
  const reduced = matchMedia("(prefers-reduced-motion: reduce)").matches;

  /* Header : devient une pilule flottante après le hero */
  const header = document.querySelector(".site-header");
  if (header) {
    let fTick = false;
    addEventListener("scroll", () => {
      if (fTick) return; fTick = true;
      requestAnimationFrame(() => {
        fTick = false;
        header.classList.toggle("floating", scrollY > 420);
      });
    }, { passive: true });
  }

  /* Sélecteur "Et votre projet ?" */
  const cards = [...document.querySelectorAll(".pj-card")];
  const pills = [...document.querySelectorAll(".pj-pill")];
  const go = document.querySelector("#pj-go");
  const wa = document.querySelector("#pj-wa");
  if (!cards.length) return;
  const langKey = () => (document.documentElement.lang === "en" ? "labelEn" : "labelFr");

  function pick(list, btn) {
    list.forEach((b) => { b.classList.remove("selected"); b.setAttribute("aria-pressed", "false"); });
    btn.classList.add("selected");
    btn.setAttribute("aria-pressed", "true");
    syncWa();
    /* Étape 2 : se déplie quand un type est choisi */
    const step2 = document.querySelector("#pj-step2");
    if (step2 && !step2.classList.contains("open")) {
      step2.classList.add("open");
      step2.setAttribute("aria-hidden", "false");
      setTimeout(() => step2.scrollIntoView({ behavior: reduced ? "auto" : "smooth", block: "nearest" }), 120);
    }
  }
  cards.forEach((b) => b.addEventListener("click", () => pick(cards, b)));
  pills.forEach((b) => b.addEventListener("click", () => pick(pills, b)));

  function selectionText() {
    const k = langKey(), en = document.documentElement.lang === "en";
    const t = document.querySelector(".pj-card.selected");
    const d = document.querySelector(".pj-pill.selected");
    const parts = [];
    if (t) parts.push(t.dataset[k]);
    if (d) parts.push((en ? "timeline: " : "délai : ") + d.dataset[k]);
    return parts.join(" — ");
  }
  function syncWa() {
    if (!wa) return;
    const txt = selectionText();
    const base = "https://wa.me/2250161506296";
    wa.href = txt
      ? base + "?text=" + encodeURIComponent((document.documentElement.lang === "en" ? "Hello, I have a project: " : "Bonjour, j'ai un projet : ") + txt)
      : base;
  }
  if (go) go.addEventListener("click", () => {
    const t = document.querySelector(".pj-card.selected");
    const grid = document.querySelector(".pj-grid");
    if (!t) {
      if (grid && !reduced) { grid.classList.remove("nudge"); void grid.offsetWidth; grid.classList.add("nudge"); }
      return;
    }
    const en = document.documentElement.lang === "en";
    const input = document.querySelector('#contact-form input[name="subject"]');
    if (input) input.value = (en ? "Project: " : "Projet : ") + selectionText();
    const contact = document.querySelector("#contact");
    if (contact) contact.scrollIntoView({ behavior: reduced ? "auto" : "smooth" });
    setTimeout(() => document.querySelector('#contact-form textarea')?.focus({ preventScroll: true }), 900);
  });
  document.querySelectorAll(".lang button").forEach((b) =>
    b.addEventListener("click", () => setTimeout(syncWa, 120)));
  syncWa();
})();

/* ============================================================
   VITRINE PROJETS (accueil) : un projet par vue, tourne-page
   ============================================================ */
(() => {
  "use strict";
  const sc = document.querySelector("#proj-showcase");
  if (!sc) return;
  const reduced = matchMedia("(prefers-reduced-motion: reduce)").matches;
  const track = sc.querySelector(".sc-track");
  const slides = [...track.children];
  const dots = [...sc.querySelectorAll(".sc-dot")];
  const prev = sc.querySelector("#sc-prev");
  const next = sc.querySelector("#sc-next");
  const count = sc.querySelector("#sc-i");
  const n = slides.length;
  let i = 0, timer = null;

  function go(k, dir) {
    const ni = (k + n) % n;
    dir = dir || (ni > i || (i === n - 1 && ni === 0) ? 1 : -1);
    i = ni;
    track.style.transform = "translateX(-" + i * 100 + "%)";
    dots.forEach((d, j) => {
      d.classList.toggle("active", j === i);
      d.setAttribute("aria-selected", j === i ? "true" : "false");
    });
    if (count) count.textContent = String(i + 1).padStart(2, "0");
    slides.forEach((s, j) => {
      const on = j === i;
      s.classList.toggle("active", on);
      s.setAttribute("aria-hidden", on ? "false" : "true");
      if ("inert" in s) s.inert = !on;
      const link = s.querySelector(".sc-link");
      if (link) link.tabIndex = on ? 0 : -1;
    });
  }
  function stop() { if (timer) { clearInterval(timer); timer = null; } }
  function auto() { stop(); if (!reduced) timer = setInterval(() => go(i + 1, 1), 7000); }

  prev.addEventListener("click", () => { go(i - 1, -1); auto(); });
  next.addEventListener("click", () => { go(i + 1, 1); auto(); });
  dots.forEach((d, j) => d.addEventListener("click", () => { go(j); auto(); }));
  sc.addEventListener("pointerenter", stop);
  sc.addEventListener("pointerleave", auto);
  sc.addEventListener("focusin", stop);
  sc.addEventListener("focusout", auto);
  sc.addEventListener("keydown", (e) => {
    if (e.key === "ArrowLeft") { go(i - 1, -1); auto(); }
    if (e.key === "ArrowRight") { go(i + 1, 1); auto(); }
  });
  let tx = null;
  sc.addEventListener("touchstart", (e) => { tx = e.touches[0].clientX; }, { passive: true });
  sc.addEventListener("touchend", (e) => {
    if (tx === null) return;
    const dx = e.changedTouches[0].clientX - tx;
    if (Math.abs(dx) > 40) go(i + (dx < 0 ? 1 : -1));
    tx = null; auto();
  }, { passive: true });

  go(0, 1); auto();
})();

/* ============================================================
   VAGUE TITRES : les lettres bougent au passage du curseur
   ============================================================ */
(() => {
  "use strict";
  const reduced = matchMedia("(prefers-reduced-motion: reduce)").matches;
  if (reduced || matchMedia("(hover: none)").matches) return;
  document.querySelectorAll("[data-split]").forEach((el) => {
    el.addEventListener("pointerenter", (e) => {
      if (e.pointerType === "touch" || el._waving) return;
      el._waving = true;
      const chars = el.querySelectorAll(".ch");
      chars.forEach((c, i) => {
        c.style.animation = "none";
        void c.offsetWidth;
        c.style.animation = "ch-wave .55s " + (i * 0.022).toFixed(3) + "s ease";
      });
      setTimeout(() => {
        chars.forEach((c) => { c.style.animation = ""; });
        el._waving = false;
      }, 600 + chars.length * 22);
    });
  });
})();

/* ============================================================
   SKEW CINÉTIQUE : la page se plie légèrement au scroll (effet caméra)
   ============================================================ */
(() => {
  "use strict";
  const reduced = matchMedia("(prefers-reduced-motion: reduce)").matches;
  const main = document.querySelector("main");
  if (!main || reduced) return;
  let lastY = scrollY, skew = 0, raf = 0;
  function frame() {
    const y = scrollY, v = y - lastY;
    lastY = y;
    const target = Math.max(-6, Math.min(6, v * 0.1));
    skew += (target - skew) * 0.14;
    if (Math.abs(skew) < 0.04 && Math.abs(target) < 0.04) {
      skew = 0; main.style.transform = ""; raf = 0; return;
    }
    main.style.transform = "skewY(" + skew.toFixed(2) + "deg)";
    raf = requestAnimationFrame(frame);
  }
  addEventListener("scroll", () => {
    if (!raf) raf = requestAnimationFrame(frame);
  }, { passive: true });
})();

/* ============================================================
   MANIFESTE : les mots s'illuminent au fil du scroll
   ============================================================ */
(() => {
  "use strict";
  const reduced = matchMedia("(prefers-reduced-motion: reduce)").matches;
  const el = document.querySelector("[data-manifesto]");
  if (!el) return;
  function split() {
    const src = el.textContent.replace(/\s+/g, " ").trim();
    el.setAttribute("aria-label", src);
    el.innerHTML = "";
    src.split(" ").forEach((w) => {
      if (!w) return;
      const s = document.createElement("span");
      s.className = "w"; s.textContent = w; s.setAttribute("aria-hidden", "true");
      el.appendChild(s);
      el.appendChild(document.createTextNode(" "));
    });
    if (reduced) el.querySelectorAll(".w").forEach((w) => w.classList.add("lit"));
  }
  split();
  document.querySelectorAll(".lang button").forEach((b) =>
    b.addEventListener("click", () => setTimeout(split, 160)));
  if (reduced) return;
  let tick = false;
  function onScroll() {
    tick = false;
    const r = el.getBoundingClientRect();
    const total = r.height + innerHeight;
    const progress = Math.min(1, Math.max(0, (innerHeight - r.top) / total));
    const ws = el.querySelectorAll(".w"), n = ws.length;
    for (let i = 0; i < n; i++) ws[i].classList.toggle("lit", progress * (n + 3) - 1.5 > i);
  }
  addEventListener("scroll", () => {
    if (!tick) { tick = true; requestAnimationFrame(onScroll); }
  }, { passive: true });
  onScroll();
})();
