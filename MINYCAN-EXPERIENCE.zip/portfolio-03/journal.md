# Journal du projet

## 2026-10-30
- Agent : Copilot
- Fait : vérifié la structure du portfolio et constaté que le dossier n'est pas encore un dépôt Git. Aucun fichier de configuration contenant des secrets n'a été détecté. Préparation de GitHub Pages et ajout des exclusions Git de base.
- À faire : initialiser Git, créer un dépôt GitHub, confirmer sa visibilité et décider si le CV PDF doit être publié, puis envoyer le projet et activer GitHub Pages.
