# Portfolio N'Goran Junior — Motion Edition

Portfolio statique (HTML, CSS et JavaScript vanilla, sans framework) d'un étudiant en
Informatique Développeur d'Applications à Abidjan. Direction éditoriale claire +
motion 2D maîtrisé : rideau d'intro, curseur contextuel, marquees, révélations au
scroll, compteurs animés, boutons magnétiques, voile de transition entre les pages.

## Structure

- `index.html` : accueil (hero, marquee technos, projets + filtres, marquee géant,
  matrice de compétences, parcours, à propos, contact)
- `pages/projets.html` : les 6 projets + filtres
- `pages/parcours.html` : timeline complète + « Ce que j'explore »
- `pages/a-propos.html` : portrait, bio, faits, démarche
- `pages/contact.html` : email, WhatsApp, GitHub, LinkedIn, formulaire, horloge d'Abidjan
- `pages/certificats.html` : certifications
- `projets/` : une étude de cas par projet
  (`cibanque`, `dona-ci`, `pigier-connect`, `jeuneavenir-ci`, `passerelle`, `bizflow`)
- `404.html` : page d'erreur (servie par GitHub Pages)
- `css/style.css` : tout le design (tokens, composants, responsive, motion réduite)
- `js/main.js` : rideau, curseur, révélations, compteurs, filtres, menu mobile,
  voile de transition, bilingue FR/EN, formulaire, horloge, timeline
- `assets/` : images (WebP), logo, CV (PDF), certificat Excel (PDF)

## Bilingue FR / EN

Chaque texte porte `data-i18n="clé"`. Les traductions anglaises vivent dans le bloc
`window.PF_PAGE_EN` en bas de chaque page (les clés communes — `skip`, `nav.*`,
`foot.*`, `status.*`, `f.*`, `k.time`, `back.projects` — sont déjà dans `main.js`,
ne les redéfinis pas). Les attributs `alt` ont leur version anglaise
(`data-alt-en`). Le choix de langue est mémorisé (localStorage).

## Mettre à jour le contenu

- **Un nouveau projet** : ajoute une `.card` dans `index.html` et
  `pages/projets.html` (même markup, `data-cat` parmi `front`, `laravel`,
  `live`, `wip`), puis crée `projets/nom.html` en copiant `projets/bizflow.html`.
- **CV** : remplace `assets/cv/CV_NGoran_Junior.pdf` en gardant le même nom.
- **Formulaire de contact** : relié à Formspree. Pour changer de destinataire,
  crée un formulaire sur [formspree.io](https://formspree.io) et remplace
  l'identifiant dans l'attribut `action` (`formspree.io/f/...`) de
  `index.html` et `pages/contact.html`.
- **Traductions** : ajoute la clé FR avec `data-i18n` + son équivalent EN dans
  `window.PF_PAGE_EN` de la page.

## Publication (gratuit, GitHub Pages)

1. Crée un dépôt GitHub, mets les fichiers à la racine.
2. Settings → Pages → Deploy from a branch → `main` / `/ (root)`.
3. Le site est en ligne en ~1 minute. La page `404.html` est servie
   automatiquement pour les adresses inconnues.

## Bonnes pratiques

- Ne publie jamais de clé secrète ou de fichier `.env`.
- Les captures des projets sont en WebP (`assets/images/`) pour un chargement rapide.
- Le site respecte `prefers-reduced-motion` : les animations sont désactivées
  pour les utilisateurs qui le demandent.
