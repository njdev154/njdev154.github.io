MINYCAN EXPERIENCE
==================

Lien a envoyer a Minycan :  https://njdev154.github.io/

Les 8 portfolios :
  https://njdev154.github.io/portfolio-01/   Mon portfolio
  https://njdev154.github.io/portfolio-02/   NJ Dev
  https://njdev154.github.io/portfolio-03/   Motion Edition
  https://njdev154.github.io/portfolio-04/   Ligne NJ
  https://njdev154.github.io/portfolio-05/   Papier & cuivre
  https://njdev154.github.io/portfolio-06/   L'affiche risographie
  https://njdev154.github.io/portfolio-07/   Table de montage
  https://njdev154.github.io/portfolio-08/   njdev

Son : reference-audio/fichier-original.mp4 (piste complete, 14,5 s, copiee sans reencodage).
Tout le reste (modifier, tester, redeployer) : voir README.md.
