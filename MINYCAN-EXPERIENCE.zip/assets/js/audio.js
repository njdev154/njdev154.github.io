// Le son « Owwwpapii » : lu une seule fois, après le premier geste, jamais en boucle.
import { CONFIG } from "./data/config.js";
import { $ } from "./utils.js";

let audio = null;
let started = false;

export function prepareAudio() {
  try {
    audio = new Audio();
    audio.preload = "auto";
    audio.loop = false;
    const pick = CONFIG.audio.sources.find((s) => audio.canPlayType(s.type)) || CONFIG.audio.sources[0];
    audio.src = pick.src;
    audio.volume = CONFIG.audio.volume;
    audio.addEventListener("error", () => { audio = null; hideControl(); });
  } catch { audio = null; }
}

// À appeler dans le gestionnaire du clic « Entrer » (geste volontaire).
export function playOnce() {
  if (started || !audio) return Promise.resolve(false);
  started = true;
  const btn = $("#sound");
  return audio.play().then(() => {
    btn.hidden = false;
    btn.addEventListener("click", toggle);
    audio.addEventListener("ended", hideControl, { once: true });
    return true;
  }).catch(() => { hideControl(); return false; }); // l'expérience continue sans son
}

function toggle() {
  if (!audio) return;
  audio.muted = !audio.muted;
  const btn = $("#sound");
  btn.setAttribute("aria-pressed", String(audio.muted));
  $(".sound__label", btn).textContent = audio.muted ? "Remettre le son" : "Couper le son";
}

function hideControl() {
  const btn = $("#sound");
  if (!btn || btn.hidden) return;
  btn.classList.add("is-leaving");
  setTimeout(() => { btn.hidden = true; }, 650);
}

export const isPlaying = () => !!audio && started && !audio.paused && !audio.ended;
