// Mémoire locale (ce téléphone uniquement) : portfolios visités et choix confirmé.
import { CONFIG } from "./data/config.js";

const read = () => {
  try { return JSON.parse(localStorage.getItem(CONFIG.storageKey)) || {}; } catch { return {}; }
};
const write = (data) => {
  try { localStorage.setItem(CONFIG.storageKey, JSON.stringify(data)); } catch { /* navigation privée : on continue sans mémoire */ }
};

export const store = {
  visited() { return read().visited || []; },
  markVisited(id) {
    const d = read(); const v = new Set(d.visited || []); v.add(id); d.visited = [...v]; write(d); return d.visited;
  },
  choice() { return read().choice || null; },
  setChoice(id) { const d = read(); d.choice = id; d.confirmedAt = id ? new Date().toISOString() : null; write(d); },
};
