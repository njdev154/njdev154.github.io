// Petits outils partagés.
export const $ = (s, c = document) => c.querySelector(s);
export const $$ = (s, c = document) => Array.from(c.querySelectorAll(s));
export const reducedMotion = () => window.matchMedia("(prefers-reduced-motion: reduce)").matches;
export const wait = (ms) => new Promise((r) => setTimeout(r, reducedMotion() ? 0 : ms));

// Crée un élément sans innerHTML (le texte passe par textContent).
export function el(tag, attrs = {}, children = []) {
  const n = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (v === null || v === undefined || v === false) continue;
    if (k === "class") n.className = v;
    else if (k === "text") n.textContent = v;
    else if (k.startsWith("data-") || k.startsWith("aria-") || k === "role") n.setAttribute(k, v);
    else n[k] = v;
  }
  for (const c of [].concat(children)) if (c) n.append(c);
  return n;
}

// Découpe un texte en mots animables ; `highlight` met un petit nom en valeur.
export function splitWords(text, { highlight, className = "w" } = {}) {
  const frag = document.createDocumentFragment();
  let i = 0;
  const pushWords = (str, extra) => {
    str.split(/(\s+)/).forEach((part) => {
      if (!part) return;
      if (/^\s+$/.test(part)) { frag.append(document.createTextNode(" ")); return; }
      const s = el("span", { class: className + (extra ? " " + extra : ""), text: part });
      s.style.setProperty("--i", i++);
      frag.append(s);
    });
  };
  if (highlight && text.includes(highlight)) {
    const [a, ...rest] = text.split(highlight);
    pushWords(a);
    pushWords(highlight, "note__name");
    pushWords(rest.join(highlight));
  } else pushWords(text);
  return frag;
}

// Observe une seule fois l'entrée dans l'écran.
export function onceVisible(nodes, cb, options = { threshold: 0.25 }) {
  if (!("IntersectionObserver" in window)) { nodes.forEach(cb); return; }
  const io = new IntersectionObserver((entries) => {
    entries.forEach((e) => { if (e.isIntersecting) { io.unobserve(e.target); cb(e.target); } });
  }, options);
  nodes.forEach((n) => io.observe(n));
}
