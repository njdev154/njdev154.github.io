// SCÈNE 6 : la conclusion. La phrase s'allume mot après mot, puis la lumière bat doucement.
import { $, el, onceVisible, reducedMotion } from "../utils.js";

export function buildFinale() {
  const line = $("#finale-line");
  const text = line.textContent; // « Je t'aime de tout mon cœur, ma vie. » (exactement)
  line.setAttribute("aria-label", text);
  line.textContent = "";
  // « ma vie. » reste sur la même ligne (espace insécable, visuellement identique)
  const words = text.split(" ");
  const tail = words.splice(-2).join("\u00a0");
  [...words, tail].forEach((w, i, all) => {
    const s = el("span", { class: "w" + (i === all.length - 1 ? " w--vie" : ""), text: w, "aria-hidden": "true" });
    s.style.setProperty("--i", i);
    line.append(s, i < all.length - 1 ? " " : "");
  });

  onceVisible([$("#fin")], (n) => n.classList.add("is-in"), { threshold: 0.45 });

  $("#again").addEventListener("click", () => {
    $("#accueil").scrollIntoView({ behavior: reducedMotion() ? "auto" : "smooth" });
    $("#enter").focus({ preventScroll: true });
  });
}
