// SCÈNE 1 : l'accueil et le passage dans « le petit univers ».
import { $, reducedMotion, wait } from "../utils.js";
import { playOnce } from "../audio.js";

export function initWelcome({ onEnter }) {
  const btn = $("#enter");
  let entered = false;

  btn.addEventListener("click", async () => {
    const target = $("#attentions");
    if (entered) { target.scrollIntoView({ behavior: reducedMotion() ? "auto" : "smooth" }); return; }
    entered = true;

    playOnce(); // ne bloque jamais l'expérience, même si le son échoue

    const after = $("#after-enter");
    const reveal = () => {
      after.inert = false;
      after.removeAttribute("inert");
      document.body.classList.remove("is-locked");
      target.scrollIntoView({ behavior: "auto" });
      onEnter();
    };

    if (reducedMotion()) { reveal(); target.focus?.({ preventScroll: true }); return; }

    const r = btn.querySelector(".enter__arrow").getBoundingClientRect();
    const iris = document.createElement("div");
    iris.className = "iris";
    iris.style.setProperty("--ix", `${r.left + r.width / 2}px`);
    iris.style.setProperty("--iy", `${r.top + r.height / 2}px`);
    document.body.append(iris);
    requestAnimationFrame(() => requestAnimationFrame(() => iris.classList.add("is-open")));
    await wait(950);
    reveal();
    await wait(120);
    iris.classList.add("is-gone");
    await wait(850);
    iris.remove();
  });
}
