// SCÈNE 2 : les petites attentions, comme une conversation qui s'écrit.
import { MESSAGES, EMMANUELLA, OWWWPAPII } from "../data/messages.js";
import { $, el, splitWords, onceVisible, reducedMotion, wait } from "../utils.js";

export function buildNotes() {
  const list = $("#notes");
  MESSAGES.forEach((m) => {
    const text = el("span", { class: "note__text" });
    text.append(splitWords(m.text, { highlight: m.name }));
    const dots = el("span", { class: "note__dots", "aria-hidden": "true" }, [el("i"), el("i"), el("i")]);
    list.append(el("li", { class: "note", "data-side": m.side }, [dots, text]));
  });

  // Owwwpapii : chaque lettre peut danser
  const papii = $("#papii");
  [...OWWWPAPII].forEach((ch, i) => {
    const l = el("span", { class: "l", text: ch === " " ? "\u00a0" : ch, "aria-hidden": "true" });
    l.style.setProperty("--i", i);
    papii.append(l);
  });
  papii.addEventListener("click", () => wobble(papii));
}

function wobble(node) {
  if (reducedMotion()) return;
  node.classList.remove("is-wobbling");
  void node.offsetWidth; // relance l'animation
  node.classList.add("is-wobbling");
}

// Lancée après l'entrée : les messages s'écrivent quand ils arrivent à l'écran.
export function startNotes() {
  const notes = [...document.querySelectorAll(".note")];
  let queue = Promise.resolve();
  onceVisible(notes, (note) => {
    queue = queue.then(async () => {
      note.classList.add("is-typing");
      await wait(650 + Math.min(note.textContent.length * 14, 700));
      note.classList.remove("is-typing");
      note.classList.add("is-said");
      await wait(350);
    });
  }, { threshold: 0.6 });

  const emma = $("#emma");
  fitEmma();
  window.addEventListener("resize", fitEmma, { passive: true });
  onceVisible([emma], () => stretchEmma(emma), { threshold: 0.7 });
  onceVisible([$("#papii")], (n) => setTimeout(() => wobble(n), 300), { threshold: 0.8 });
}

// Calcule la taille pour que la version la plus longue tienne sur une ligne, sans débordement.
function fitEmma() {
  const wrap = $("#emma");
  const full = EMMANUELLA.before + EMMANUELLA.stretch.repeat(EMMANUELLA.count) + EMMANUELLA.after;
  const probe = el("span", { class: "emma__fit", text: full });
  probe.style.cssText = "position:absolute;visibility:hidden;font-size:100px;white-space:nowrap";
  wrap.querySelector(".emma__word").append(probe);
  const w = probe.getBoundingClientRect().width;
  probe.remove();
  const avail = wrap.clientWidth - 24;
  wrap.style.setProperty("--emma-size", `${Math.max(28, Math.floor((avail / w) * 100 * 0.98))}px`);
}

async function stretchEmma(wrap) {
  const word = $("#emma-word");
  const { before, stretch, count, after } = EMMANUELLA;
  word.textContent = "";
  const head = document.createTextNode(before);
  const tail = document.createTextNode(after);
  word.append(head, el("span", { class: "m", text: stretch }), tail);
  for (let i = 1; i < count; i++) {
    await wait(i < 4 ? 160 : 85);
    word.insertBefore(el("span", { class: "m", text: stretch }), tail);
  }
  await wait(250);
  wrap.classList.add("is-done");
}
