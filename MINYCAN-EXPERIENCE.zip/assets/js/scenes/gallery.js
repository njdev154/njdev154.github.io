// SCÈNES 3 et 4 : l'exposition des huit portfolios et leur ouverture.
import { PORTFOLIOS } from "../data/portfolios.js";
import { WHISPERS } from "../data/messages.js";
import { $, $$, el, onceVisible, reducedMotion } from "../utils.js";
import { store } from "../store.js";

const label = (p) => `N° ${Number(p.id)}`;

function picture(p) {
  const alt = `Capture d'écran de l'accueil du portfolio ${label(p)}, ${p.name}`;
  const img = el("img", { alt, loading: "lazy", decoding: "async", width: 1440, height: 900 });
  const pic = el("picture");
  if (p.layout === "phone") {
    img.src = p.captures.mobile; img.width = 600; img.height = 1299;
  } else {
    pic.append(el("source", { media: "(max-width: 899px)", srcset: p.captures.mobile }));
    img.src = p.captures.desktopSmall;
    img.srcset = `${p.captures.desktopSmall} 760w, ${p.captures.desktop} 1440w`;
    img.sizes = p.layout === "full" ? "100vw" : "(min-width: 900px) 70vw, 100vw";
  }
  pic.append(img);
  return { pic, img };
}

export function buildGallery() {
  const list = $("#works");
  const seen = new Set(store.visited());

  PORTFOLIOS.forEach((p) => {
    const { pic, img } = picture(p);
    const frame = el("a", { class: "work__frame" + (p.layout === "phone" ? " is-phone" : ""), href: p.url, target: "_blank", rel: "noopener", tabIndex: -1, "data-id": p.id }, [
      el("span", { class: "skeleton", "aria-hidden": "true" }), pic,
      el("span", { class: "open-cue", "aria-hidden": "true", text: "Ouvrir ↗" }),
    ]);
    const done = () => frame.classList.add("is-loaded");
    if (img.complete && img.naturalWidth) done(); else { img.addEventListener("load", done); img.addEventListener("error", done); }

    const cartel = el("div", { class: "cartel" }, [
      el("span", { class: "cartel__no", text: label(p) }),
      el("h3", { class: "cartel__name", text: p.name }),
      el("p", { class: "cartel__sub", text: p.subtitle }),
      el("p", { class: "cartel__tech", text: p.tech }),
      el("p", { class: "cartel__desc", text: p.description }),
      el("p", { class: "cartel__links" }, [
        el("a", { class: "cartel__open", href: p.url, target: "_blank", rel: "noopener", "data-id": p.id, "aria-label": `Ouvrir le portfolio ${label(p)}, ${p.name} (nouvel onglet)`, text: "Découvrir cet univers ↗" }),
        el("span", { class: "cartel__seen", text: "déjà visité", hidden: !seen.has(p.id), "data-seen": p.id }),
      ]),
    ]);
    list.append(el("li", { class: `work work--${p.layout}`, "data-id": p.id }, [frame, cartel]));

    // Lumière qui suit le doigt / la souris sur la capture
    frame.addEventListener("pointermove", (e) => {
      const r = frame.getBoundingClientRect();
      frame.style.setProperty("--mx", `${e.clientX - r.left}px`);
      frame.style.setProperty("--my", `${e.clientY - r.top}px`);
    });
  });

  onceVisible($$(".work"), (w) => w.classList.add("is-in"), { threshold: 0.18 });
  initTilt();
  initVisits();
}

// L'œuvre N° 3 est accrochée de biais et se redresse quand on arrive devant elle.
function initTilt() {
  const tilt = $(".work--tilt .work__frame");
  if (!tilt || reducedMotion()) return;
  let ticking = false;
  const update = () => {
    ticking = false;
    const r = tilt.getBoundingClientRect();
    const center = r.top + r.height / 2;
    const t = Math.min(1, Math.max(0, (center - innerHeight * 0.5) / (innerHeight * 0.6)));
    tilt.style.setProperty("--tilt", `${(t * 16).toFixed(2)}deg`);
  };
  addEventListener("scroll", () => { if (!ticking) { ticking = true; requestAnimationFrame(update); } }, { passive: true });
  update();
}

// Mémorise les visites et dit un petit mot au retour.
function initVisits() {
  let away = null;
  let n = 0;
  document.addEventListener("click", (e) => {
    const a = e.target.closest("a[data-id]");
    if (!a) return;
    const visited = store.markVisited(a.dataset.id);
    $$(`[data-seen="${a.dataset.id}"]`).forEach((s) => (s.hidden = false));
    document.dispatchEvent(new CustomEvent("visited", { detail: visited }));
    away = a.dataset.id;
  });
  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState !== "visible" || !away) return;
    away = null;
    const left = PORTFOLIOS.length - store.visited().length;
    const tail = left > 0 ? ` Encore ${left} univers à voir.` : " Tu les as tous vus. Le choix t'attend plus bas.";
    whisper(WHISPERS[n++ % WHISPERS.length] + tail);
  });
}

let whisperTimer;
export function whisper(text) {
  const w = $("#whisper");
  w.textContent = text;
  w.classList.add("is-on");
  clearTimeout(whisperTimer);
  whisperTimer = setTimeout(() => w.classList.remove("is-on"), 4200);
}
