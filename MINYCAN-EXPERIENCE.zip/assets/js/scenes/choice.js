// SCÈNE 5 : le choix de Minycan.
// Pas de faux envoi : le choix est gardé sur son téléphone, puis elle l'envoie
// elle-même via un message WhatsApp déjà écrit (elle appuie sur « Envoyer »).
import { PORTFOLIOS } from "../data/portfolios.js";
import { CONFIG } from "../data/config.js";
import { $, $$, el, reducedMotion } from "../utils.js";
import { store } from "../store.js";

const label = (p) => `N° ${Number(p.id)}`;
const find = (id) => PORTFOLIOS.find((p) => p.id === id);

export function buildChoice() {
  const picks = $("#picks");
  PORTFOLIOS.forEach((p) => {
    const input = el("input", { type: "radio", name: "portfolio", value: p.id, id: `pick-${p.id}` });
    picks.append(el("label", { class: "pick", htmlFor: `pick-${p.id}` }, [
      input,
      el("img", { src: p.captures.desktopSmall, alt: "", loading: "lazy", decoding: "async", width: 760, height: 475 }),
      el("span", { class: "pick__no", text: label(p) }),
      el("span", { class: "pick__name", text: p.name }),
      el("span", { class: "pick__mark", "aria-hidden": "true" }),
    ]));
  });

  const form = $("#choice-form");
  const confirm = $("#choice-confirm");
  const current = $("#choice-current");

  form.addEventListener("change", () => {
    const id = form.portfolio.value;
    const p = find(id);
    $$(".pick").forEach((l) => l.classList.toggle("is-checked", l.querySelector("input").checked));
    confirm.disabled = !p;
    current.textContent = "";
    if (p) current.append("Ton choix : ", el("strong", { text: `${label(p)} · ${p.name}` }));
  });

  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const p = find(form.portfolio.value);
    if (!p) return;
    store.setChoice(p.id);
    showSealed(p);
  });

  $("#sealed-change").addEventListener("click", () => {
    store.setChoice(null);
    $("#sealed").hidden = true;
    form.hidden = false;
    (form.querySelector("input:checked") || form.querySelector("input")).focus({ preventScroll: true });
    form.scrollIntoView({ behavior: reducedMotion() ? "auto" : "smooth", block: "center" });
  });

  updateCount(store.visited());
  document.addEventListener("visited", (e) => updateCount(e.detail));

  // Choix déjà confirmé lors d'une visite précédente
  const saved = find(store.choice());
  if (saved) {
    const input = $(`#pick-${saved.id}`);
    input.checked = true;
    form.dispatchEvent(new Event("change"));
    showSealed(saved, { focus: false });
  }
}

function showSealed(p, { focus = true } = {}) {
  const msg = `Coucou Junior ! J'ai fait mon choix : le portfolio ${label(p)}, « ${p.name} ». ${p.url}`;
  $("#sealed-pick").textContent = `${label(p)} · ${p.name}`;
  $("#sealed-send").href = `https://wa.me/${CONFIG.whatsappNumber}?text=${encodeURIComponent(msg)}`;
  $("#choice-form").hidden = true;
  const sealed = $("#sealed");
  sealed.hidden = false;
  if (focus) sealed.focus({ preventScroll: true });
}

function updateCount(visited) {
  const n = visited.length;
  const t = n === 0
    ? "Tu peux choisir ici, mais ouvre-les d'abord : c'est plus juste."
    : n >= PORTFOLIOS.length
      ? "Tu les as tous visités. Maintenant, écoute ton cœur."
      : `Tu en as visité ${n} sur ${PORTFOLIOS.length}.`;
  $("#visited-count").textContent = t;
}
