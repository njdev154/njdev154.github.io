// Les petites attentions de la scène 2, dans l'ordre d'apparition.
// `name` : le petit nom mis en valeur dans la phrase (doit apparaître tel quel dans `text`).
export const MESSAGES = [
  { text: "Coucou ma pkada…", name: "ma pkada", side: "start" },
  { text: "Alors Nini, prête pour une petite surprise ?", name: "Nini", side: "end" },
  { text: "Prends ton temps, mon bébé.", name: "mon bébé", side: "start" },
  { text: "Mi amor, tout ceci est pour toi.", name: "Mi amor", side: "end" },
  { text: "Minycan, j'espère que tu souriras.", name: "Minycan", side: "start" },
];

// La plaisanterie typographique (une seule fois dans tout le site).
export const EMMANUELLA = {
  before: "E",
  stretch: "m",
  count: 10, // nombre de « m » : « Emmmmmmmmmmanuella »
  after: "anuella !",
  aside: "Ton prénom est toujours trop long.",
};

export const OWWWPAPII = "Owwwpapiiiii !";

// Phrases murmurées quand elle revient d'un portfolio.
export const WHISPERS = [
  "Re-bonjour, ma princesse.",
  "Alors, mi amor ?",
  "Prends ton temps, Nini.",
  "Il t'a plu, celui-là ?",
];
