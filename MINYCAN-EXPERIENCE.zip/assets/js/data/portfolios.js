// LA source unique des huit portfolios.
// Pour changer un nom, une description, une capture ou une URL : c'est ici, et nulle part ailleurs.
const BASE = "https://njdev154.github.io";
const cap = (n) => ({
  desktop: `assets/media/captures/portfolio-${n}-desktop-1440.webp`,
  desktopSmall: `assets/media/captures/portfolio-${n}-desktop-760.webp`,
  mobile: `assets/media/captures/portfolio-${n}-mobile-600.webp`,
});

export const PORTFOLIOS = [
  {
    id: "01", name: "Mon portfolio", subtitle: "Le premier pas",
    tech: "HTML · CSS",
    description: "La toute première version : une page unique, écrite à la main en 2e année de BTS IDA, avec ses commentaires d'apprenti.",
    url: `${BASE}/portfolio-01/`, captures: cap("01"), layout: "small",
  },
  {
    id: "02", name: "NJ Dev", subtitle: "Carnet de chantier",
    tech: "HTML · CSS · JavaScript",
    description: "Un plan de construction : grille d'architecte, encre sapin et tampon ambre. Quatre pages, projets et CV.",
    url: `${BASE}/portfolio-02/`, captures: cap("02"), layout: "wide",
  },
  {
    id: "03", name: "Motion Edition", subtitle: "Éditorial en mouvement",
    tech: "HTML · CSS · JavaScript, bilingue",
    description: "Rideau d'intro, curseur contextuel, marquees et voile de transition entre les pages, avec une étude de cas par projet.",
    url: `${BASE}/portfolio-03/`, captures: cap("03"), layout: "tilt",
  },
  {
    id: "04", name: "Ligne NJ", subtitle: "Une ligne de transport depuis Yopougon",
    tech: "HTML · CSS · JavaScript, canvas",
    description: "Chaque projet est un arrêt : tableau des départs à palettes, lumières de la ville, train qui avance au défilement.",
    url: `${BASE}/portfolio-04/`, captures: cap("04"), layout: "full",
  },
  {
    id: "05", name: "Papier & cuivre", subtitle: "Le nom qui respire",
    tech: "HTML · CSS · JavaScript, police variable",
    description: "Papier chaud, encre sombre et cuivre discret : un nom géant qui s'élargit sous le doigt, des cartes qu'on lance comme un boomerang.",
    url: `${BASE}/portfolio-05/`, captures: cap("05"), layout: "phone",
  },
  {
    id: "06", name: "L'affiche risographie", subtitle: "Deux encres, un bleu et un rose",
    tech: "HTML · CSS · JavaScript, physique maison",
    description: "Une affiche imprimée à Yopougon : portrait en trame de points, lettres qu'on attrape, stickers et avion en papier.",
    url: `${BASE}/portfolio-06/`, captures: cap("06"), layout: "large",
  },
  {
    id: "07", name: "Table de montage", subtitle: "Comme un logiciel de motion design",
    tech: "HTML · CSS · JavaScript, sans librairie",
    description: "L'intro est une timeline, la navigation aussi : tête de lecture, images-clés, fenêtres qu'on lance et qui reviennent.",
    url: `${BASE}/portfolio-07/`, captures: cap("07"), layout: "offset",
  },
  {
    id: "08", name: "njdev", subtitle: "Le site qui se construit",
    tech: "HTML · CSS · JavaScript",
    description: "Maquette, code, mise en ligne : chaque bloc arrive en squelette gris avant son rendu, et les fenêtres de projets se lancent.",
    url: `${BASE}/portfolio-08/`, captures: cap("08"), layout: "finale",
  },
];
