// Réglages généraux de l'expérience. Tout ce qui peut changer se modifie ici.
export const CONFIG = {
  // Numéro WhatsApp qui reçoit le choix (format international, sans + ni espaces).
  // Repris des portfolios 03 et 06 (lien WhatsApp de contact de Junior).
  whatsappNumber: "2250161506296",
  // Son : piste audio complète du fichier fourni (14,5 s), copiée sans réencodage.
  // Le premier format lisible par le navigateur est utilisé.
  audio: {
    sources: [
      { src: "assets/media/audio/owwwpapii-calee.m4a", type: 'audio/mp4; codecs="mp4a.40.2"' }, // copie exacte (AAC)
      { src: "assets/media/audio/owwwpapii-calee.ogg", type: 'audio/ogg; codecs="opus"' },      // secours (Opus)
    ],
    volume: 0.9,
  },
  // Clé de mémorisation locale (portfolios visités, choix confirmé).
  storageKey: "minycan-experience-v1",
};
