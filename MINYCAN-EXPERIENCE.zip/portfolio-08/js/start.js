/* Point d'entrée du site : démarre toutes les animations */
import { boot } from "./main.js";
boot();
