/* ==============================================================
   NJDEV · INTERACTIONS
   JavaScript pur, sans dépendance. Un seul point d'entrée : boot().
   Sommaire : outils · intro · en-tête · deck lançable · défilement
   des outils · projets horizontaux · services · configurateur ·
   parcours · outils (matrice) · contact · étude de cas · boucle.
   ============================================================== */
import { CONTACT, TOOLS, PROJECTS, PATH, PROJECT_TYPES, MODULES, DELAYS } from "./data.js";
import { LOGOS, UI } from "./icons.js";

/* ---------- outils ---------- */
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
const lerp = (a, b, t) => a + (b - a) * t;
const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const safeUrl = (u) => (typeof u === "string" && /^(https:\/\/|mailto:|assets\/|#)/.test(u) ? u : "#");
const toolName = (id) => (TOOLS.find((t) => t.id === id) || { name: id }).name;
const titleCase = (s) => s.toLowerCase().replace(/(^|\s)\S/g, (c) => c.toUpperCase()).replace("Ci", "CI");
const pad2 = (n) => String(n).padStart(2, "0");

let ASSET = (p) => p;
let PREVIEW = false;
let REDUCED = false;
let FINE = false;
let SC = null; // conteneur de défilement (window sur le vrai site)
const getY = () => (SC && SC !== window ? SC.scrollTop : window.scrollY);
const goTo = (top) => (SC && SC !== window ? SC : window).scrollTo({ top, behavior: REDUCED ? "auto" : "smooth" });
const lock = (on) => { document.body.classList.toggle("is-locked", on); if (SC && SC !== window) SC.style.overflow = on ? "hidden" : ""; };
const scrollMax = () => (SC && SC !== window ? SC.scrollHeight - SC.clientHeight : document.documentElement.scrollHeight - innerHeight);

function icons(root = document) {
  $$("[data-icon]", root).forEach((el) => { if (!el.firstChild && UI[el.dataset.icon]) el.innerHTML = UI[el.dataset.icon]; });
  $$("[data-logo]", root).forEach((el) => { if (!el.firstChild && LOGOS[el.dataset.logo]) el.innerHTML = LOGOS[el.dataset.logo]; });
}
const mailAddr = () => CONTACT.mailUser + "@" + CONTACT.mailHost;
const waUrl = (text) => "https://wa.me/" + CONTACT.whatsapp + (text ? "?text=" + encodeURIComponent(text) : "");
const projectType = (p) => (/application|plateforme/i.test(p.kind) ? "app" : "vitrine");

/* ==============================================================
   BOOT
   ============================================================== */
export function boot(opts = {}) {
  if (opts.asset) ASSET = opts.asset;
  PREVIEW = !!opts.preview;
  SC = opts.scroller || window;
  REDUCED = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  FINE = window.matchMedia("(hover: hover) and (pointer: fine)").matches;
  if (REDUCED) document.documentElement.classList.add("no-motion");

  // chemins des fichiers (images, CV, certificat)
  $$('img[src^="assets/"]').forEach((img) => (img.src = ASSET(img.getAttribute("src"))));
  $$('a[href^="assets/"]').forEach((a) => (a.href = ASSET(a.getAttribute("href"))));

  icons();
  const cleanups = [];
  const add = (fn) => fn && cleanups.push(fn);

  add(setupContactLinks());
  add(setupSplit());
  add(setupReveal());
  add(setupHeader());
  const deck = setupDeck();
  add(deck.destroy);
  add(setupMarquee());
  add(setupWork());
  add(setupServices());
  add(setupConfig());
  add(setupTimeline());
  add(setupStack());
  add(setupForm());
  add(setupCase());
  add(setupCursor());
  add(setupMagnetic());
  add(setupFooter());
  add(setupAnchors());
  add(setupPortrait());
  add(startLoop());

  runIntro(() => {
    document.body.classList.add("is-ready");
    $(".hl")?.classList.add("is-in");
    startRotator();
    countUp();
    deck.start();
    const m = location.hash.match(/^#projet\/([\w-]+)/);
    if (m) openCase(m[1]);
  });

  return () => cleanups.forEach((fn) => fn());
}

/* ==============================================================
   INTRO : le mot se tape, le curseur grandit et devient le rideau
   ============================================================== */
function runIntro(done) {
  const intro = $("#intro");
  if (!intro) return done();
  let seen = false;
  try { seen = sessionStorage.getItem("p08-njdev-intro") === "1"; } catch (e) {}
  const finish = () => {
    intro.remove();
    lock(false);
    done();
  };
  if (REDUCED || seen) return finish();
  try { sessionStorage.setItem("p08-njdev-intro", "1"); } catch (e) {}

  lock(true);
  const typed = $("#introTyped");
  const caret = $("#introCaret");
  const steps = $$("#introSteps li");
  const bar = $("#introBar");
  const word = [["n", 1], ["j", 1], ["d", 0], ["e", 0], ["v", 0]];
  const timers = [];
  let ended = false;
  const later = (fn, ms) => timers.push(setTimeout(fn, ms));

  word.forEach(([c, blue], i) => later(() => {
    const el = document.createElement(blue ? "b" : "span");
    el.textContent = c;
    typed.appendChild(el);
  }, 180 + i * 110));
  steps.forEach((li, i) => later(() => li.classList.add("on"), 820 + i * 380));
  const t0 = performance.now();
  const barTick = (t) => {
    if (ended) return;
    const p = clamp((t - t0 - 600) / 1500, 0, 1);
    bar.style.transform = `scaleX(${1 - Math.pow(1 - p, 3)})`;
    if (p < 1) requestAnimationFrame(barTick);
  };
  requestAnimationFrame(barTick);

  const end = () => {
    if (ended) return;
    ended = true;
    timers.forEach(clearTimeout);
    const r = caret.getBoundingClientRect();
    const wipe = document.createElement("div");
    wipe.className = "intro__wipe";
    Object.assign(wipe.style, { left: r.left + "px", top: r.top + "px", width: r.width + "px", height: r.height + "px" });
    document.body.appendChild(wipe);
    intro.classList.add("is-expanding");
    const W = innerWidth, H = innerHeight;
    const grow = wipe.animate(
      [
        { left: r.left + "px", top: r.top + "px", width: r.width + "px", height: r.height + "px", borderRadius: "4px" },
        { left: "0px", top: "0px", width: W + "px", height: H + "px", borderRadius: "0px" }
      ],
      { duration: 620, easing: "cubic-bezier(0.7, 0, 0.2, 1)", fill: "forwards" }
    );
    grow.onfinish = () => {
      intro.classList.add("is-gone");
      lock(false);
      done();
      const away = wipe.animate(
        [{ transform: "translateY(0)", borderRadius: "0 0 0 0" }, { transform: "translateY(-102%)", borderRadius: "0 0 50% 50% / 0 0 120px 120px" }],
        { duration: 820, easing: "cubic-bezier(0.7, 0, 0.2, 1)", fill: "forwards" }
      );
      away.onfinish = () => { wipe.remove(); intro.remove(); };
    };
  };
  later(end, 2300);
  $("#introSkip")?.addEventListener("click", end);
}

/* ---------- mot qui change dans le titre ---------- */
let rotTimer = null;
function startRotator() {
  const words = $$("#rotator span");
  const sr = $("#heroTitle .sr");
  if (!words.length) return;
  let i = 0;
  words[0].classList.add("in");
  const width = () => { $("#rotator").style.width = words[i].offsetWidth + "px"; };
  // largeur figée sur le mot visible pour que la ligne ne saute pas
  words.forEach((w) => (w.style.whiteSpace = "nowrap"));
  $("#rotator").style.transition = "width .7s cubic-bezier(0.22,1,0.36,1)";
  width();
  if (REDUCED) return;
  clearInterval(rotTimer);
  rotTimer = setInterval(() => {
    const prev = words[i];
    i = (i + 1) % words.length;
    prev.classList.remove("in");
    prev.classList.add("out");
    words[i].classList.remove("out");
    // repart du bas
    words[i].style.transition = "none";
    words[i].style.transform = "translateY(110%)";
    words[i].offsetWidth;
    words[i].style.transition = "";
    words[i].style.transform = "";
    words[i].classList.add("in");
    if (sr) sr.textContent = words[i].textContent;
    width();
  }, 2600);
}

function countUp() {
  $$("[data-count]").forEach((el, k) => {
    const to = +el.dataset.count;
    if (REDUCED) { el.textContent = to; return; }
    const t0 = performance.now() + 500 + k * 120;
    const tick = (t) => {
      const p = clamp((t - t0) / 900, 0, 1);
      el.textContent = Math.round(to * (1 - Math.pow(1 - p, 3)));
      if (p < 1) requestAnimationFrame(tick);
    };
    requestAnimationFrame(tick);
  });
}

/* ==============================================================
   TITRES : mots qui montent + apparition « rendu »
   ============================================================== */
function setupSplit() {
  $$("[data-split]").forEach((el) => {
    let i = 0;
    const walk = (node) => {
      Array.from(node.childNodes).forEach((n) => {
        if (n.nodeType === 3) {
          const parts = n.textContent.split(/(\s+)/);
          const frag = document.createDocumentFragment();
          parts.forEach((p) => {
            if (!p) return;
            if (/^\s+$/.test(p)) { frag.appendChild(document.createTextNode(" ")); return; }
            const w = document.createElement("span");
            w.className = "w";
            const inner = document.createElement("span");
            inner.style.setProperty("--i", i++);
            inner.textContent = p;
            w.appendChild(inner);
            frag.appendChild(w);
          });
          n.replaceWith(frag);
        } else if (n.nodeType === 1) walk(n);
      });
    };
    el.setAttribute("aria-label", el.textContent.replace(/\s+/g, " ").trim());
    walk(el);
    $$(".w", el).forEach((w) => w.setAttribute("aria-hidden", "true"));
  });
}

function setupReveal() {
  const els = $$("[data-split], [data-render], .svc, .tl");
  if (REDUCED || !("IntersectionObserver" in window)) { els.forEach((e) => e.classList.add("is-in")); return; }
  const io = new IntersectionObserver((entries) => {
    const batch = entries.filter((e) => e.isIntersecting);
    batch.sort((a, b) => a.boundingClientRect.top - b.boundingClientRect.top || a.boundingClientRect.left - b.boundingClientRect.left);
    batch.forEach((e, k) => {
      e.target.style.setProperty("--d", k * 0.09 + "s");
      e.target.classList.add("is-in");
      io.unobserve(e.target);
    });
  }, { rootMargin: "0px 0px -8% 0px", threshold: 0.12 });
  els.forEach((e) => io.observe(e));
  return () => io.disconnect();
}

/* ==============================================================
   EN-TÊTE : se cache en descendant, pastille de section active
   ============================================================== */
let headerState = { last: 0 };
function setupHeader() {
  const burger = $("#burger");
  const sheet = $("#sheet");
  const toggle = (open) => {
    burger.setAttribute("aria-expanded", String(open));
    if (open) {
      sheet.hidden = false;
      requestAnimationFrame(() => sheet.classList.add("is-open"));
      lock(true);
    } else {
      sheet.classList.remove("is-open");
      lock(false);
      setTimeout(() => { if (!sheet.classList.contains("is-open")) sheet.hidden = true; }, 700);
    }
  };
  burger.addEventListener("click", () => toggle(burger.getAttribute("aria-expanded") !== "true"));
  $$("a", sheet).forEach((a) => a.addEventListener("click", () => toggle(false)));
  headerState.close = () => toggle(false);
}

function updateHeader(y) {
  const top = $("#top");
  const dy = y - headerState.last;
  if (Math.abs(dy) > 4) {
    const caseOpen = document.body.classList.contains("case-open");
    top.classList.toggle("is-hidden", dy > 0 && y > 420 && !caseOpen && $("#burger").getAttribute("aria-expanded") !== "true");
    headerState.last = y;
  }
  top.classList.toggle("is-solid", y > 40);

  // section active
  const ids = ["projets", "services", "parcours", "apropos"];
  let active = null;
  const mid = innerHeight * 0.4;
  ids.forEach((id) => {
    const s = document.getElementById(id);
    if (!s) return;
    const r = s.getBoundingClientRect();
    if (r.top <= mid && r.bottom > mid) active = id;
  });
  if (active === "configurateur") active = "services";
  if (headerState.active !== active) {
    headerState.active = active;
    const pill = $("#navPill");
    $$(".nav a").forEach((a) => a.classList.toggle("is-active", a.dataset.nav === active));
    const link = active && $(`.nav a[data-nav="${active}"]`);
    if (link) {
      pill.style.opacity = "1";
      pill.style.width = link.offsetWidth + "px";
      pill.style.transform = `translateX(${link.offsetLeft}px)`;
    } else pill.style.opacity = "0";
  }
}

function setupAnchors() {
  const onClick = (e) => {
    const a = e.target.closest('a[href^="#"]');
    if (!a) return;
    const id = a.getAttribute("href").slice(1);
    if (!id) { e.preventDefault(); return; }
    const t = document.getElementById(id);
    if (!t) return;
    e.preventDefault();
    if (a.dataset.type) configApi.setType?.(a.dataset.type, true);
    const y = id === "accueil" ? 0 : t.getBoundingClientRect().top + getY() - (id === "projets" ? 0 : 70);
    goTo(y);
  };
  document.addEventListener("click", onClick);
  return () => document.removeEventListener("click", onClick);
}

/* ==============================================================
   DECK : fenêtres qu'on attrape et qu'on lance. Un ressort amorti
   les ramène derrière la pile, comme un boomerang.
   ============================================================== */
function setupDeck() {
  const stack = $("#deckStack");
  const deckEl = $("#deck");
  const N = PROJECTS.length;
  const cards = PROJECTS.map((p, i) => {
    const el = document.createElement("article");
    el.className = "win";
    el.dataset.slug = p.slug;
    el.innerHTML = `
      <div class="win__bar"><i></i><i></i><i></i><span class="win__url">${esc(p.domain)}</span></div>
      <div class="win__shot"><img src="${esc(ASSET(p.cover))}" alt="Capture de ${esc(titleCase(p.name))}" draggable="false" ${i > 1 ? 'loading="lazy"' : ""}></div>
      <div class="win__meta"><div><p class="win__kind">${esc(p.kind)}</p><h3 class="win__name">${esc(p.name)}</h3></div><span class="win__open" data-icon="arrow"></span></div>`;
    stack.appendChild(el);
    return el;
  });
  icons(stack);
  let order = cards.map((_, i) => i);
  const SLOTS = [
    { x: 0, y: 0, s: 1, r: 0 },
    { x: 18, y: -26, s: 0.95, r: 2.2 },
    { x: -14, y: -48, s: 0.9, r: -2.4 },
    { x: 10, y: -66, s: 0.85, r: 3 },
    { x: 0, y: -80, s: 0.8, r: -1.5 }
  ];
  const slot = (i) => {
    const k = clamp(stack.clientWidth / 640, 0.45, 1);
    const s = SLOTS[Math.min(i, SLOTS.length - 1)];
    return { x: s.x * k, y: s.y * k, s: s.s, r: s.r * (0.6 + 0.4 * k) };
  };
  const tf = (x, y, s, r) => `translate3d(${x}px, ${y}px, 0) scale(${s}) rotate(${r}deg)`;
  const layout = (skip) => {
    order.forEach((ci, i) => {
      const el = cards[ci];
      el.style.zIndex = String(N - i);
      el.dataset.cursor = i === 0 ? "Lancer" : "";
      el.setAttribute("aria-hidden", i === 0 ? "false" : "true");
      el.style.filter = i === 0 ? "none" : `brightness(${1 - i * 0.06})`;
      if (el === skip) return;
      const s = slot(i);
      el.style.transform = tf(s.x, s.y, s.s, s.r);
      el.style.opacity = i > 4 ? "0" : "1";
    });
  };
  layout();

  let flying = null;
  let drag = null;
  let lastUser = performance.now();
  let auto = null;
  let visible = true;

  const fly = (el, vx, vy, x = 0, y = 0) => {
    if (flying) return;
    const sp = Math.hypot(vx, vy);
    if (sp > 4200) { vx *= 4200 / sp; vy *= 4200 / sp; }
    el.classList.add("is-fly");
    const st = { x, y, vx, vy, r: x * 0.06, vr: vx * 0.12, s: 1, vs: 0, swapped: false };
    flying = { el, st };
    const k = 15, c = 2 * 0.38 * Math.sqrt(k);
    let t0 = performance.now();
    const step = (t) => {
      const dt = Math.min(0.032, (t - t0) / 1000);
      t0 = t;
      const back = slot(N - 1);
      const tx = st.swapped ? back.x : 0, ty = st.swapped ? back.y : 0, tr = st.swapped ? back.r : 0, ts = st.swapped ? back.s : 1;
      const ax = -k * (st.x - tx) - c * st.vx;
      const ay = -k * (st.y - ty) - c * st.vy;
      st.vx += ax * dt; st.vy += ay * dt;
      st.x += st.vx * dt; st.y += st.vy * dt;
      st.vr += (-k * (st.r - tr) - c * 0.9 * st.vr) * dt; st.r += st.vr * dt;
      st.vs += (-k * (st.s - ts) - c * st.vs) * dt; st.s += st.vs * dt;
      // au sommet de la trajectoire, la fenêtre passe derrière la pile
      if (!st.swapped && st.x * st.vx + st.y * st.vy < 0) {
        st.swapped = true;
        const ci = cards.indexOf(el);
        order = order.filter((o) => o !== ci).concat(ci);
        layout(el);
        el.style.zIndex = "0";
      }
      const scaleFly = st.swapped ? st.s : 1 + Math.min(0.06, Math.hypot(st.x, st.y) / 6000);
      el.style.transform = tf(st.x, st.y, scaleFly, st.r);
      const rest = Math.hypot(st.x - tx, st.y - ty) < 0.6 && Math.hypot(st.vx, st.vy) < 8;
      if (st.swapped && rest) {
        el.classList.remove("is-fly");
        flying = null;
        layout();
        return;
      }
      requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  };

  const top = () => cards[order[0]];
  const onDown = (e) => {
    const el = e.target.closest(".win");
    if (!el || el !== top() || flying || e.button > 0) return;
    el.setPointerCapture?.(e.pointerId);
    el.classList.add("is-drag");
    drag = { el, id: e.pointerId, sx: e.clientX, sy: e.clientY, x: 0, y: 0, moved: 0, hist: [{ x: e.clientX, y: e.clientY, t: performance.now() }] };
    lastUser = performance.now();
  };
  const onMove = (e) => {
    if (!drag || e.pointerId !== drag.id) return;
    drag.x = e.clientX - drag.sx;
    drag.y = e.clientY - drag.sy;
    drag.moved = Math.max(drag.moved, Math.hypot(drag.x, drag.y));
    const now = performance.now();
    drag.hist.push({ x: e.clientX, y: e.clientY, t: now });
    while (drag.hist.length > 2 && now - drag.hist[0].t > 90) drag.hist.shift();
    drag.el.style.transform = tf(drag.x, drag.y, 1.02, drag.x * 0.05);
  };
  const onUp = (e) => {
    if (!drag || e.pointerId !== drag.id) return;
    const d = drag;
    drag = null;
    d.el.classList.remove("is-drag");
    lastUser = performance.now();
    if (d.moved < 6) {
      // simple clic : on ouvre l'étude de cas
      layout();
      openCase(d.el.dataset.slug, e.clientX, e.clientY);
      return;
    }
    const a = d.hist[0], b = d.hist[d.hist.length - 1];
    const dt = Math.max(16, b.t - a.t) / 1000;
    let vx = (b.x - a.x) / dt, vy = (b.y - a.y) / dt;
    const sp = Math.hypot(vx, vy);
    const dist = Math.hypot(d.x, d.y);
    if (sp < 450 && dist < 110) { layout(); return; } // pas assez lancé : retour en place
    if (sp < 900) { vx = (d.x / dist) * 1700; vy = (d.y / dist) * 1700; }
    fly(d.el, vx, vy, d.x, d.y);
  };
  stack.addEventListener("pointerdown", onDown);
  window.addEventListener("pointermove", onMove);
  window.addEventListener("pointerup", onUp);
  window.addEventListener("pointercancel", onUp);
  const onKey = (e) => {
    if (e.target.closest?.(".win") && (e.key === "Enter" || e.key === " ")) { e.preventDefault(); openCase(top().dataset.slug); }
  };
  stack.addEventListener("keydown", onKey);
  cards.forEach((c) => (c.tabIndex = -1));
  const syncTab = () => cards.forEach((c) => (c.tabIndex = c === top() ? 0 : -1));
  syncTab();

  let dir = 1;
  const throwNext = () => { if (!flying) { fly(top(), 1500 * dir, -650); dir *= 1; } setTimeout(syncTab, 900); };
  $("#deckNext").addEventListener("click", () => { lastUser = performance.now(); throwNext(); });
  $("#deckPrev").addEventListener("click", () => {
    if (flying) return;
    lastUser = performance.now();
    order = [order[N - 1]].concat(order.slice(0, N - 1));
    layout();
    syncTab();
  });

  const io = "IntersectionObserver" in window ? new IntersectionObserver(([en]) => (visible = en.isIntersecting), { threshold: 0.3 }) : null;
  io?.observe(deckEl);

  return {
    start() {
      if (REDUCED) return;
      auto = setInterval(() => {
        if (!visible || drag || flying || document.hidden || document.body.classList.contains("case-open")) return;
        if (performance.now() - lastUser < 6000) return;
        throwNext();
      }, 4200);
    },
    destroy() {
      clearInterval(auto);
      io?.disconnect();
      window.removeEventListener("pointermove", onMove);
      window.removeEventListener("pointerup", onUp);
      window.removeEventListener("pointercancel", onUp);
    }
  };
}

/* ==============================================================
   BANDEAU D'OUTILS : vitesse liée au défilement
   ============================================================== */
const marquee = { x: 0, w: 0, el: null };
function setupMarquee() {
  const track = $("#marquee");
  const one = TOOLS.map((t) => `<p class="marquee__item"><span>${LOGOS[t.id] || ""}</span>${esc(t.name)}</p>`).join("");
  track.innerHTML = one + one + one;
  $$(".marquee__item", track).forEach((p, i) => i >= TOOLS.length && p.setAttribute("aria-hidden", "true"));
  marquee.el = track;
  const measure = () => (marquee.w = track.scrollWidth / 3);
  measure();
  window.addEventListener("resize", measure);
  return () => window.removeEventListener("resize", measure);
}

/* ==============================================================
   PROJETS : la section se fige et défile à l'horizontale
   ============================================================== */
const work = { cur: 0, target: 0, max: 0, pinned: false, panels: [] };
function setupWork() {
  const track = $("#workTrack");
  const html = PROJECTS.map((p, i) => {
    const live = p.status === "live";
    return `<li class="pj" data-slug="${esc(p.slug)}">
      <div class="pj__frame" data-open="${esc(p.slug)}" data-cursor="Ouvrir" role="button" tabindex="0" aria-label="Ouvrir l'étude de cas ${esc(titleCase(p.name))}">
        <div class="win__bar"><i></i><i></i><i></i><span class="win__url">${esc(p.domain)}</span></div>
        <div class="pj__shot"><img src="${esc(ASSET(p.cover))}" alt="Capture de ${esc(titleCase(p.name))}" loading="lazy" decoding="async" draggable="false"></div>
      </div>
      <div class="pj__info">
        <div class="pj__top"><span class="pj__num">${pad2(i + 1)}</span><span class="badge ${live ? "" : "badge--wip"}">${live ? "En ligne" : "En cours"}</span><span class="pj__kind">${esc(p.kind)}</span></div>
        <h3 class="pj__name">${esc(p.name)}</h3>
        <p class="pj__pitch">${esc(p.pitch)}</p>
        <ul class="pj__stack" aria-label="Outils">${p.stack.map((s) => `<li title="${esc(toolName(s))}">${LOGOS[s] || ""}<span class="sr">${esc(toolName(s))}</span></li>`).join("")}</ul>
        <div class="pj__actions">
          <button class="btn btn--ink" type="button" data-open="${esc(p.slug)}" data-magnetic>Étude de cas<span class="btn__dot" data-icon="arrow"></span></button>
          ${p.demo ? `<a class="btn btn--line" href="${esc(safeUrl(p.demo))}" target="_blank" rel="noopener noreferrer" data-magnetic>Voir le site</a>` : ""}
          <a class="pj__more" href="#configurateur" data-type="${projectType(p)}">Le même pour moi</a>
        </div>
      </div>
    </li>`;
  }).join("");
  track.innerHTML = html + `<li class="pj pj--yours"><div class="yours"><p class="yours__q">Le <em>vôtre</em>&thinsp;?</p><p>Le prochain projet de cette liste peut être le vôtre. Décrivez-le en trente secondes.</p><a class="btn btn--marker" href="#configurateur" data-magnetic>Composer mon site<span class="btn__dot" data-icon="arrow"></span></a></div></li>`;
  icons(track);
  $("#workTotal").textContent = pad2(PROJECTS.length);
  work.panels = $$(".pj", track).map((el) => ({ el, img: $(".pj__shot img", el) }));

  const onOpen = (e) => {
    const t = e.target.closest("[data-open]");
    if (!t) return;
    if (e.type === "keydown" && e.key !== "Enter" && e.key !== " ") return;
    e.preventDefault();
    openCase(t.dataset.open, e.clientX, e.clientY);
  };
  track.addEventListener("click", onOpen);
  track.addEventListener("keydown", onOpen);

  const vp = $("#workViewport");
  const measure = () => {
    const sec = $("#projets");
    work.pinned = innerWidth > 900;
    if (work.pinned) {
      work.max = Math.max(0, track.scrollWidth - innerWidth);
      sec.style.height = innerHeight + work.max + "px";
    } else {
      sec.style.height = "";
      track.style.transform = "";
      work.max = 0;
    }
  };
  measure();
  const onVp = () => {
    if (work.pinned) return;
    const max = vp.scrollWidth - vp.clientWidth;
    const p = max > 0 ? vp.scrollLeft / max : 0;
    $("#workRail").style.transform = `scaleX(${p})`;
    $("#workIndex").textContent = pad2(Math.min(PROJECTS.length, Math.round(p * PROJECTS.length) + 1));
  };
  vp.addEventListener("scroll", onVp, { passive: true });
  window.addEventListener("resize", measure);
  setTimeout(measure, 600);
  return () => window.removeEventListener("resize", measure);
}

function updateWork(dtk) {
  if (!work.pinned) return;
  const sec = $("#projets");
  const r = sec.getBoundingClientRect();
  const span = sec.offsetHeight - innerHeight;
  const p = span > 0 ? clamp(-r.top / span, 0, 1) : 0;
  work.target = p * work.max;
  work.cur = REDUCED ? work.target : lerp(work.cur, work.target, 1 - Math.pow(1 - 0.14, dtk));
  if (Math.abs(work.cur - work.target) < 0.1) work.cur = work.target;
  $("#workTrack").style.transform = `translate3d(${-work.cur}px,0,0)`;
  $("#workRail").style.transform = `scaleX(${work.max ? work.cur / work.max : 0})`;
  if (r.bottom < 0 || r.top > innerHeight) return;
  const vw = innerWidth;
  let best = 0, bestD = 9;
  work.panels.forEach(({ el, img }, i) => {
    const b = el.getBoundingClientRect();
    const d = (b.left + b.width / 2 - vw / 2) / vw;
    const ad = Math.min(1, Math.abs(d));
    if (ad < bestD && i < PROJECTS.length) { bestD = ad; best = i; }
    if (REDUCED) return;
    el.style.transform = `scale(${1 - ad * 0.07}) rotate(${d * -1.6}deg)`;
    el.style.opacity = String(1 - ad * 0.35);
    if (img) img.style.transform = `translate3d(${clamp(d, -0.8, 0.8) * -3.5}%,0,0)`;
  });
  $("#workIndex").textContent = pad2(best + 1);
}

/* ==============================================================
   SERVICES : cartes inclinables, maquettes qui s'animent
   ============================================================== */
function setupServices() {
  const cards = $$(".svc");
  const offs = [];
  cards.forEach((c) => {
    if (FINE && !REDUCED) {
      const mv = (e) => {
        const r = c.getBoundingClientRect();
        const x = (e.clientX - r.left) / r.width - 0.5, y = (e.clientY - r.top) / r.height - 0.5;
        c.style.transform = `perspective(900px) rotateX(${-y * 5}deg) rotateY(${x * 6}deg) translateY(-4px)`;
      };
      const en = () => { c.classList.remove("is-live"); c.offsetWidth; c.classList.add("is-live"); };
      const lv = () => { c.style.transform = ""; };
      c.addEventListener("pointermove", mv);
      c.addEventListener("pointerenter", en);
      c.addEventListener("pointerleave", lv);
    }
  });
  // la maquette prend vie quand la carte est bien visible (et au survol)
  if ("IntersectionObserver" in window) {
    const io = new IntersectionObserver((es) => es.forEach((e) => e.target.classList.toggle("is-live", e.isIntersecting)), { threshold: 0.65 });
    cards.forEach((c) => io.observe(c));
    offs.push(() => io.disconnect());
  }
  return () => offs.forEach((f) => f());
}

/* ==============================================================
   CONFIGURATEUR : la maquette se construit en direct
   ============================================================== */
const configApi = {};
function setupConfig() {
  const state = { type: "vitrine", mods: new Set(PROJECT_TYPES[0].base), delay: null };
  const typesEl = $("#cfgTypes"), modsEl = $("#cfgModules"), delEl = $("#cfgDelays");
  const canvas = $("#cfgCanvas"), empty = $("#cfgEmpty");
  const chip = (label, attrs, plus) => `<button type="button" class="chip" ${attrs} aria-pressed="false">${plus ? '<span class="chip__plus" aria-hidden="true"></span>' : ""}${esc(label)}</button>`;
  typesEl.innerHTML = PROJECT_TYPES.map((t) => chip(t.label, `data-t="${t.id}"`)).join("");
  modsEl.innerHTML = MODULES.map((m) => chip(m.label, `data-m="${m.id}"`, true)).join("");
  delEl.innerHTML = DELAYS.map((d, i) => chip(d, `data-d="${i}"`)).join("");
  const urls = { vitrine: "votre-entreprise.com", landing: "votre-offre.com", app: "app.votre-projet.com", refonte: "votre-site.com · v2" };

  const nodes = new Map();
  const render = () => {
    $$("[data-t]", typesEl).forEach((b) => b.setAttribute("aria-pressed", String(b.dataset.t === state.type)));
    $$("[data-m]", modsEl).forEach((b) => b.setAttribute("aria-pressed", String(state.mods.has(b.dataset.m))));
    $$("[data-d]", delEl).forEach((b) => b.setAttribute("aria-pressed", String(DELAYS[+b.dataset.d] === state.delay)));
    $("#cfgUrl").textContent = urls[state.type] || "votre-site.com";

    // blocs retirés : ils s'envolent
    nodes.forEach((el, id) => {
      if (!state.mods.has(id)) {
        nodes.delete(id);
        el.classList.add("is-out");
        setTimeout(() => el.remove(), 380);
      }
    });
    // blocs ajoutés : ils tombent à leur place
    let k = 0;
    MODULES.forEach((m) => {
      if (!state.mods.has(m.id)) return;
      if (!nodes.has(m.id)) {
        const el = document.createElement("div");
        el.className = `blk blk--${m.id}`;
        el.innerHTML = `<b>${esc(m.label)}</b>`;
        el.style.animationDelay = k * 45 + "ms";
        k++;
        const next = MODULES.slice(MODULES.indexOf(m) + 1).map((x) => nodes.get(x.id)).find(Boolean);
        canvas.insertBefore(el, next || null);
        nodes.set(m.id, el);
      }
    });
    const count = state.mods.size;
    canvas.classList.toggle("is-dense", count > 6);
    empty.style.display = count ? "none" : "";
    const w = MODULES.filter((m) => state.mods.has(m.id)).reduce((s, m) => s + m.w, 0);
    $("#cfgSize").textContent = !count ? "—" : w <= 4 ? "Projet léger" : w <= 9 ? "Projet moyen" : "Projet ambitieux";
    $("#cfgCount").textContent = count + (count > 1 ? " blocs" : " bloc");
    $("#cfgBar").style.width = Math.min(100, (w / 16) * 100) + "%";
    $("#cfgWa").href = waUrl(message());
  };
  const message = () => {
    const t = PROJECT_TYPES.find((x) => x.id === state.type);
    const mods = MODULES.filter((m) => state.mods.has(m.id)).map((m) => m.label.toLowerCase());
    let txt = `Bonjour Junior, j'ai un projet : ${t ? t.label.toLowerCase() : "un site"}`;
    if (mods.length) txt += `, avec ${mods.join(", ")}`;
    txt += ".";
    if (state.delay) txt += ` Délai souhaité : ${state.delay.toLowerCase()}.`;
    return txt;
  };
  configApi.setType = (id, keepScroll) => {
    const t = PROJECT_TYPES.find((x) => x.id === id);
    if (!t) return;
    state.type = id;
    state.mods = new Set(t.base);
    render();
  };
  typesEl.addEventListener("click", (e) => { const b = e.target.closest("[data-t]"); if (b) configApi.setType(b.dataset.t); });
  modsEl.addEventListener("click", (e) => {
    const b = e.target.closest("[data-m]");
    if (!b) return;
    const id = b.dataset.m;
    state.mods.has(id) ? state.mods.delete(id) : state.mods.add(id);
    render();
  });
  delEl.addEventListener("click", (e) => {
    const b = e.target.closest("[data-d]");
    if (!b) return;
    const d = DELAYS[+b.dataset.d];
    state.delay = state.delay === d ? null : d;
    render();
  });
  $("#cfgReset").addEventListener("click", () => { state.mods.clear(); state.delay = null; render(); });
  $("#cfgToForm").addEventListener("click", () => {
    const f = $("#form");
    f.elements.message.value = message();
    const r = $$('input[name="subject"]', f).find((x) => x.value === "Projet de site");
    if (r) r.checked = true;
    goTo($("#contact").getBoundingClientRect().top + getY() - 40);
    setTimeout(() => f.elements.name.focus({ preventScroll: true }), REDUCED ? 0 : 900);
  });
  render();
}

/* ==============================================================
   PARCOURS : la ligne se trace au défilement
   ============================================================== */
function setupTimeline() {
  const list = $("#timelineList");
  list.innerHTML = PATH.map((s) => {
    const tag = s.state === "now" ? '<span class="tl__tag">En ce moment</span>' : s.state === "next" ? '<span class="tl__tag">À venir</span>' : "";
    const link = s.link ? `<a class="tl__link" href="${esc(ASSET(s.link))}" target="_blank" rel="noopener noreferrer">${esc(s.linkLabel)}<span data-icon="arrow"></span></a>` : "";
    return `<li class="tl tl--${s.state}"><span class="tl__dot" aria-hidden="true"></span><div class="tl__card"><p class="tl__when">${esc(s.when)}${tag}</p><h3 class="tl__title">${esc(s.title)}</h3><p class="tl__place">${esc(s.place)}</p>${link}</div></li>`;
  }).join("");
  icons(list);
}
function updateTimeline() {
  const tl = $("#timeline");
  const r = tl.getBoundingClientRect();
  if (r.bottom < -100 || r.top > innerHeight + 100) return;
  const p = clamp((innerHeight * 0.62 - r.top) / r.height, 0, 1);
  $("#timelineFill").style.transform = `scaleY(${p})`;
  const lineY = r.top + p * r.height;
  $$(".tl", tl).forEach((li) => {
    const d = $(".tl__dot", li).getBoundingClientRect();
    li.classList.toggle("is-in", d.top + 9 <= lineY + 1);
  });
  const pr = $("#process");
  const q = pr.getBoundingClientRect();
  pr.style.setProperty("--p", clamp((innerHeight * 0.85 - q.top) / (innerHeight * 0.5), 0, 1).toFixed(3));
}

/* ==============================================================
   OUTILS : survoler un logo montre où il a servi
   ============================================================== */
function setupStack() {
  const grid = $("#stackGrid");
  const info = $("#stackInfo");
  const idle = info.textContent;
  grid.innerHTML = TOOLS.map((t) => `<li class="tool" tabindex="0" data-tool="${t.id}"><span>${LOGOS[t.id] || ""}</span><p>${esc(t.name)}</p></li>`).join("");
  const text = (id) => {
    const used = PROJECTS.filter((p) => p.stack.includes(id)).map((p) => titleCase(p.name));
    if (id === "github") return "<b>GitHub</b> · code et mise en ligne de chaque projet publié";
    if (id === "vscode") return "<b>VS Code</b> · mon éditeur au quotidien";
    return `<b>${esc(toolName(id))}</b> · ${used.length ? "utilisé dans " + used.map(esc).join(", ") : "étudié en cours"}`;
  };
  const show = (el) => {
    $$(".tool", grid).forEach((t) => t.classList.toggle("is-on", t === el));
    info.innerHTML = el ? text(el.dataset.tool) : esc(idle);
  };
  grid.addEventListener("pointerover", (e) => show(e.target.closest(".tool")));
  grid.addEventListener("pointerleave", () => show(null));
  grid.addEventListener("focusin", (e) => show(e.target.closest(".tool")));
  grid.addEventListener("focusout", () => show(null));
  grid.addEventListener("click", (e) => show(e.target.closest(".tool")));
}

/* ==============================================================
   CONTACT : liens, copie de l'email, formulaire sécurisé
   ============================================================== */
function setupContactLinks() {
  const mail = $("#mailLink");
  mail.textContent = mailAddr();
  mail.href = "mailto:" + mailAddr();
  $("#waLink").href = waUrl("Bonjour Junior, je vous contacte depuis votre portfolio.");
  $("#heroWa").href = waUrl("Bonjour Junior, j'aimerais parler d'un projet.");
  $("#ghLink").href = CONTACT.github;
  $("#inLink").href = CONTACT.linkedin;
  $("#year").textContent = new Date().getFullYear();
  $("#mailCopy").addEventListener("click", async () => {
    const ok = $("#mailOk");
    try {
      await navigator.clipboard.writeText(mailAddr());
      ok.textContent = "Copié";
    } catch (e) {
      const r = document.createRange();
      r.selectNodeContents(mail);
      const s = getSelection(); s.removeAllRanges(); s.addRange(r);
      ok.textContent = "Sélectionné";
    }
    clearTimeout(ok._t);
    ok._t = setTimeout(() => (ok.textContent = ""), 1800);
  });
}

function setupForm() {
  const form = $("#form");
  const msg = $("#formMsg");
  const send = $("#formSend");
  const emailRe = /^[^\s@]{1,64}@[^\s@]{1,190}\.[a-z]{2,}$/i;
  const fields = ["name", "email", "message"];
  fields.forEach((n) => form.elements[n].addEventListener("input", () => form.elements[n].closest(".field").classList.remove("is-bad")));
  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const v = (n) => String(form.elements[n].value || "").trim();
    if (v("_gotcha")) return; // robot
    const bad = fields.filter((n) => !v(n) || (n === "email" && !emailRe.test(v(n))) || (n === "message" && v(n).length < 10));
    fields.forEach((n) => form.elements[n].closest(".field").classList.toggle("is-bad", bad.includes(n)));
    if (bad.length) { msg.textContent = bad.includes("message") && v("message") ? "Votre message est un peu court." : "Vérifiez les champs en surbrillance."; return; }
    let lastSent = 0;
    try { lastSent = +localStorage.getItem("p08-njdev-sent") || 0; } catch (err) {}
    if (Date.now() - lastSent < 60000) { msg.textContent = "Un message vient de partir. Patientez une minute."; return; }
    const subject = (form.querySelector('input[name="subject"]:checked') || {}).value || "Contact";
    const data = { name: v("name").slice(0, 80), email: v("email").slice(0, 120), subject, message: v("message").slice(0, 2000) };
    const done = () => {
      try { localStorage.setItem("p08-njdev-sent", String(Date.now())); } catch (err) {}
      form.reset();
      msg.textContent = "";
      $("#formBody").hidden = true;
      $("#formDone").hidden = false;
    };
    const viaMail = () => {
      const body = `${data.message}\n\n${data.name} · ${data.email}`;
      location.href = `mailto:${mailAddr()}?subject=${encodeURIComponent("[Portfolio] " + data.subject)}&body=${encodeURIComponent(body)}`;
      done();
    };
    if (PREVIEW || !/^https:\/\/formspree\.io\//.test(CONTACT.formEndpoint || "")) return viaMail();
    send.disabled = true;
    msg.textContent = "Envoi…";
    try {
      const res = await fetch(CONTACT.formEndpoint, { method: "POST", headers: { "Content-Type": "application/json", Accept: "application/json" }, body: JSON.stringify({ ...data, _subject: "[Portfolio] " + subject }) });
      if (!res.ok) throw new Error("http");
      done();
    } catch (err) {
      msg.textContent = "L'envoi a échoué. Écrivez-moi directement par email.";
    } finally {
      send.disabled = false;
    }
  });
  $("#formAgain").addEventListener("click", () => { $("#formBody").hidden = false; $("#formDone").hidden = true; form.elements.name.focus(); });
}

/* ==============================================================
   ÉTUDE DE CAS : s'ouvre en cercle depuis le clic
   ============================================================== */
let caseState = { slug: null, opener: null };
function caseHtml(p) {
  const i = PROJECTS.indexOf(p);
  const next = PROJECTS[(i + 1) % PROJECTS.length];
  const live = p.status === "live";
  const st = (n) => `data-stagger data-i="${n}"`;
  const list = (arr) => `<ul>${arr.map((x) => `<li>${esc(x)}</li>`).join("")}</ul>`;
  return `
    <div class="case__top" ${st(0)}><span class="badge ${live ? "" : "badge--wip"}">${live ? "En ligne" : "En cours"}</span><span class="pj__kind">${esc(p.kind)}</span></div>
    <h2 class="case__name" id="caseName" ${st(1)}>${esc(p.name)}</h2>
    <p class="case__pitch" ${st(2)}>${esc(p.pitch)}</p>
    <dl class="case__meta" ${st(3)}>
      <div><dt>Année</dt><dd>${esc(p.year)}</dd></div>
      <div><dt>Type</dt><dd>${esc(p.kind.split(" · ")[0])}</dd></div>
      <div><dt>En bref</dt><dd>${esc(p.facts[0])}</dd></div>
      <div><dt>Outils</dt><dd><ul class="pj__stack">${p.stack.map((s) => `<li title="${esc(toolName(s))}">${LOGOS[s] || ""}<span class="sr">${esc(toolName(s))}</span></li>`).join("")}</ul></dd></div>
    </dl>
    <div class="gallery" id="gallery" data-cursor="${p.gallery.length > 1 ? "Glisser" : ""}" ${st(4)}>
      <div class="gallery__track" id="galleryTrack">
        ${p.gallery.map((g) => `<figure><div class="pj__frame"><div class="win__bar"><i></i><i></i><i></i><span class="win__url">${esc(p.domain)}</span></div><img src="${esc(ASSET(g.src))}" alt="${esc(titleCase(p.name))} : ${esc(g.label)}" draggable="false"></div><figcaption>${esc(g.label)}</figcaption></figure>`).join("")}
      </div>
    </div>
    ${p.gallery.length > 1 ? `<p class="gallery__hint" ${st(4)}>Faites glisser les captures.</p>` : ""}
    <div class="case__cols">
      <section class="case__block case__block--wide" ${st(5)}><h3>Le point de départ</h3><p>${esc(p.need)}</p></section>
      <section class="case__block" ${st(6)}><h3>Ce que j'ai construit</h3>${list(p.built)}</section>
      <section class="case__block" ${st(7)}><h3>Ce que j'ai appris</h3>${list(p.learned)}</section>
      <section class="case__block case__block--wide case__block--honest" ${st(8)}><h3>Où en est le projet</h3><p>${esc(p.honest)}</p></section>
    </div>
    <div class="case__actions" ${st(9)}>
      ${p.demo ? `<a class="btn btn--ink" href="${esc(safeUrl(p.demo))}" target="_blank" rel="noopener noreferrer">Voir le site<span class="btn__dot" data-icon="arrow"></span></a>` : `<span class="btn btn--line" aria-disabled="true">Pas encore de démo publique</span>`}
      ${p.code ? `<a class="btn btn--line" href="${esc(safeUrl(p.code))}" target="_blank" rel="noopener noreferrer"><span class="btn__logo">${LOGOS.github}</span>Voir le code</a>` : ""}
      <a class="btn btn--marker" href="#configurateur" data-close-case data-type="${projectType(p)}">Le même pour moi<span class="btn__dot" data-icon="arrow"></span></a>
    </div>
    <button class="case__next" type="button" data-next="${esc(next.slug)}" ${st(10)}><div><small>Projet suivant</small><b>${esc(next.name)}</b></div><span data-icon="right"></span></button>`;
}

function openCase(slug, x, y) {
  const p = PROJECTS.find((q) => q.slug === slug);
  const box = $("#case");
  if (!p || !box) return;
  const inner = $("#caseInner");
  const already = !box.hidden;
  if (!already) caseState.opener = document.activeElement;
  caseState.slug = slug;
  inner.innerHTML = caseHtml(p);
  $$("[data-i]", inner).forEach((el) => el.style.setProperty("--i", el.dataset.i));
  icons(inner);
  $("#caseScroll").scrollTop = 0;
  box.style.setProperty("--cx", (x ?? innerWidth / 2) + "px");
  box.style.setProperty("--cy", (y ?? innerHeight / 2) + "px");
  if (!already) {
    box.hidden = false;
    box.offsetWidth;
    box.classList.add("is-open");
    lock(true); document.body.classList.add("case-open");
    setTimeout(() => $("#caseClose").focus({ preventScroll: true }), 50);
  } else {
    box.classList.remove("is-open");
    box.offsetWidth;
    box.classList.add("is-open");
  }
  setupGallery();
  try { history.replaceState(null, "", "#projet/" + slug); } catch (e) {}
}
function closeCase() {
  const box = $("#case");
  if (!box || box.hidden) return;
  box.classList.remove("is-open");
  lock(false); document.body.classList.remove("case-open");
  setTimeout(() => { if (!box.classList.contains("is-open")) box.hidden = true; }, 800);
  try { history.replaceState(null, "", "#projets"); } catch (e) {}
  caseState.opener?.focus?.({ preventScroll: true });
}
function setupCase() {
  const box = $("#case");
  $("#caseClose").addEventListener("click", closeCase);
  box.addEventListener("click", (e) => {
    const n = e.target.closest("[data-next]");
    if (n) { openCase(n.dataset.next, e.clientX, e.clientY); return; }
    if (e.target.closest("[data-close-case]")) closeCase();
  });
  const onKey = (e) => {
    if (box.hidden) return;
    if (e.key === "Escape") closeCase();
    if (e.key === "Tab") {
      const f = $$('a[href], button:not([disabled]), [tabindex="0"]', box).filter((el) => el.offsetParent !== null);
      if (!f.length) return;
      const first = f[0], last = f[f.length - 1];
      if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
      else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
    }
  };
  document.addEventListener("keydown", onKey);
  const onHash = () => {
    const m = location.hash.match(/^#projet\/([\w-]+)/);
    if (m && m[1] !== caseState.slug) openCase(m[1]);
  };
  window.addEventListener("hashchange", onHash);
  return () => { document.removeEventListener("keydown", onKey); window.removeEventListener("hashchange", onHash); };
}

/* galerie glissée avec inertie */
function setupGallery() {
  const g = $("#gallery"), track = $("#galleryTrack");
  if (!g || !track) return;
  let x = 0, v = 0, dragging = false, sx = 0, ox = 0, lastX = 0, lastT = 0, raf = 0;
  const bounds = () => Math.min(0, g.clientWidth - track.scrollWidth);
  const apply = () => (track.style.transform = `translate3d(${x}px,0,0)`);
  const glide = () => {
    v *= 0.93;
    x += v;
    const min = bounds();
    if (x > 0) { x = lerp(x, 0, 0.2); v *= 0.5; }
    if (x < min) { x = lerp(x, min, 0.2); v *= 0.5; }
    apply();
    if (Math.abs(v) > 0.2 || x > 0.5 || x < min - 0.5) raf = requestAnimationFrame(glide);
  };
  g.addEventListener("pointerdown", (e) => {
    if (e.button > 0) return;
    dragging = true; sx = e.clientX; ox = x; lastX = e.clientX; lastT = performance.now(); v = 0;
    cancelAnimationFrame(raf);
    g.classList.add("is-drag");
    g.setPointerCapture?.(e.pointerId);
  });
  g.addEventListener("pointermove", (e) => {
    if (!dragging) return;
    const min = bounds();
    let nx = ox + (e.clientX - sx);
    if (nx > 0) nx *= 0.35;
    if (nx < min) nx = min + (nx - min) * 0.35;
    const t = performance.now();
    v = ((e.clientX - lastX) / Math.max(1, t - lastT)) * 16;
    lastX = e.clientX; lastT = t;
    x = nx; apply();
  });
  const up = () => { if (!dragging) return; dragging = false; g.classList.remove("is-drag"); raf = requestAnimationFrame(glide); };
  g.addEventListener("pointerup", up);
  g.addEventListener("pointercancel", up);
}

/* ==============================================================
   CURSEUR, BOUTONS MAGNÉTIQUES, PORTRAIT, PIED DE PAGE
   ============================================================== */
const cursor = { x: -100, y: -100, cx: -100, cy: -100, on: false };
function setupCursor() {
  if (!FINE || REDUCED) return;
  const el = $("#cursor"), label = $("#cursorLabel");
  const mv = (e) => {
    cursor.x = e.clientX; cursor.y = e.clientY;
    if (!cursor.on) { cursor.on = true; cursor.cx = cursor.x; cursor.cy = cursor.y; el.classList.add("is-on"); }
    const t = e.target.closest?.("[data-cursor]");
    const txt = t && t.dataset.cursor;
    el.classList.toggle("is-big", !!txt);
    if (txt) label.textContent = txt;
    el.classList.toggle("is-hidden", !txt && !!e.target.closest?.("input, textarea"));
  };
  const out = (e) => { if (!e.relatedTarget) el.classList.remove("is-on"), (cursor.on = false); };
  window.addEventListener("pointermove", mv, { passive: true });
  document.addEventListener("pointerout", out);
  return () => { window.removeEventListener("pointermove", mv); document.removeEventListener("pointerout", out); };
}

function setupMagnetic() {
  if (!FINE || REDUCED) return;
  const mv = (e) => {
    const b = e.target.closest?.("[data-magnetic]");
    $$("[data-magnetic].is-mag").forEach((x) => { if (x !== b) { x.classList.remove("is-mag"); x.style.transform = ""; } });
    if (!b) return;
    const r = b.getBoundingClientRect();
    const dx = e.clientX - (r.left + r.width / 2), dy = e.clientY - (r.top + r.height / 2);
    b.classList.add("is-mag");
    b.style.transform = `translate(${dx * 0.18}px, ${dy * 0.3}px)`;
  };
  window.addEventListener("pointermove", mv, { passive: true });
  return () => window.removeEventListener("pointermove", mv);
}

function setupPortrait() {
  const fr = $("#portrait");
  if (!fr || !FINE || REDUCED) return;
  fr.addEventListener("pointermove", (e) => {
    const r = fr.getBoundingClientRect();
    const x = (e.clientX - r.left) / r.width - 0.5, y = (e.clientY - r.top) / r.height - 0.5;
    fr.style.transform = `perspective(1000px) rotateY(${x * 7}deg) rotateX(${-y * 6}deg)`;
  });
  fr.addEventListener("pointerleave", () => (fr.style.transform = ""));
}

function setupFooter() {
  const big = $("#footBig");
  const txt = big.textContent;
  big.innerHTML = Array.from(txt).map((c) => `<span class="ch">${c === " " ? "&nbsp;" : esc(c)}</span>`).join("");
  big.setAttribute("aria-label", txt);
  const chars = $$(".ch", big);
  if (REDUCED) return;
  const mv = (e) => {
    chars.forEach((c) => {
      const r = c.getBoundingClientRect();
      const d = Math.abs(e.clientX - (r.left + r.width / 2));
      const k = Math.max(0, 1 - d / 220);
      c.style.transform = `translateY(${-k * 0.16}em)`;
      c.classList.toggle("is-up", k > 0.55);
    });
  };
  const lv = () => chars.forEach((c) => { c.style.transform = ""; c.classList.remove("is-up"); });
  big.addEventListener("pointermove", mv);
  big.addEventListener("pointerleave", lv);
  // une vague quand le pied de page arrive à l'écran
  if ("IntersectionObserver" in window) {
    const io = new IntersectionObserver(([en]) => {
      if (!en.isIntersecting) return;
      io.disconnect();
      chars.forEach((c, i) => setTimeout(() => {
        c.style.transform = "translateY(-0.14em)"; c.classList.add("is-up");
        setTimeout(() => { c.style.transform = ""; c.classList.remove("is-up"); }, 260);
      }, i * 45));
    }, { threshold: 0.6 });
    io.observe(big);
  }
}

/* ==============================================================
   BOUCLE : tout ce qui suit le défilement, une seule fois par image
   ============================================================== */
function startLoop() {
  let raf = 0, last = performance.now(), lastY = getY(), vel = 0, mdir = 1;
  const prog = $("#progress");
  const cur = $("#cursor");
  const portraitImg = $("#portrait img");
  const tick = (t) => {
    const dt = Math.min(64, t - last);
    last = t;
    const dtk = dt / 16.67;
    const y = getY();
    const dy = y - lastY;
    lastY = y;
    vel = lerp(vel, dy / Math.max(1, dtk), 0.2);

    const max = scrollMax();
    prog.style.transform = `scaleX(${max > 0 ? y / max : 0})`;
    updateHeader(y);
    updateWork(dtk);
    updateTimeline();

    // bandeau : la vitesse et le sens suivent le défilement
    if (marquee.el && marquee.w && !REDUCED) {
      if (Math.abs(vel) > 0.5) mdir = vel > 0 ? 1 : -1;
      marquee.x -= (0.7 + Math.min(14, Math.abs(vel) * 0.35)) * mdir * dtk;
      if (marquee.x <= -marquee.w) marquee.x += marquee.w;
      if (marquee.x > 0) marquee.x -= marquee.w;
      marquee.el.style.transform = `translate3d(${marquee.x}px,0,0)`;
    }
    // curseur avec un léger retard
    if (cursor.on) {
      cursor.cx = lerp(cursor.cx, cursor.x, 1 - Math.pow(1 - 0.25, dtk));
      cursor.cy = lerp(cursor.cy, cursor.y, 1 - Math.pow(1 - 0.25, dtk));
      cur.style.transform = `translate3d(${cursor.cx}px, ${cursor.cy}px, 0)`;
    }
    // portrait en légère parallaxe
    if (portraitImg && !REDUCED) {
      const r = portraitImg.parentElement.getBoundingClientRect();
      if (r.bottom > 0 && r.top < innerHeight) {
        const p = (r.top + r.height / 2 - innerHeight / 2) / innerHeight;
        portraitImg.parentElement.style.setProperty("--iy", (p * -24).toFixed(1) + "px");
        portraitImg.closest(".portrait").style.setProperty("--py", (p * 30).toFixed(1) + "px");
      }
    }
    raf = requestAnimationFrame(tick);
  };
  raf = requestAnimationFrame(tick);
  return () => cancelAnimationFrame(raf);
}
