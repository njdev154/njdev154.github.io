/* ==============================================================
   CONTENU DU PORTFOLIO
   Tout le texte qui bouge vit ici : projets, services, parcours,
   blocs du configurateur. Pour ajouter un projet, copie un bloc
   de PROJECTS et dépose ses captures dans assets/img/.
   ============================================================== */

export const CONTACT = {
  // l'adresse est assemblée au chargement pour gêner les robots
  mailUser: "ngoranjunior154",
  mailHost: "gmail.com",
  whatsapp: "2250161506296",
  github: "https://github.com/njdev154",
  linkedin: "https://www.linkedin.com/in/junior-ngoran/",
  // laisse vide pour n'utiliser que l'email
  formEndpoint: "https://formspree.io/f/mgaevrwr"
};

export const TOOLS = [
  { id: "html", name: "HTML" },
  { id: "css", name: "CSS" },
  { id: "js", name: "JavaScript" },
  { id: "php", name: "PHP" },
  { id: "laravel", name: "Laravel" },
  { id: "mysql", name: "MySQL" },
  { id: "git", name: "Git" },
  { id: "github", name: "GitHub" },
  { id: "vscode", name: "VS Code" }
];

export const PROJECTS = [
  {
    slug: "cibanque",
    name: "CIBANQUE",
    year: "2026",
    status: "live",
    kind: "Application front-end",
    domain: "njdev154.github.io/cibanque",
    demo: "https://njdev154.github.io/cibanque/",
    code: "https://github.com/njdev154/cibanque",
    stack: ["html", "css", "js", "git"],
    facts: ["8 écrans reliés", "Données en localStorage", "Montants en FCFA"],
    cover: "assets/img/cibanque-dashboard.webp",
    gallery: [
      { src: "assets/img/cibanque-dashboard.webp", label: "Tableau de bord" },
      { src: "assets/img/cibanque-accueil.webp", label: "Accueil" },
      { src: "assets/img/cibanque-login.webp", label: "Connexion" }
    ],
    pitch: "Une banque mobile simulée : ouvrir un compte, suivre son solde, envoyer de l'argent, régler ses factures.",
    need: "Passer d'une simple page à un vrai parcours utilisateur. Une banque était le meilleur terrain d'essai : tout le monde connaît les gestes attendus, donc la moindre incohérence se remarque.",
    built: [
      "Huit écrans reliés, de l'inscription jusqu'au profil",
      "Création de compte et connexion gérées en JavaScript",
      "Solde, virements et historique enregistrés dans le navigateur (localStorage)",
      "Paiement de factures CIE et SODECI, écran carte bancaire"
    ],
    learned: [
      "Garder une interface cohérente d'un écran à l'autre",
      "Lire, écrire et mettre à jour des données sans serveur",
      "Penser aux détails d'usage : devise, mobile money, factures"
    ],
    honest: "En ligne. C'est une simulation : aucun serveur, montants fictifs, aucune transaction réelle."
  },
  {
    slug: "passerelle",
    name: "PASSERELLE",
    year: "2026",
    status: "wip",
    kind: "Application full-stack · Laravel",
    domain: "passerelle · en local",
    demo: null,
    code: "https://github.com/njdev154/passerelle",
    stack: ["laravel", "php", "mysql", "html", "css", "git"],
    facts: ["4 rôles utilisateurs", "Base MySQL", "Vues Blade"],
    cover: "assets/img/passerelle-accueil.webp",
    gallery: [{ src: "assets/img/passerelle-accueil.webp", label: "Accueil" }],
    pitch: "La plateforme qui relie étudiants, entreprises et écoles autour des stages et de l'alternance.",
    need: "Un premier stage se cherche souvent à l'aveugle : des CV envoyés, peu de réponses, aucun suivi. Passerelle réunit les offres et les candidatures, et montre à chacun où en est sa demande.",
    built: [
      "Une application Laravel : routes, contrôleurs, vues Blade",
      "Une base MySQL avec migrations, relations et données de test",
      "Des formulaires validés côté serveur",
      "Un espace par rôle : étudiant, entreprise, école, administration"
    ],
    learned: [
      "Passer du site statique à une application avec serveur",
      "Modéliser des rôles et leurs droits dans une base de données",
      "Organiser un projet qui grandit sans s'y perdre"
    ],
    honest: "En développement, en local. Les étapes de candidature et la validation des offres sont en cours. Pas encore de démo publique."
  },
  {
    slug: "dona-ci",
    name: "DONA CI",
    year: "2026",
    status: "live",
    kind: "Site multi-pages · santé",
    domain: "njdev154.github.io/dona-ci",
    demo: "https://njdev154.github.io/dona-ci/",
    code: "https://github.com/njdev154/dona-ci",
    stack: ["html", "css", "js", "git"],
    facts: ["Identité visuelle dédiée", "3 parcours visiteurs", "Responsive"],
    cover: "assets/img/dona-accueil.webp",
    gallery: [{ src: "assets/img/dona-accueil.webp", label: "Accueil" }],
    pitch: "Un site qui aide entreprises, écoles et associations à organiser une collecte de sang.",
    need: "Un sujet sérieux demande un site qui rassure. Le visiteur doit comprendre en quelques secondes ce qu'il peut faire : organiser une collecte, s'informer, ou donner.",
    built: [
      "Une identité visuelle construite pour le sujet",
      "Plusieurs pages responsive",
      "Trois parcours selon le profil : organisations, donneurs, ressources"
    ],
    learned: [
      "Créer une identité à partir d'un sujet",
      "Hiérarchiser une information sensible sans l'alourdir"
    ],
    honest: "En ligne. Avant un usage réel, contacts et circuits de collecte doivent être validés avec une structure médicale."
  },
  {
    slug: "pigier-connect",
    name: "PIGIER CONNECT",
    year: "2026",
    status: "live",
    kind: "Site vitrine · école",
    domain: "njdev154.github.io/pigier-connect",
    demo: "https://njdev154.github.io/pigier-connect/",
    code: "https://github.com/njdev154/pigier-connect",
    stack: ["html", "css", "js", "git"],
    facts: ["Premier site publié", "Recherche en JavaScript", "Mobile d'abord"],
    cover: "assets/img/pigier-accueil.webp",
    gallery: [
      { src: "assets/img/pigier-accueil.webp", label: "Accueil" },
      { src: "assets/img/pigier-formations.webp", label: "Recherche de formations" }
    ],
    pitch: "Un portail pour explorer les formations d'une école : filières, recherche, FAQ, préinscription.",
    need: "Mon premier site publié, en mars 2026. Le défi : ranger beaucoup d'informations dans une navigation simple, et rester confortable sur téléphone.",
    built: [
      "Une navigation claire entre plusieurs sections",
      "Une mise en page responsive en Flexbox",
      "Une recherche de formations et une FAQ interactives",
      "Un formulaire de préinscription avec message de confirmation"
    ],
    learned: [
      "Penser la navigation d'un site entier",
      "Concevoir pour le mobile dès le départ"
    ],
    honest: "En ligne. Projet personnel, sans lien officiel avec l'école : le formulaire ne transmet aucune inscription."
  },
  {
    slug: "jeuneavenir-ci",
    name: "JEUNEAVENIR CI",
    year: "2026",
    status: "wip",
    kind: "Plateforme · en conception",
    domain: "jeuneavenir · en local",
    demo: null,
    code: null,
    stack: ["html", "css", "js"],
    facts: ["5 piliers", "Parcours guidé", "Front-end"],
    cover: "assets/img/jeuneavenir-accueil.webp",
    gallery: [
      { src: "assets/img/jeuneavenir-accueil.webp", label: "Accueil" },
      { src: "assets/img/jeuneavenir-piliers.webp", label: "Les cinq piliers" }
    ],
    pitch: "Orientation, mentorat et premiers stages : accompagner les jeunes du lycée jusqu'au premier emploi.",
    need: "Beaucoup de jeunes choisissent une filière sans savoir où elle mène. JeuneAvenir veut transformer cette question floue en pistes concrètes : filières, écoles, métiers, stages.",
    built: [
      "Cinq piliers pensés comme un parcours : orientation, découverte, mentorat, insertion, espace personnel",
      "Les écrans principaux et leur navigation"
    ],
    learned: [
      "Découper un grand sujet en parcours simples",
      "Concevoir une plateforme avant d'écrire le code"
    ],
    honest: "En conception, en local. Contenus, comptes et partie serveur restent à construire."
  }
];

/* Parcours, du plus ancien au plus récent.
   state : "done" (fait), "now" (en cours), "next" (à venir) */
export const PATH = [
  { when: "2023 → 2024", title: "Baccalauréat série D", place: "Collège Le Rodin", state: "done" },
  { when: "2024 → 2025", title: "Licence 1 · Informatique Développeur d'Applications", place: "Pigier Côte d'Ivoire · HTML, CSS, C, SQL", state: "done" },
  { when: "Juin 2025", title: "Microsoft Office Specialist · Excel 2016", place: "Certification Certiport", state: "done", link: "assets/docs/certificat-mos-excel-2016.pdf", linkLabel: "Voir le certificat" },
  { when: "2025 → 2026", title: "Licence 2 · BTS IDA", place: "Admissible, validation par le stage", state: "done" },
  { when: "Mars 2026", title: "Premier site en ligne", place: "Pigier Connect, publié sur GitHub Pages", state: "done" },
  { when: "Août 2026 → aujourd'hui", title: "Stage développeur web", place: "YA Consulting", state: "now" },
  { when: "Nov. 2026 → 2027", title: "Licence 3 · IDA", place: "Pigier Côte d'Ivoire · cap sur le full-stack", state: "next" }
];

/* Blocs du configurateur. w = poids dans l'estimation d'envergure */
export const PROJECT_TYPES = [
  { id: "vitrine", label: "Site vitrine", base: ["hero", "about", "services", "contact"] },
  { id: "landing", label: "Landing page", base: ["hero", "reviews", "contact"] },
  { id: "app", label: "Application web", base: ["login", "dashboard"] },
  { id: "refonte", label: "Refonte", base: ["hero", "services", "contact"] }
];

export const MODULES = [
  { id: "hero", w: 1, label: "Bannière d'accueil" },
  { id: "about", w: 1, label: "Présentation" },
  { id: "services", w: 1, label: "Services" },
  { id: "gallery", w: 1, label: "Galerie" },
  { id: "catalog", w: 2, label: "Catalogue" },
  { id: "booking", w: 3, label: "Réservation" },
  { id: "reviews", w: 1, label: "Avis clients" },
  { id: "faq", w: 1, label: "FAQ" },
  { id: "login", w: 3, label: "Espace membre" },
  { id: "dashboard", w: 3, label: "Tableau de bord" },
  { id: "contact", w: 1, label: "Formulaire de contact" }
];

export const DELAYS = ["Urgent", "Sous 1 mois", "2 à 3 mois", "Flexible"];
