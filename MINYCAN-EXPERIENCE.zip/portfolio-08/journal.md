# Journal du projet

## 2026-10-30 — Copilot
- Préparation du projet à une publication GitHub Pages : ajout d'un `.gitignore` et clarification des étapes Git pour Windows dans le README.
- Aucun dépôt public correspondant n'a été trouvé et l'adresse du site répond actuellement 404 ; la création du dépôt, le push et l'activation de Pages restent à faire avec le compte GitHub du propriétaire.
