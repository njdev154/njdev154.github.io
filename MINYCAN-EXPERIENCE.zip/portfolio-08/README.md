# njdev · Portfolio de Junior N'Goran

Portfolio de développeur web junior : sites vitrines, landing pages et applications Laravel.

**Adresse prévue après publication :** https://njdev154.github.io/portfolio-08/

---

## L'idée

Un site qui **se construit sous les yeux du visiteur**, comme un vrai projet web :
maquette → code → mise en ligne.

- **Intro** : `njdev` se tape lettre par lettre, puis le curseur de saisie grandit jusqu'à couvrir l'écran et se retire comme un rideau. Une seule fois par visite, bouton « Passer ».
- **Apparitions** : chaque bloc arrive d'abord sous forme de squelette gris (la maquette), qui se retire pour laisser place au contenu (le rendu).
- **Couleurs** : papier clair, encre bleu nuit, outremer (la couleur du plan), surligneur jaune-vert pour ce qui compte.
- **Typo** : Instrument Sans (titres serrés), Instrument Serif italique pour les mots clés, JetBrains Mono pour les annotations.

## Ce qui bouge

| Partie | Mouvement |
| --- | --- |
| Accueil | Titre qui monte ligne par ligne, mot qui change (*travaillent, vendent, rassurent, convainquent*), surlignage qui se dessine, compteurs. |
| Fenêtres de projets | Pile de fenêtres qu'on **attrape et qu'on lance** : un ressort amorti les ramène derrière la pile, comme un boomerang. Lancer automatique toutes les quelques secondes si personne n'y touche. Clic = étude de cas. |
| Bandeau d'outils | Vitesse et sens liés au défilement. |
| Projets | La section se fige et défile à l'horizontale (sur ordinateur), avec parallaxe dans les captures. Balayage tactile sur mobile. |
| Étude de cas | S'ouvre en cercle depuis le clic, captures à faire glisser avec inertie, lien partageable (`#projet/cibanque`), projet suivant. |
| Services | Cartes inclinables, mini maquettes animées propres à chaque offre. Processus dont la ligne se trace. |
| Configurateur | On choisit un type et des blocs : la maquette se construit en direct (les blocs tombent à leur place), estimation d'envergure, envoi sur WhatsApp ou dans le formulaire. |
| Parcours | La ligne se trace au défilement, les étapes s'allument, l'étape en cours pulse. |
| À propos | Portrait avec parallaxe et inclinaison, matrice d'outils (survoler un logo montre les projets où il a servi). |
| Contact | Email copiable, formulaire sécurisé, « Construisons-le. » géant dont les lettres réagissent au curseur. |
| Partout | Curseur contextuel (Lancer / Ouvrir / Glisser), boutons magnétiques, barre de progression, en-tête qui se cache en descendant, pastille de section active, menu mobile plein écran. |

## Structure

```
index.html          la page (une seule page)
404.html            page d'erreur servie par GitHub Pages
css/style.css       tout le design (couleurs et polices en haut du fichier)
css/noscript.css    affichage propre si JavaScript est désactivé
css/404.css         page 404
js/data.js          LE CONTENU : projets, parcours, services, configurateur, contact
js/main.js          interactions et animations (JavaScript pur, commenté)
js/icons.js         logos des outils et icônes (SVG)
js/start.js         point d'entrée
assets/img/         captures (WebP), portrait, icônes, image de partage
assets/docs/        CV et certificat (PDF)
```

## Modifier le contenu

Presque tout se change dans **`js/data.js`**, sans toucher au HTML :

- **Ajouter un projet** : copie un bloc dans `PROJECTS`, change `slug`, les textes et les images. Il apparaît automatiquement dans la pile de l'accueil, la section Projets, l'étude de cas et la matrice d'outils.
- **Parcours** : `PATH`. `state: "now"` = en cours, `state: "next"` = à venir.
- **Configurateur** : `PROJECT_TYPES`, `MODULES` (le poids `w` sert à l'estimation), `DELAYS`.
- **Contact** : `CONTACT` (email, WhatsApp, GitHub, LinkedIn, formulaire).
- **CV** : remplace `assets/docs/cv-junior-ngoran.pdf` en gardant le même nom.
- **Couleurs / polices** : en haut de `css/style.css`.

## Mettre en ligne (GitHub Pages, gratuit)

Crée sur GitHub un dépôt public nommé **exactement** `njdev154.github.io`, sans générer de README, licence ni `.gitignore` sur GitHub. Dans un terminal PowerShell ouvert dans ce dossier, publie le projet :

```powershell
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/njdev154/njdev154.github.io.git
git push -u origin main
```

Si `origin` existe déjà, vérifie son adresse avec `git remote -v` au lieu de refaire `git remote add origin`.

Ensuite, dans le dépôt GitHub : *Settings → Pages → Build and deployment → Deploy from a branch → `main` / `(root)`*. Attends la fin du déploiement ; le site sera disponible sur https://njdev154.github.io/portfolio-08/.

Le fichier `.nojekyll` est inclus pour que GitHub Pages serve les fichiers sans les traiter avec Jekyll.

Tester en local : `python3 -m http.server` dans le dossier, puis http://localhost:8000
(ouvrir `index.html` en double-clic ne marche pas : les modules JavaScript ont besoin d'un serveur).

## Sécurité

- **Aucune librairie, aucun CDN de scripts, aucun tracker.** Tout le JavaScript vient du site lui-même.
- **Content Security Policy stricte** : seuls les fichiers du site s'exécutent. Exceptions limitées : Google Fonts (polices) et Formspree (envoi du formulaire).
- **Aucun script ni style en ligne** dans le HTML, aucun attribut `onclick`.
- **Formulaire** : validation, longueurs maximales, piège à robots, un message par minute maximum. Si Formspree échoue, le visiteur est invité à écrire par email.
- **Email assemblé en JavaScript** pour gêner les robots collecteurs.
- **Liens externes** en `rel="noopener noreferrer"`, politique de référent stricte.
- **Aucun secret** dans le code (l'identifiant Formspree est public par nature).

## Accessibilité

Lien d'évitement, navigation clavier complète (étude de cas avec piège de focus et touche Échap),
focus visibles, textes alternatifs, `prefers-reduced-motion` respecté (animations coupées),
contenu lisible sans JavaScript.

---

Conçu et codé à la main · HTML, CSS, JavaScript.
