// Captures réelles des 8 portfolios (rendu navigateur du vrai site).
// Usage : node scripts/captures.mjs [baseUrl] [dossierSortie]
import { chromium } from "playwright";
const base = process.argv[2] || "http://localhost:8080";
const out = process.argv[3] || "shots";
const views = { desktop: { width: 1440, height: 900, deviceScaleFactor: 1 }, mobile: { width: 390, height: 844, deviceScaleFactor: 2, isMobile: true, hasTouch: true } };
const browser = await chromium.launch({ executablePath: process.env.CHROME || undefined });
for (let i = Number(process.env.FROM || 1); i <= Number(process.env.TO || 8); i++) {
  const nn = String(i).padStart(2, "0");
  for (const [name, vp] of Object.entries(views)) {
    const ctx = await browser.newContext({ viewport: { width: vp.width, height: vp.height }, deviceScaleFactor: vp.deviceScaleFactor, isMobile: !!vp.isMobile, hasTouch: !!vp.hasTouch, reducedMotion: "reduce", locale: "fr-FR" });
    const page = await ctx.newPage();
    const errors = [];
    page.on("pageerror", (e) => errors.push(e.message));
    if (process.env.OFFLINE) await page.route((u) => !u.href.startsWith(base), (r) => r.abort());
    await page.goto(`${base}/portfolio-${nn}/`, { waitUntil: "domcontentloaded", timeout: 15000 }).catch((e) => errors.push("goto " + e.message));
    await page.waitForTimeout(3500);
    for (const label of ["Passer", "Skip"]) { const b = page.getByRole("button", { name: label, exact: true }); if (await b.count().catch(() => 0)) { await b.first().click({ timeout: 1000 }).catch(() => {}); await page.waitForTimeout(1500); } }
    await page.screenshot({ path: `${out}/portfolio-${nn}-${name}.png` });
    console.log(nn, name, errors.length ? "ERR: " + errors.join(" | ").slice(0, 300) : "ok");
    await ctx.close();
  }
}
await browser.close();
