import { chromium } from "playwright";
const base = process.argv[2] || "http://localhost:8080/";
const out = process.argv[3] || "tests";
const browser = await chromium.launch({ args: ["--autoplay-policy=user-gesture-required"] });
const runs = [
  { name: "iphone", viewport: { width: 390, height: 844 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true },
  { name: "desktop", viewport: { width: 1440, height: 900 }, deviceScaleFactor: 1 },
];
for (const r of runs) {
  const ctx = await browser.newContext({ viewport: r.viewport, deviceScaleFactor: r.deviceScaleFactor, isMobile: !!r.isMobile, hasTouch: !!r.hasTouch, locale: "fr-FR" });
  await ctx.route("https://njdev154.github.io/**", (q) => q.fulfill({ status: 200, contentType: "text/html", body: "<title>stub</title>ok" }));
  const page = await ctx.newPage();
  const log = [];
  page.on("console", (m) => { if (["error", "warning"].includes(m.type())) log.push(m.type() + ": " + m.text()); });
  page.on("pageerror", (e) => log.push("pageerror: " + e.message));
  page.on("requestfailed", (q) => { if (!q.url().startsWith("https://njdev154")) log.push("reqfail: " + q.url()); });
  page.on("response", (s) => { if (s.status() >= 400) log.push("http " + s.status() + " " + s.url()); });
  await page.goto(base, { waitUntil: "load" });
  await page.waitForTimeout(3200);
  await page.screenshot({ path: `${out}/${r.name}-1-accueil.png` });
  const canAac = await page.evaluate(() => new Audio().canPlayType('audio/mp4; codecs="mp4a.40.2"'));
  await page.click("#enter");
  await page.waitForTimeout(2200);
  const audioState = await page.evaluate(() => ({ soundHidden: document.querySelector("#sound").hidden, label: document.querySelector(".sound__label").textContent }));
  let toggled = null;
  if (await page.locator("#sound").isVisible()) { await page.click("#sound"); toggled = await page.evaluate(() => document.querySelector("#sound").getAttribute("aria-pressed") + "/" + document.querySelector(".sound__label").textContent); await page.click("#sound"); }
  await page.screenshot({ path: `${out}/${r.name}-2-attentions.png` });
  // défiler doucement pour déclencher les messages
  for (let i = 0; i < 14; i++) { await page.mouse.wheel(0, r.viewport.height * 0.45); await page.waitForTimeout(700); }
  const said = await page.evaluate(() => document.querySelectorAll(".note.is-said").length);
  await page.locator("#emma").scrollIntoViewIfNeeded(); await page.waitForTimeout(2500);
  await page.screenshot({ path: `${out}/${r.name}-3-emma.png` });
  const emma = await page.evaluate(() => ({ text: document.querySelector("#emma-word").textContent, w: document.querySelector("#emma-word").getBoundingClientRect().width, vw: innerWidth }));
  // son : toggle
  await page.waitForTimeout(9000);
  const soundAfterEnd = await page.evaluate(() => document.querySelector("#sound").hidden);
  await page.locator("#papii").scrollIntoViewIfNeeded(); await page.waitForTimeout(1500);
  await page.screenshot({ path: `${out}/${r.name}-4-papii.png` });
  await page.locator("#exposition").scrollIntoViewIfNeeded(); await page.waitForTimeout(1500);
  await page.screenshot({ path: `${out}/${r.name}-5-expo.png` });
  const works = page.locator(".work");
  for (let i = 0; i < 8; i++) { await works.nth(i).scrollIntoViewIfNeeded(); await page.waitForTimeout(1300); if ([0,2,3,4,6].includes(i)) await page.screenshot({ path: `${out}/${r.name}-6-work-${i+1}.png` }); }
  const imgs = await page.evaluate(() => [...document.querySelectorAll(".work img")].map((i) => i.naturalWidth > 0));
  // ouvrir un portfolio : nouvel onglet
  const [popup] = await Promise.all([ctx.waitForEvent("page"), page.locator(".cartel__open").nth(3).click()]);
  await popup.waitForLoadState("domcontentloaded"); const popupUrl = popup.url(); await popup.close();
  await page.bringToFront(); await page.evaluate(() => document.dispatchEvent(new Event("visibilitychange"))); await page.waitForTimeout(800);
  const whisper = await page.evaluate(() => document.querySelector("#whisper").textContent);
  const seenShown = await page.evaluate(() => !document.querySelector('[data-seen="04"]').hidden);
  // choix
  await page.locator("#choix").scrollIntoViewIfNeeded(); await page.waitForTimeout(1200);
  await page.locator('label[for="pick-02"]').click(); await page.locator('label[for="pick-06"]').click(); await page.waitForTimeout(400);
  await page.screenshot({ path: `${out}/${r.name}-7-choix.png` });
  const current = await page.textContent("#choice-current");
  await page.click("#choice-confirm"); await page.waitForTimeout(1200);
  await page.screenshot({ path: `${out}/${r.name}-8-confirme.png` });
  const wa = await page.getAttribute("#sealed-send", "href");
  await page.locator("#fin").scrollIntoViewIfNeeded(); await page.mouse.wheel(0, 200); await page.waitForTimeout(4500);
  await page.screenshot({ path: `${out}/${r.name}-9-fin.png` });
  const overflow = await page.evaluate(() => document.documentElement.scrollWidth - innerWidth);
  // persistance au rechargement
  await page.reload({ waitUntil: "load" }); await page.waitForTimeout(800);
  const persisted = await page.evaluate(() => ({ sealedVisible: !document.querySelector("#sealed").hidden, pick: document.querySelector("#sealed-pick").textContent }));
  console.log(JSON.stringify({ run: r.name, canAac, audioState, soundAfterEnd, said, emma, toggled, imgs, popupUrl, whisper, seenShown, current, wa, overflow, persisted, log }, null, 1));
  await ctx.close();
}
await browser.close();
