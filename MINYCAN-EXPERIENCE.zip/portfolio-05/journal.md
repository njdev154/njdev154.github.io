# Journal

## 2026-10-28
- Agent : Copilot
- Vérifié : `index.html` s’affiche dans le navigateur et le serveur HTTP local répond `200 OK`.
- Fait : diagnostic de l’échec signalé avec Go Live ; aucune erreur du site n’a été reproduite.
- À faire : vérifier l’extension Live Server dans VS Code, le dossier ouvert, l’URL/port affiché et les messages de la console si Go Live échoue encore.

## 2026-10-28
- Agent : Copilot
- Fait : palette réduite à des tons papier, encre et cuivre ; retrait du monogramme rond, des points décoratifs et des jetons flottants qui chevauchaient l’accueil ; curseur natif rétabli.
- Fait : déclinaison appliquée à l’accueil et à la page 404, favicon simplifié, README actualisé.
- À faire : vérifier le rendu final sur mobile et confirmer que la nouvelle direction visuelle convient.
