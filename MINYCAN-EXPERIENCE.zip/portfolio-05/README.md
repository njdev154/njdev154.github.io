# Portfolio · N'Goran Junior

Portfolio motion design de **N'Goran Junior**, développeur web à Abidjan.
En ligne : https://njdev154.github.io/portfolio-05/

## Ce qui bouge
- Nom géant en police variable : les lettres s'élargissent près du curseur, une vague les traverse au repos.
- Portrait qu'on peut tirer, il revient. Rôle qui défile, heure d'Abidjan en direct.
- Cartes projets lançables comme un boomerang : elles partent, tournent, reviennent.
- Études de cas (contexte, ce que ça démontre, ce que j'ai appris, « Honnêtement »), galerie, lien partageable `#/projets/cibanque`.
- Matrice compétences × projets : pas de pourcentages, des preuves.
- Parcours : la ligne se dessine au scroll, un point orange voyage, les étapes s'allument.
- Fiche contact : on choisit l'objet et le délai, puis on lance la fiche vers le haut pour envoyer (e-mail ou WhatsApp pré-remplis). Email copiable.
- Identité visuelle resserrée : papier chaud, encre sombre et cuivre discret. Le nom remplace le monogramme rond, et les technologies ne flottent plus sur le texte d'accueil.
- Barre de progression, menu mobile en cercle, curseur natif et `prefers-reduced-motion` respecté.

## Mettre en ligne
1. Dépôt nommé exactement `njdev154.github.io`.
2. Dépose tout le contenu de ce dossier à la racine (y compris `.nojekyll`).
3. Settings → Pages → Deploy from a branch → `main` / `(root)`.

## Sécurité
- Aucun script, police ou tracker externe : tout est servi par le site (polices dans `assets/fonts`).
- Content Security Policy : seules les ressources du site sont chargées, aucun envoi de formulaire vers un tiers.
- Liens externes en `rel="noopener noreferrer"`, email assemblé en JavaScript contre les robots.
- Aucun secret, aucune donnée stockée.

## Modifier
Le site est compilé dans `index.html`. Pour changer un texte simple, cherche-le dans `index.html`.
Pour remplacer le CV : garde le même nom `assets/docs/CV-NGoran-Junior.pdf`.
