// MINYCAN EXPERIENCE · point d'entrée.
// Site statique sans dépendance : HTML, CSS et modules JavaScript natifs.
import { $, $$, onceVisible } from "./utils.js";
import { prepareAudio } from "./audio.js";
import { initWelcome } from "./scenes/welcome.js";
import { buildNotes, startNotes } from "./scenes/notes.js?v=nickname-spacing-1";
import { buildGallery } from "./scenes/gallery.js";
import { buildChoice } from "./scenes/choice.js";
import { buildFinale } from "./scenes/finale.js";

// Où se pose la lumière du projecteur selon la scène
const SPOTS = { accueil: ["28%", "40%"], attentions: ["72%", "48%"], exposition: ["18%", "26%"], choix: ["62%", "62%"], fin: ["50%", "50%"] };

function trackScenes() {
  const body = document.body;
  const setScene = (id) => {
    if (body.dataset.scene === id) return;
    body.dataset.scene = id;
    const [x, y] = SPOTS[id] || SPOTS.accueil;
    body.style.setProperty("--spot-x", x);
    body.style.setProperty("--spot-y", y);
  };
  setScene("accueil");
  if (!("IntersectionObserver" in window)) return;
  const io = new IntersectionObserver((entries) => {
    entries.forEach((e) => { if (e.isIntersecting) setScene(e.target.id); });
  }, { rootMargin: "-45% 0px -45% 0px" });
  $$(".scene").forEach((s) => io.observe(s));
}

function boot() {
  try {
    prepareAudio();
    buildNotes();
    buildGallery();
    buildChoice();
    buildFinale();
  } catch (err) {
    console.error("Préparation incomplète :", err);
  }
  trackScenes();
  initWelcome({
    onEnter() {
      startNotes();
      onceVisible($$(".reveal"), (n) => n.classList.add("is-in"), { threshold: 0.2 });
    },
  });

  // Le rideau se lève quand les polices sont prêtes (2,5 s maximum).
  const fontsReady = document.fonts ? document.fonts.ready : Promise.resolve();
  Promise.race([fontsReady, new Promise((r) => setTimeout(r, 2500))]).then(() => {
    document.body.classList.remove("is-loading");
    setTimeout(() => document.body.classList.add("is-ready"), 350);
  });
}

boot();
