# Journal du projet

## 2026-11-01 — Copilot
- Préparé un workflow GitHub Actions qui extrait l'archive du site et la publie sur GitHub Pages.
- Mis à jour les instructions de redéploiement pour correspondre au workflow.
- Créé une archive à partir des fichiers du projet, vérifiée (255 fichiers, `.nojekyll` présent), puis envoyée au dépôt public.
- Le premier workflow a échoué car il cherchait l'archive dans un sous-dossier ; corrigé le chemin pour la racine du dépôt.
- Activé GitHub Actions comme source Pages ; le workflow de déploiement final a réussi.
- Vérifié que la page centrale et les huit adresses des portfolios répondent en ligne.
- À faire : tester le parcours sur un iPhone et un Android réels ; confirmer le numéro WhatsApp avant de partager le lien.

## 2026-11-01 — Copilot
- Réparti les petits noms dans les scènes (accueil, attention, exposition, retour, choix, confirmation, conclusion) sans retoucher le design ni le texte final.
- Mis à jour le README, l'archive de déploiement et le workflow pour utiliser MINYCAN-EXPERIENCE-v2.zip.
- À faire : publier la mise à jour sur GitHub, vérifier les scènes en ligne et confirmer le numéro WhatsApp.
