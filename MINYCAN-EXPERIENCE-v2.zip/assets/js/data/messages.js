// Les petites attentions de la scène 2, dans l'ordre d'apparition.
// `name` : le petit nom mis en valeur dans la phrase (doit apparaître tel quel dans `text`).
export const MESSAGES = [
  { text: "Coucou ma pkada…", name: "ma pkada", side: "start" },
  { text: "Prête pour une petite surprise ?", side: "end" },
  { text: "Prends ton temps, rien ne presse.", side: "start" },
  { text: "J'ai préparé tout ça rien que pour toi.", side: "end" },
  { text: "J'espère que tu souriras.", side: "start" },
];

// La plaisanterie typographique (une seule fois dans tout le site).
export const EMMANUELLA = {
  before: "E",
  stretch: "m",
  count: 10, // nombre de « m » : « Emmmmmmmmmmanuella »
  after: "anuella !",
  aside: "Ton prénom est toujours trop long.",
};

export const OWWWPAPII = "Owwwpapiiiii !";

// Phrases murmurées quand elle revient d'un portfolio.
export const WHISPERS = [
  "Re-bonjour, Minycan.",
  "Alors, tu en as pensé quoi ?",
  "Prends ton temps.",
  "Il t'a plu, celui-là ?",
];
